<?php

namespace vale\crates\crate;

use pocketmine\item\Item;

class CrateReward {

	/** @var Item */
	private $item = null;

	/** @var callable */
	private $callback;

	/**
	 * Reward constructor.
	 *
	 * @param Item|null $item
	 * @param callable $callable
	 */
	public function __construct(?Item $item, callable $callable) {
		$this->item = $item;
		$this->callback = $callable;
	}

	/**
	 * @return Item
	 */
	public function getItem(): ?Item {
		return $this->item;
	}

	/**
	 * @return callable
	 */
	public function getCallback(): callable {
		return $this->callback;
	}
}