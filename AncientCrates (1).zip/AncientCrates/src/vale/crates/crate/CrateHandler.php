<?php
namespace vale\crates\crate;

use pocketmine\block\BlockIds;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\nbt\tag\StringTag;
use pocketmine\tile\Chest;
use vale\crates\Main;

class CrateHandler implements Listener
{
	public Main $plugin;

	/**
	 * CrateHandler Constructor
	 * @param Main $plugin
	 */
	public function __construct(Main $plugin)
	{
		$this->plugin = $plugin;
	}

	public function ok(PlayerJoinEvent $event){
		$i = 0;
		$items = [
			"Common",
			"Uncommon",
			"Rare",
			"Basic",
			"Mythic"
		];
		foreach ($items as $item) {
			$i++;
			if ($i < 5) {
				$itemslol = Item::get(Item::STICK)->setCustomName($items[$i]);
				$itemslol->getNamedTag()->setTag(new StringTag($items[$i]));
				#$event->getPlayer()->getInventory()->addItem($itemslol);
			}
		}
	}

	/**
	 * @param PlayerInteractEvent $event
	 */
	public function onInteract(PlayerInteractEvent $event)
	{
		$player = $event->getPlayer();
		if ($event->getBlock()->getId() === BlockIds::CHEST) {
			$tag = $player->getInventory()->getItemInHand()->getNamedTag();
			if ($tag->hasTag("Common")) {
				$this->plugin->getCrateManager()->tryReward($player, "Common");
				$event->setCancelled(true);
			}
			if ($tag->hasTag("Rare")) {
				$this->plugin->getCrateManager()->tryReward($player, "Rare");
				$event->setCancelled(true);
			}
			if ($tag->hasTag("Mythic")) {
				$this->plugin->getCrateManager()->tryReward($player, "Mythic");
				$event->setCancelled(true);
			}
			if ($tag->hasTag("Uncommon")) {
				$this->plugin->getCrateManager()->tryReward($player, "Uncommon");
				$event->setCancelled(true);
			}
			if ($tag->hasTag("Basic")) {
				$this->plugin->getCrateManager()->tryReward($player, "Basic");
				$event->setCancelled(true);
			}
		}
	}
}