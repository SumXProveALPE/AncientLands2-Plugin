<?php
namespace vale\crates\crate;

use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\StringTag;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;
use DaPigGuy\PiggyCustomEnchants\CustomEnchantManager;
use onebone\economyapi\EconomyAPI;
use pocketmine\Player;
use pocketmine\utils\Color;
use pocketmine\utils\TextFormat;
use vale\crates\Main;
class CrateManager
{
	public Main $plugin;

	public const KEYS = ["Common", "Uncommon", "Basic", "Rare", "Mythic"];

	const YELLOWCRYSTAL = "YellowCrystal";
	const PURPLECRYSTAL = "PurpleCrystal";
	const REDCRYSTAL = "RedCrystal";
	const ORANGECRYSTAL = "OrangeCrystal";
	const BLUECRYSTAL = "BlueCrystal";
	const GREENCRYSTAL = "GreenCrystal";
	const HELLFIRE = "HellFire";
	const Grace = "Grace";
	const MINDSTONE = "MindStone";
	const POWERSTONE = "PowerStone";
	const REALITYSTONE = "RealityStone";
	const SOULSTONE = "SoulStone";
	const SPACESTONE = "SpaceStone";
	const TIMESTONE = "TimeStone";

	const Nature = "Nature";


	/**
	 * CrateManager Constructor
	 * @param Main $plugin
	 */
	public function __construct(Main $plugin)
	{
		$this->plugin = $plugin;
		$this->plugin->getServer()->getPluginManager()->registerEvents(new CrateHandler($plugin), $plugin);
	}

	/**
	 * @param string $key
	 * @return mixed|string
	 */
	public function getKey(string $key)
	{
		$data = $this->plugin->getConfig()->getAll();
		$lol = $data["keys"];
		return $lol[$key];
	}

	/**
	 * @param string $what
	 * @return string
	 */
	public function getCratePrefix(string $what): string
	{
		$key = $this->getKey($what);
		return $key["prefix"];
	}

	/**
	 * @param string $what
	 * @return string
	 */
	public function getCrateUniqueTag(string $what): string
	{
		$key = $this->getKey($what);
		return $key["uniqueTag"];
	}
    #the most aids function ive made in my life
	/**
	 * @param Player $player
	 * @param string $tag
	 */
	public function tryReward(Player $player, string $tag): void
	{
		$crate = $this->getKey($tag);
		$prefix = $this->getCratePrefix($tag);
		$tag = $this->getCrateUniqueTag($tag);
		if($tag === "Mythic"){
			$random = mt_rand(1,5);
			$rewards = [
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::ENDER_CHEST);
					$item->setNamedTagEntry(new StringTag("moneypouch", 5));
					$item->setNamedTagEntry(new ListTag("ench", []));
					$item->setCustomName("§d§lMoney Pouch §r§7(Tap anywhere)");
					$item->setLore([
						"§7* §bTier: " . TextFormat::GRAY . Main::roman($random)]);
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved a Money Pouch!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$common = Item::get(340, 100, 16);
					$common->setCustomName("§r§bCommon Enchantment Book");
					$common->setLore([
						'§r§7Examine to recive a random',
						'§r§aCommon §7enchantment book'
					]);
					$player->getInventory()->addItem($common);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Common Books!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$common = Item::get(340, 100, 16);
					$common->setCustomName("§r§bCommon Enchantment Book");
					$common->setLore([
						'§r§7Examine to recive a random',
						'§r§aCommon §7enchantment book'
					]);
					$player->getInventory()->addItem($common);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Common Books!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$common = Item::get(340, 100, 16);
					$common->setCustomName("§r§bCommon Enchantment Book");
					$common->setLore([
						'§r§7Examine to recive a random',
						'§r§aCommon §7enchantment book'
					]);
					$player->getInventory()->addItem($common);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Common Books!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$uncommon = Item::get(340, 101, rand(1,32));
					$uncommon->setCustomName("§r§eUncommon Enchantment Book");
					$uncommon->setLore([
						'§r§7Examine to recive a random',
						'§r§eUncommon §7enchantment book'
					]);
					$player->getInventory()->addItem($uncommon);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Uncommon Books!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$mythic = Item::get(340, 103, rand(1,10));
					$mythic->setCustomName("§r§4Mythic Enchantment Book");
					$mythic->setLore([
						'§r§7Examine to recive a random',
						'§r§4Mythic §7enchantment book'
					]);
					$player->getInventory()->addItem($mythic);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Mythic Books!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(388);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§4BrokenKey Hell§cFire");
					$special->setLore([
						"§r",
						"§r§7Put Nine of These in a crafting time to make an HellFire KEY",
						"§r",
						"§r§7These is an OP KEY",
						"§r",
						"§r§6Tier Level: §4DEMON RACE",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString(self::HELLFIRE, "hellfire");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved x{$random} {$special->getCustomName()}!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(351,5);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§5Power Stone");
					$special->setLore([
						"§r",
						"§r§7Created From The Power Of All Gods",
						"§r§7Given tremendous power to those who own it",
						"§r§7Be careful for this power could kill you",
						"§r",
						"§r§7Right click to claim its powers",
						"§r",
						"§r§6Tier Level: §aTier 4",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString(self::POWERSTONE, "power");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved x{$random} {$special->getCustomName()}!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(388);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§6BrokenKey §fGr§ga§fce");
					$special->setLore([
						"§r",
						"§r§7Put Nine of These in a crafting time to make an Grace KEY",
						"§r",
						"§r§7These is an OP KEY",
						"§r",
						"§r§6Tier Level: §6ANGEL RACE",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString(self::Grace, "grace");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved x{$random} {$special->getCustomName()}!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(351,10);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§aGreen Crystal");
					$special->setLore([
						"§r",
						"§r§7Event Key",
						"§r",
						"§r§6Tier Level: §a5",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString(self::GREENCRYSTAL, "green");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved x{$random} {$special->getCustomName()}!");
				}),


				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$rare = Item::get(340, 102, rand(1,32));
					$rare->setCustomName("§r§6Rare Enchantment Book");
					$rare->setLore([
						'§r§7Examine to recive a random',
						'§r§6Rare §7enchantment book'
					]);
					$player->sendMessage($prefix . " §r§aYou recieved {$rare->getCustomName()} Mythic Books!");
					$player->getInventory()->addItem($rare);
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(388,0,rand(1,10));
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§6BrokenKey §fGr§ga§fce");
					$special->setLore([
						"§r",
						"§r§7Put Nine of These in a crafting time to make an Grace KEY",
						"§r",
						"§r§7These is an OP KEY",
						"§r",
						"§r§6Tier Level: §6ANGEL RACE",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("Grace", "grace");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved a Broken Key Fragment!");
				}),
				new CrateReward($item = Item::get(ItemIds::DIAMOND_SWORD), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§4§lDemon Sword");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),4));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 5));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), rand(1,10)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),

				new CrateReward($item = Item::get(ItemIds::DIAMOND_HELMET), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§c§lMythic §r§fHelmet");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),8));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Frozen"),rand(1,4)));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"),rand(1,5)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),

				new CrateReward($item = Item::get(ItemIds::DIAMOND_CHESTPLATE), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§c§lMythic §r§fChestplate");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),5));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"),rand(1,4)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(351,11);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§eYellow Crystal");
					$special->setLore([
						"§r",
						"§r§7Event Key",
						"§r",
						"§r§6Tier Level: §a2",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("YellowCrystal", "yellow");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved a {$special->getCustomName()}");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,2000));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1000));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1000));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1000));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$random = rand(1,200000);
					EconomyAPI::getInstance()->addMoney($player,$random);
					$player->sendMessage($prefix . " §r§aYou recieved $random $");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$random = rand(1,200000);
					EconomyAPI::getInstance()->addMoney($player,$random);
					$player->sendMessage($prefix . " §r§aYou recieved $random $");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$book = Item::get(Item::BOOK);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),10));
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
					$player->getInventory()->addItem($book);
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$book = Item::get(Item::BOOK);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),3));
					$player->getInventory()->addItem($book);
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$goldenapples = Item::get(Item::ENCHANTED_GOLDEN_APPLE, rand(1,5));
					$player->getInventory()->addItem($goldenapples);
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$axe = Item::get(Item::DIAMOND_AXE);
					$axe->setCustomName("§r§2§lOgre Axe");
					$axe->setLore([
						'§r§7Crafted by the one Eyed Ogre SumXProve',
					]);
					$axe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),rand(1,10)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"),rand(1,4)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"),rand(1,4)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::FEATHERWEIGHT),rand(1,4)));
					$player->getInventory()->addItem($axe);
					$player->sendMessage($prefix . " §r§aYou recieved a {$axe->getCustomName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$axe = Item::get(Item::DIAMOND_SWORD);
					$axe->setCustomName("§r§c§lPheonix Sword");
					$axe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),rand(1,10)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::WITHER),rand(1,5)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::FEATHERWEIGHT),rand(1,5)));
					$player->getInventory()->addItem($axe);
					$player->sendMessage($prefix . " §r§aYou recieved a {$axe->getCustomName()}");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::DIAMOND_HELMET);
					$helm->setCustomName("§r§c§lPheonix Helmet");
					$helm->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),rand(1,10)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::CLARITY),rand(1,5)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::OVERLOAD),rand(1,5)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::VALOR),rand(1,5)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::RESILIENCE),rand(1,4)));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getCustomName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::DIAMOND_LEGGINGS);
					$helm->setCustomName("§r§c§lPheonix Leggings");
					$helm->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),rand(1,10)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::OVERLOAD),rand(1,5)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::PHOENIX),rand(1,4)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::REMENDY),rand(1,4)));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getCustomName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::GOLD_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::IRON_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::EMERALD_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::ENDER_PEARL, 0, rand(1,10));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::DIAMOND_PICKAXE);
					$helm->setCustomName("§4§lOP PICK");
					$helm->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY),rand(1,10)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::KEYPLUS),rand(1,4)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::DRILLER),rand(1,4)));
					$helm->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING),rand(1,10)));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getCustomName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::DIAMOND_BOOTS);
					$helm->setCustomName("§r§c§lPheonix Leggings");
					$helm->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),rand(1,10)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::OVERLOAD),rand(1,5)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::GEARS),rand(1,4)));
					$helm->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::SPRINGS),rand(1,4)));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getCustomName()}");
				}),
			];
			$reward = $rewards[array_rand($rewards)];
			$callable = $reward->getCallback();
			$callable($player);
		}

		if($tag === "Rare"){
			$random = mt_rand(1,5);
			$rewards = [
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::ENDER_CHEST);
					$item->setNamedTagEntry(new StringTag("moneypouch", 5));
					$item->setNamedTagEntry(new ListTag("ench", []));
					$item->setCustomName("§d§lMoney Pouch §r§7(Tap anywhere)");
					$item->setLore([
						"§7* §bTier: " . TextFormat::GRAY . Main::roman($random)]);
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved a Money Pouch!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::GOLD_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::IRON_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::EMERALD_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::ENDER_PEARL, 0, rand(1,10));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$common = Item::get(340, 100, 16);
					$common->setCustomName("§r§bCommon Enchantment Book");
					$common->setLore([
						'§r§7Examine to recive a random',
						'§r§aCommon §7enchantment book'
					]);
					$player->getInventory()->addItem($common);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Common Books!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$common = Item::get(340, 100, 16);
					$common->setCustomName("§r§bCommon Enchantment Book");
					$common->setLore([
						'§r§7Examine to recive a random',
						'§r§aCommon §7enchantment book'
					]);
					$player->getInventory()->addItem($common);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Common Books!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$common = Item::get(340, 100, 16);
					$common->setCustomName("§r§bCommon Enchantment Book");
					$common->setLore([
						'§r§7Examine to recive a random',
						'§r§aCommon §7enchantment book'
					]);
					$player->getInventory()->addItem($common);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Common Books!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$uncommon = Item::get(340, 101, rand(1,32));
					$uncommon->setCustomName("§r§eUncommon Enchantment Book");
					$uncommon->setLore([
						'§r§7Examine to recive a random',
						'§r§eUncommon §7enchantment book'
					]);
					$player->getInventory()->addItem($uncommon);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Uncommon Books!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$mythic = Item::get(340, 103, rand(1,10));
					$mythic->setCustomName("§r§4Mythic Enchantment Book");
					$mythic->setLore([
						'§r§7Examine to recive a random',
						'§r§4Mythic §7enchantment book'
					]);
					$player->getInventory()->addItem($mythic);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Mythic Books!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$rare = Item::get(340, 102, rand(1,32));
					$rare->setCustomName("§r§6Rare Enchantment Book");
					$rare->setLore([
						'§r§7Examine to recive a random',
						'§r§6Rare §7enchantment book'
					]);
					$player->sendMessage($prefix . " §r§aYou recieved {$rare->getCustomName()} Mythic Books!");
					$player->getInventory()->addItem($rare);
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(388,0,rand(1,10));
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§6BrokenKey §fGr§ga§fce");
					$special->setLore([
						"§r",
						"§r§7Put Nine of These in a crafting time to make an Grace KEY",
						"§r",
						"§r§7These is an OP KEY",
						"§r",
						"§r§6Tier Level: §6ANGEL RACE",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("Grace", "grace");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved a Broken Key Fragment!");
				}),
				new CrateReward($item = Item::get(ItemIds::DIAMOND_SWORD), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§4§lDemon Sword");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),4));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 5));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), rand(1,10)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),

				new CrateReward($item = Item::get(ItemIds::DIAMOND_HELMET), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§c§lMythic §r§fHelmet");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),8));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Frozen"),rand(1,4)));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"),rand(1,5)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),

				new CrateReward($item = Item::get(ItemIds::DIAMOND_CHESTPLATE), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§c§lMythic §r§fChestplate");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),5));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"),rand(1,4)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(351,11);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§eYellow Crystal");
					$special->setLore([
						"§r",
						"§r§7Event Key",
						"§r",
						"§r§6Tier Level: §a2",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("YellowCrystal", "yellow");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved a {$special->getCustomName()}");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,2000));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1000));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1000));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1000));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$random = rand(1,200000);
					EconomyAPI::getInstance()->addMoney($player,$random);
					$player->sendMessage($prefix . " §r§aYou recieved $random $");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$random = rand(1,200000);
					EconomyAPI::getInstance()->addMoney($player,$random);
					$player->sendMessage($prefix . " §r§aYou recieved $random $");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$book = Item::get(Item::BOOK);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),10));
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
					$player->getInventory()->addItem($book);
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$book = Item::get(Item::BOOK);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),3));
					$player->getInventory()->addItem($book);
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$goldenapples = Item::get(Item::ENCHANTED_GOLDEN_APPLE, rand(1,5));
					$player->getInventory()->addItem($goldenapples);
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$axe = Item::get(Item::DIAMOND_AXE);
					$axe->setCustomName("§r§2§lOgre Axe");
					$axe->setLore([
						'§r§7Crafted by the one Eyed Ogre SumXProve',
					]);
					$axe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),rand(1,10)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"),rand(1,4)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"),rand(1,4)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::FEATHERWEIGHT),rand(1,4)));
					$player->getInventory()->addItem($axe);
					$player->sendMessage($prefix . " §r§aYou recieved a {$axe->getCustomName()}");
				}),
			];
			$reward = $rewards[array_rand($rewards)];
			$callable = $reward->getCallback();
			$callable($player);

		}

		if($tag === "Uncommon"){
			$random = rand(1,5);
			$rewards = [
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::GOLD_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::IRON_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::EMERALD_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::ENDER_PEARL, 0, rand(1,10));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(351,1);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§4Red Crystal");
					$special->setLore([
						"§r",
						"§r§7Event Key",
						"§r",
						"§r§6Tier Level: §a3",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("RedCrystal", "red");
					$special->setNamedTag($nbt);
					$player->sendMessage($prefix . " §r§aYou recieved a {$special->getCustomName()} !");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::DIAMOND_BLOCK, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Diamond Blocks!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::OBSIDIAN, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} OBBY!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::BEDROCK, 0, rand(1,5));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Bedrock!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::ENCHANTED_GOLDEN_APPLE, 0, rand(1,5));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Enchanted Apples!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::GOLDEN_APPLE, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Golden Apples!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::BONE, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Bones!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::ENDER_CHEST);
					$item->setNamedTagEntry(new StringTag("moneypouch", $random));
					$item->setNamedTagEntry(new ListTag("ench", []));
					$item->setCustomName("§d§lMoney Pouch §r§7(Tap anywhere)");
					$item->setLore([
						"§7* §bTier: " . TextFormat::GRAY . Main::roman($random)]);
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved a Money Pouch!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$common = Item::get(340, 100, $random);
					$common->setCustomName("§r§bCommon Enchantment Book");
					$common->setLore([
						'§r§7Examine to recive a random',
						'§r§aCommon §7enchantment book'
					]);
					$player->getInventory()->addItem($common);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Common Books!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(388);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§6BrokenKey §fGr§ga§fce");
					$special->setLore([
						"§r",
						"§r§7Put Nine of These in a crafting time to make an Grace KEY",
						"§r",
						"§r§7These is an OP KEY",
						"§r",
						"§r§6Tier Level: §6ANGEL RACE",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("Grace", "grace");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved a Broken Key Fragment!");
				}),
				new CrateReward($item = Item::get(ItemIds::DIAMOND_SWORD), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§4§lDemon Sword §r§7§o(Forged From the Depths of Hell!)");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),4));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 3));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 3));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),

				new CrateReward($item = Item::get(ItemIds::DIAMOND_HELMET), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§e§lSandstorm §r§fHelmet");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),5));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Frozen"),rand(1,4)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),

				new CrateReward($item = Item::get(ItemIds::DIAMOND_CHESTPLATE), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§e§lSandstorm §r§fChestplate");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),5));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"),rand(1,4)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(351,11);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§eYellow Crystal");
					$special->setLore([
						"§r",
						"§r§7Event Key",
						"§r",
						"§r§6Tier Level: §a2",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("YellowCrystal", "yellow");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved a {$special->getCustomName()}");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,500));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1000));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1809));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1809));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$random = rand(1,100000);
					EconomyAPI::getInstance()->addMoney($player,$random);
					$player->sendMessage($prefix . " §r§aYou recieved $random $");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$random = rand(1,50000);
					EconomyAPI::getInstance()->addMoney($player,$random);
					$player->sendMessage($prefix . " §r§aYou recieved $random $");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$book = Item::get(Item::BOOK);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),3));
					$player->getInventory()->addItem($book);
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$book = Item::get(Item::BOOK);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),3));
					$player->getInventory()->addItem($book);
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$axe = Item::get(Item::DIAMOND_AXE);
					$axe->setCustomName("§r§2§lOgre Axe");
					$axe->setLore([
						'§r§7Crafted by the one Eyed Ogre SumXProve',
					]);
					$axe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),rand(1,10)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"),rand(1,4)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"),rand(1,4)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::FEATHERWEIGHT),rand(1,4)));
					$player->getInventory()->addItem($axe);
					$player->sendMessage($prefix . " §r§aYou recieved a {$axe->getCustomName()}");
				}),
			];
			$reward = $rewards[array_rand($rewards)];
			$callable = $reward->getCallback();
			$callable($player);

		}

		if($tag === "Basic"){
			$random = rand(1,5);
			$rewards = [
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::GOLD_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::IRON_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::EMERALD_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::ENDER_PEARL, 0, rand(1,10));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(351,1);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§4Red Crystal");
					$special->setLore([
						"§r",
						"§r§7Event Key",
						"§r",
						"§r§6Tier Level: §a3",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("RedCrystal", "red");
					$special->setNamedTag($nbt);
					$player->sendMessage($prefix . " §r§aYou recieved a {$special->getCustomName()} !");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::DIAMOND_BLOCK, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Diamond Blocks!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::OBSIDIAN, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} OBBY!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::BEDROCK, 0, rand(1,5));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Bedrock!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::ENCHANTED_GOLDEN_APPLE, 0, rand(1,5));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Enchanted Apples!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::GOLDEN_APPLE, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Golden Apples!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::BONE, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Bones!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::ENDER_CHEST);
					$item->setNamedTagEntry(new StringTag("moneypouch", $random));
					$item->setNamedTagEntry(new ListTag("ench", []));
					$item->setCustomName("§d§lMoney Pouch §r§7(Tap anywhere)");
					$item->setLore([
						"§7* §bTier: " . TextFormat::GRAY . Main::roman($random)]);
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved a Money Pouch!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$common = Item::get(340, 100, $random);
					$common->setCustomName("§r§bCommon Enchantment Book");
					$common->setLore([
						'§r§7Examine to recive a random',
						'§r§aCommon §7enchantment book'
					]);
					$player->getInventory()->addItem($common);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Common Books!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(388);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§6BrokenKey §fGr§ga§fce");
					$special->setLore([
						"§r",
						"§r§7Put Nine of These in a crafting time to make an Grace KEY",
						"§r",
						"§r§7These is an OP KEY",
						"§r",
						"§r§6Tier Level: §6ANGEL RACE",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("Grace", "grace");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved a Broken Key Fragment!");
				}),
				new CrateReward($item = Item::get(ItemIds::DIAMOND_SWORD), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§4§lDemon Sword §r§7§o(Forged From the Depths of Hell!)");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),4));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 3));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 3));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),

				new CrateReward($item = Item::get(ItemIds::DIAMOND_HELMET), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§e§lSandstorm §r§fHelmet");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),5));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Frozen"),rand(1,4)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),

				new CrateReward($item = Item::get(ItemIds::DIAMOND_CHESTPLATE), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§e§lSandstorm §r§fChestplate");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),5));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"),rand(1,4)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(351,11);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§eYellow Crystal");
					$special->setLore([
						"§r",
						"§r§7Event Key",
						"§r",
						"§r§6Tier Level: §a2",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("YellowCrystal", "yellow");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved a {$special->getCustomName()}");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,500));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1000));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1809));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1809));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$random = rand(1,100000);
					EconomyAPI::getInstance()->addMoney($player,$random);
					$player->sendMessage($prefix . " §r§aYou recieved $random $");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$random = rand(1,50000);
					EconomyAPI::getInstance()->addMoney($player,$random);
					$player->sendMessage($prefix . " §r§aYou recieved $random $");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$book = Item::get(Item::BOOK);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),3));
					$player->getInventory()->addItem($book);
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$book = Item::get(Item::BOOK);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),3));
					$player->getInventory()->addItem($book);
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$axe = Item::get(Item::DIAMOND_AXE);
					$axe->setCustomName("§r§2§lOgre Axe");
					$axe->setLore([
						'§r§7Crafted by the one Eyed Ogre SumXProve',
					]);
					$axe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),rand(1,10)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"),rand(1,4)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"),rand(1,4)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::FEATHERWEIGHT),rand(1,4)));
					$player->getInventory()->addItem($axe);
					$player->sendMessage($prefix . " §r§aYou recieved a {$axe->getCustomName()}");
				}),
			];
			$reward = $rewards[array_rand($rewards)];
			$callable = $reward->getCallback();
			$callable($player);

		}
		if($tag === "Common"){
			$random = rand(1,5);
			$rewards = [
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::COAL_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
					$player->sendMessage($prefix . " §r§aYou recieved a Broken Key Fragment!");
				}),


				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::GOLD_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::IRON_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::EMERALD_BLOCK, 0, rand(1,128));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$helm = Item::get(Item::ENDER_PEARL, 0, rand(1,10));
					$player->getInventory()->addItem($helm);
					$player->sendMessage($prefix . " §r§aYou recieved a {$helm->getName()}");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(351,1);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§4Red Crystal");
					$special->setLore([
						"§r",
						"§r§7Event Key",
						"§r",
						"§r§6Tier Level: §a3",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("RedCrystal", "red");
					$special->setNamedTag($nbt);
					$player->sendMessage($prefix . " §r§aYou recieved a {$special->getCustomName()} !");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::DIAMOND_BLOCK, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Diamond Blocks!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::OBSIDIAN, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} OBBY!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::BEDROCK, 0, rand(1,5));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Bedrock!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::ENCHANTED_GOLDEN_APPLE, 0, rand(1,5));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Enchanted Apples!");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::GOLDEN_APPLE, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Golden Apples!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::BONE, 0, rand(1,20));
					$player->getInventory()->addItem($item);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Bones!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$item = ItemFactory::get(ItemIds::ENDER_CHEST);
					$item->setNamedTagEntry(new StringTag("moneypouch", $random));
					$item->setNamedTagEntry(new ListTag("ench", []));
					$item->setCustomName("§d§lMoney Pouch §r§7(Tap anywhere)");
					$item->setLore([
						"§7* §bTier: " . TextFormat::GRAY . Main::roman($random)]);
					     $player->getInventory()->addItem($item);
						 $player->sendMessage($prefix . " §r§aYou recieved a Money Pouch!");
				 }),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$common = Item::get(340, 100, $random);
					$common->setCustomName("§r§bCommon Enchantment Book");
					$common->setLore([
						'§r§7Examine to recive a random',
						'§r§aCommon §7enchantment book'
					]);
					$player->getInventory()->addItem($common);
					$player->sendMessage($prefix . " §r§aYou recieved {$random} Common Books!");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(388);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§6BrokenKey §fGr§ga§fce");
					$special->setLore([
						"§r",
						"§r§7Put Nine of These in a crafting time to make an Grace KEY",
						"§r",
						"§r§7These is an OP KEY",
						"§r",
						"§r§6Tier Level: §6ANGEL RACE",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("Grace", "grace");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved a Broken Key Fragment!");
				}),
				new CrateReward($item = Item::get(ItemIds::DIAMOND_SWORD), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§4§lDemon Sword §r§7§o(Forged From the Depths of Hell!)");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),4));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 3));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 3));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),

				new CrateReward($item = Item::get(ItemIds::DIAMOND_HELMET), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§e§lSandstorm §r§fHelmet");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),5));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Frozen"),rand(1,4)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),

				new CrateReward($item = Item::get(ItemIds::DIAMOND_CHESTPLATE), function (Player $player) use ($random, $prefix, $item) {
					$item->setCustomName("§r§e§lSandstorm §r§fChestplate");
					$item->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),5));
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"),rand(1,4)));
					$player->sendMessage($prefix . " §r§aYou recieved a {$item->getCustomName()}");
					$player->getInventory()->addItem($item);
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$special = Item::get(351,11);
					$special->setNamedTagEntry(new ListTag("ench", []));
					$special->setCustomName("§eYellow Crystal");
					$special->setLore([
						"§r",
						"§r§7Event Key",
						"§r",
						"§r§6Tier Level: §a2",
						"§r§3"
					]);
					$nbt = $special->getNamedTag();
					$nbt->setString("YellowCrystal", "yellow");
					$special->setNamedTag($nbt);
					$player->getInventory()->addItem($special);
					$player->sendMessage($prefix . " §r§aYou recieved a {$special->getCustomName()}");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,500));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1000));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1809));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$player->addXp(rand(1,1809));
					$player->sendMessage($prefix . " §r§aYou recieved $random xp");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$random = rand(1,100000);
					EconomyAPI::getInstance()->addMoney($player,$random);
					$player->sendMessage($prefix . " §r§aYou recieved $random $");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$random = rand(1,50000);
					EconomyAPI::getInstance()->addMoney($player,$random);
					$player->sendMessage($prefix . " §r§aYou recieved $random $");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$book = Item::get(Item::BOOK);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION),3));
					$player->getInventory()->addItem($book);
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
				}),
				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$book = Item::get(Item::BOOK);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),3));
					$player->getInventory()->addItem($book);
					$player->sendMessage($prefix . " §r§aYou recieved a Book");
				}),

				new CrateReward($item = null, function (Player $player) use ($random, $prefix) {
					$axe = Item::get(Item::DIAMOND_AXE);
					$axe->setCustomName("§r§2§lOgre Axe");
					$axe->setLore([
						'§r§7Crafted by the one Eyed Ogre SumXProve',
					]);
					$axe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS),rand(1,10)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"),rand(1,4)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"),rand(1,4)));
					$axe->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantment(CustomEnchantIds::FEATHERWEIGHT),rand(1,4)));
					$player->getInventory()->addItem($axe);
					$player->sendMessage($prefix . " §r§aYou recieved a {$axe->getCustomName()}");
				}),
			];
			$reward = $rewards[array_rand($rewards)];
			$callable = $reward->getCallback();
			$callable($player);

		}
	}
}