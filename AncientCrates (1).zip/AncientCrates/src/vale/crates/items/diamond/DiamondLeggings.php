<?php

declare(strict_types = 1);


namespace vale\crates\items\diamond;
//Base Libraries
use pocketmine\item\{
	DiamondLeggings as PMLEG,
};

class DiamondLeggings extends PMLEG{

	public function __construct(){
		parent::__construct(self::DIAMOND_LEGGINGS);
	}

	public function getDefensePoints() : int{
		return 7;
	}
	public function getMaxDurability() : int{
		return 10000;
	}
}