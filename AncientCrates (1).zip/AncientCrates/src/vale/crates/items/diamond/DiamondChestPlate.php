<?php

declare(strict_types = 1);


namespace vale\crates\items\diamond;
//Base Libraries
use pocketmine\item\{
	DiamondChestplate as PMCHEST,
};

class DiamondChestPlate extends PMCHEST{

	public function __construct(){
		parent::__construct(self::DIAMOND_CHESTPLATE);
	}

	public function getDefensePoints() : int{
		return 7;
	}
	public function getMaxDurability() : int{
		return 10000;
	}
}