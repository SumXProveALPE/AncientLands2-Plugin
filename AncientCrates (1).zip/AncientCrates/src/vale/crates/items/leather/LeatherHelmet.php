<?php

declare(strict_types = 1);


namespace vale\crates\items\leather;
//Base Libraries
use pocketmine\item\{
	LeatherCap as PMHELM,
};

class LeatherHelmet extends PMHELM{

	public function __construct(){
		parent::__construct(self::LEATHER_CAP);
	}

	public function getDefensePoints() : int{
		return 7;
	}
	public function getMaxDurability() : int{
		return 8000;
	}
}