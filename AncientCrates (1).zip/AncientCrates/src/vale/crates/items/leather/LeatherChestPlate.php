<?php

declare(strict_types = 1);


namespace vale\crates\items\leather;
//Base Libraries
use pocketmine\item\{
	LeatherTunic as PMCHEST,
};

class LeatherChestPlate extends PMCHEST{

	public function __construct(){
		parent::__construct(self::LEATHER_CHESTPLATE);
	}
	public function getDefensePoints() : int{
		return 7;
	}
	public function getMaxDurability() : int{
		return 8000;
	}
}