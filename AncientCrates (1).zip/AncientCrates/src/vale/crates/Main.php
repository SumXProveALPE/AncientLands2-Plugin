<?php
namespace vale\crates;

use Exception;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\item\ItemFactory;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use vale\crates\crate\CrateManager;
use vale\crates\crate\CrateReward;
use vale\crates\items\diamond\DiamondBoots;
use vale\crates\items\diamond\DiamondChestPlate;
use vale\crates\items\diamond\DiamondHelmet;
use vale\crates\items\diamond\DiamondLeggings;
use vale\crates\items\leather\LeatherBoots;
use vale\crates\items\leather\LeatherChestPlate;
use vale\crates\items\leather\LeatherHelmet;
use vale\crates\items\leather\LeatherLeggings;

class Main extends PluginBase implements Listener
{

	private CrateManager $crateManager;

	/*BRO IF UR READING THIS AND UR A DEV BRO DONT JUDGE ME
	 HE WANTED ME TO MAKE A SIMPLE CRATES PLUGIN FFS
	*/

	/** @var $config */
	private $config;

	public function onEnable(): void
	{
		$this->config = $this->getConfig()->getAll();
		if (!is_dir($this->getDataFolder())) @mkdir($this->getDataFolder()); //IK PMMP DOES THIS BY DEFAULT FOR SOME REASON IT WASNT WORKING
		try {
			$this->crateManager = new CrateManager($this);
		} catch (Exception $exception) {
			$this->getLogger()->info("Could Not Initiate CrateManager");
		}
		$items = [
			DiamondHelmet::class,
			DiamondChestplate::class,
			DiamondLeggings::class,
			DiamondBoots::class,
		    LeatherHelmet::class,
		    LeatherChestPlate::class,
		    LeatherLeggings::class,
			LeatherBoots::class,
		];
		foreach ($items as $class){
			ItemFactory::registerItem(new $class(), true);
			$this->getLogger()->info($class);
		}
	}

	public static function roman($number): string
	{
		$roman = "I";
		switch ($number) {
			case 5:
				$roman = "V";
				break;
			case 4:
				$roman = "IV";
				break;
			case 3:
				$roman = "III";
				break;
			case 2:
				$roman = "II";
				break;
			case 1:
				$roman = "I";
				break;
		}
		return $roman;
	}

	public function getAllData()
	{
		return $this->config;
	}

	/**
     * @return CrateManager
     */
    public function getCrateManager(): CrateManager{
        return $this->crateManager;
    }
}