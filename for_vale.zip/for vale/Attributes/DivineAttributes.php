<?php

namespace core\addons;

use core\AncientLands;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\plugin\Plugin;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\item\Durable;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\CompoundTag;


class DivineAttributes extends PluginCommand{

	/** @var array */
	public $plugin;

	public function __construct($name, AncientLands $plugin) {
        parent::__construct($name, $plugin);
        $this->setDescription("Divine Attributes");
        $this->setUsage("/dwa <player>");
        $this->setPermission("core.command.dwa");
		$this->plugin = $plugin;
    }

	/**
     * @param CommandSender $sender
     * @param string $alias
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool{
		if (!$sender->hasPermission("core.command.dwa")) {
			$sender->sendMessage(TextFormat::RED . "You do not have permission to use this command");
			return false;
		}
		if (count($args) < 1) {
            $sender->sendMessage(TextFormat::GOLD . "Usage:" . TextFormat::GREEN . " /dwa <player>");
            return false;
        }
		if (!empty($args[0])) {
            $target = $this->getPlayer($args[0]);
			if ($target == null) {
                $sender->sendMessage(TextFormat::RED . "That player cannot be found");
				return false;
			}
            if ($target == true) {
			    $special = Item::get(375);
                $special->setCustomName("§f§lDi§gv§fine §fAtt§gr§fibute §f(§gGrace§f§l)");
                $special->setLore([
                '§r§f§lLevel: §g1',
                '§r§f§lApply: §g§l100%',
                '§r',
                '§r§g§lHoly Grace',
                '§r§f Drop Below 5 Hearts for an Instant Health boost',
                '§r§f with Regen 20 for the next minute.',
                '§r',
                '§r§f Example: If you are fighting',
                '§r§f and get below, 5 hearts this ablity will proct',
                '§r§f for the next minute',
                '§r§f your be unstopable',
                '§r',
                '§r§7Divine Attribute can §nONLY §r§7be applied',
                '§r§7to §gWeapons and only 1 §nattribute',
                '§r§7can be imbued per weapon',
                '§r',
				'§r§7to learn more about Divine Attributes use §g/divine',
                '§r§3'
                ]);
				$target->getInventory()->addItem($special);
                $target->sendMessage("§a§l(!) §r§aYou recieved All The Divine Attributes!");
				return true;
            }
		}
	}

	/**
     * @param string $player
     * @return null|Player
     */
    public function getPlayer($player): ?Player{
        if (!Player::isValidUserName($player)) {
            return null;
        }
        $player = strtolower($player);
        $found = null;
        foreach($this->plugin->getServer()->getOnlinePlayers() as $target) {
            if (strtolower(TextFormat::clean($target->getDisplayName(), true)) === $player || strtolower($target->getName()) === $player) {
                $found = $target;
                break;
            }
        }
        if (!$found) {
            $found = ($f = $this->plugin->getServer()->getPlayer($player)) === null ? null : $f;
        }
        if (!$found) {
            $delta = PHP_INT_MAX;
            foreach($this->plugin->getServer()->getOnlinePlayers() as $target) {
                if (stripos(($name = TextFormat::clean($target->getDisplayName(), true)), $player) === 0) {
                    $curDelta = strlen($name) - strlen($player);
                    if ($curDelta < $delta) {
                        $found = $target;
                        $delta = $curDelta;
                    }
                    if ($curDelta === 0) {
                        break;
                    }
                }
            }
        }
        return $found;
    }
}
