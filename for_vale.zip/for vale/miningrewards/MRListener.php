<?php


namespace Sinkerz\AncientLands\miningrewards;


use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;
use Sinkerz\AncientLands\sessions\Sessions;
use onebone\economyapi\EconomyAPI;

class MRListener implements Listener
{

    public function onBreak(BlockBreakEvent $event) {
        if ($event->isCancelled()) return;
        $player = $event->getPlayer();
        $session = Sessions::getSession($player);
        $level = $session->getLevel();
        $economy = EconomyAPI::getInstance();
        if ($level < MRManager::MAX_LEVEL) {
            if ($player->getLevel()->getName() !== "mine" or $player->getLevel()->getName() !== "kingmine2") return;
            $xp = mt_rand(2, 4) * $session->getLevel();
            if ($session->getBlocks() < MRManager::getInstance()->getRequiredBlocks($level)) {
                $session->updateMRData("blocks", $session->getBlocks() + 1);
            } else $player->sendMessage("§r§aYou have reached the required amount of mined blocks you can now rankup using the /rankup command!");
            $economy->addMoney($player, MRManager::getInstance()->getMoneyPerBlock($level));
            $player->addXp($xp);
            $player->sendPopup("§r§l§8[" . TextFormat::DARK_AQUA . MRManager::getInstance()->roman($level) . "§8]§a + §r§f$" . MRManager::getInstance()->getMoneyPerBlock($level) . "§8| §a§l+ §r§f$xp Experience");
        }
    }

}
