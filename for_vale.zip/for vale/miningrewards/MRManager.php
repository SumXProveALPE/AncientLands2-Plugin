<?php


namespace Sinkerz\AncientLands\miningrewards;


use pocketmine\item\Item;
use Sinkerz\AncientLands\Core;

class MRManager
{

    public $levels = [];
    const BASE_BLOCK_COUNT = 10000;
    const MAX_LEVEL = 100;
    public static $instance = null;

    public static function getInstance() :self{
        if(self::$instance === null){
            self::$instance = new self;
        }
        return self::$instance;
    }

    public function registerLevel(int $level, int $moneyPerBlock = 0, int $rankUp = 0, int $requiredBlocks = 0) {
        $this->levels[$level] = ["MoneyPerBlock" => $moneyPerBlock, "Blocks" => $requiredBlocks, "RankUP" => $rankUp];
        Core::getInstance()->getLogger()->info("MiningRewards: Successfully registered Level " . $level);
    }

    public function getRankUpPrice(int $level):int {
        var_dump($level);
        if ($this->levels[$level]["RankUP"] <= 0) {
            return ($level * 25000);
        }
        return $this->levels[$level]["RankUP"];
    }

    public function getRequiredBlocks(int $level):int {
        if ($this->levels[$level]["Blocks"] <= 0) {
            return ($level * self::BASE_BLOCK_COUNT);
        }
        return $this->levels[$level]["Blocks"];
    }

    public function getMoneyPerBlock(int $level) {
        if ($this->levels[$level]["MoneyPerBlock"] <= 0) {
            return ($level * mt_rand(10, 15));
        }
        return ($this->levels[$level]["MoneyPerBlock"] * $level);
    }

    public function roman(int $lvl): string{
        $string = "";
        $romans = [
            "C" => 100,
            "L" => 50,
            "XL" => 40,
            "X" => 10,
            "IX" => 9,
            "VIII" => 8,
            "VII" => 7,
            "VI" => 6,
            "V" => 5,
            "IV" => 4,
            "III" => 3,
            "II" => 2,
            "I" => 1
        ];

        while($lvl > 0){
            foreach($romans as $roman => $int){
                if($lvl >= $int){
                    $lvl -= $int;
                    $string .= $roman;
                    break;
                }
            }
        }
        return $string;
    }

}
