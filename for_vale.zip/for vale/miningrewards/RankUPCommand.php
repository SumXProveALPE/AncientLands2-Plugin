<?php


namespace Sinkerz\AncientLands\miningrewards;


use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\utils\CommandException;
use pocketmine\Player;
use Sinkerz\AncientLands\Core;
use Sinkerz\AncientLands\sessions\Sessions;
use onebone\economyapi\EconomyAPI;

class RankUPCommand extends Command
{

    public function __construct() {
        parent::__construct("rankup");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender instanceof Player) return;
        $session = Sessions::getSession($sender);
        $economy = EconomyAPI::getInstance();
        $cost = MRManager::getInstance()->getRankUpPrice($session->getLevel());
        $requiredBlocks = MRManager::getInstance()->getRequiredBlocks($session->getLevel());
        if ($session->getLevel() >= MRManager::MAX_LEVEL) {
            $sender->sendMessage("§r§cYou have already reached the max level!");
            return;
        }
        if ($requiredBlocks > $session->getBlocks()) {
            $sender->sendMessage("§r§cYou must mine " . ($requiredBlocks - $session->getBlocks()) . " more blocks in order to rank up.");
            return;
        }
        if ($cost > $economy->myMoney($sender)) {
            $sender->sendMessage("§r§cYou do not have enough money to rank up! RankUP Cost: $cost");
            return;
        }
        $economy->reduceMoney($sender, $cost);
        $session->updateMRData("level", ($session->getLevel() + 1));
        $session->updateMRData("blocks", 0);
        $sender->sendTitle("§r§a§lMining Rewards", "§r§7You successfully ranked up to level §a" . $session->getLevel());
    }
}