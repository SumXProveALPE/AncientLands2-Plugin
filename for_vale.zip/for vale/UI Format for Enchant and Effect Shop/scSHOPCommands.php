<?php

namespace Sinkerz\AncientLands\commands\types;

use jojoe77777\FormAPI\FormAPI;
use Sinkerz\AncientLands\Core;

use pocketmine\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\plugin\Plugin;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use sum\StoreCredit;

//use jojoe77777\FormAPI;

class scSHOPCommands extends Command{

	/** @var array */
	public $plugin;

	public function __construct(){
        parent::__construct("scshop");
        $this->setDescription("Store Credit Shop");
        $this->setUsage("/cs");
        $this->setPermission("core.command.scshop");
		$this->plugin = Core::getInstance();
    }

	/**
     * @param CommandSender $sender
     * @param string $alias
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool{
		if (!$sender->hasPermission("core.command.scshop")) {
	      	$sender->sendMessage(TextFormat::RED . "You do not have permission to use this command");
            return false;
        }
		if (!$sender instanceof Player) {
			$sender->sendMessage(TextFormat::RED . "This command can be only used in-game.");
			return false;
		}
	    $this->scSHOP($sender);
		return true;
	}

    /**
     * @param Player $player
     */
	public function scSHOP(Player $player) : void{
	    /** @var FormAPI $api */
		$api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $player, int $data = null) {
            $result = $data;
            if ($result === null) {
                return;
            }

            $commands = ['setgroup ' . $player->getName() . ' Divine', 'setgroup ' . $player->getName() . ' Fantasy', 'setgroup ' . $player->getName() . ' Mirage', 'perm ' . $player->getName() . ' Fly', 'perm ' . $player->getName() . ' Heal', 'perm ' . $player->getName() . ' Feed', 'gem ' . $player->getName() . ' Inferno', 'gem ' . $player->getName() . ' Hercules', 'gem ' . $player->getName() . ' Poseidon', 'gem ' . $player->getName() . ' Asgardian', 'gem ' . $player->getName() . ' Amazon', 'gem ' . $player->getName() . ' Atlas', 'gem ' . $player->getName() . ' Hydra', 'gem ' . $player->getName() . ' Cerberus', 'gem ' . $player->getName() . ' Posessive', 'gem ' . $player->getName() . ' Cronus', 'moneypouch ' . $player->getName() . ' 1', 'moneypouch ' . $player->getName() . ' 2', 'moneypouch ' . $player->getName() . ' 3', 'moneypouch ' . $player->getName() . ' 4', 'moneypouch ' . $player->getName() . ' 5', 'mobsack ' . $player->getName() . ' 1', 'keypouch ' . $player->getName() . ' 1', 'keypouch ' . $player->getName() . ' 2', 'keypouch ' . $player->getName() . ' 3'];
            $costs = [100, 150, 250 ,35, 25, 15, 10, 15, 20, 30, 40, 50, 75, 85, 95, 120, 10, 15, 20, 25, 30, 15, 3, 6, 9];

            if (!isset($commands[$data]) || !isset($costs[$data])) return;

            $command = $commands[$data];
            $cost = $costs[$data];

            if (StoreCredit::getInstance()->getCredit($player) < $cost) {
                $player->sendMessage("You do not have enough store credits!");
                return;
            }

            StoreCredit::getInstance()->takeCredit($player, $cost);
            $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), $command);
        });
		$form->setTitle(TextFormat::BOLD . TextFormat::GREEN . "§3§lStoreCredit SHOP");
	    $form->setContent(TextFormat::GREEN . "");
	    $form->addButton(TextFormat::BLUE . "§rDivine\n§r§6100 Store Credit");
		$form->addButton(TextFormat::BLUE . "§rFantasy\n§r§6150 Store Credit");
		$form->addButton(TextFormat::BLUE . "§rMirage\n§r§6250 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rFly Permission\n§r§635 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rHeal Permission\n§r§625 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rFeed Permission\n§r§615 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rInferno Gem\n§r§610 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rHercules Gem\n§r§615 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rPoseidon Gem\n§r§620 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rAsgardian Gem\n§r§630 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rAmazon Gem\n§r§640 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rAtlas Gem\n§r§650 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rHydra Gem\n§r§675 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rCerberus Gem\n§r§685 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rPosessive Gem\n§r§695 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rCronus Gem\n§r§6120 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rMoney Pouch T1\n§r§610 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rMoney Pouch T2\n§r§615 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rMoney Pouch T3\n§r§620 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rMoney Pouch T4\n§r§625 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rMoney Pouch T5\n§r§630 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rMob Coin Sack\n§r§615 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rKey Pouch T1\n§r§63 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rKey Pouch T2\n§r§66 Store Credit");
        $form->addButton(TextFormat::BLUE . "§rKey Pouch T3\n§r§69 Store Credit");
		$form->sendToPlayer($player);
	}
}
