<?php

declare(strict_types=1);

namespace Sinkerz\AncientLands\commands\types;

use pocketmine\command\CommandSender;
use pocketmine\lang\TranslationContainer;
use pocketmine\Player;
use pocketmine\command\Command;
use Sinkerz\AncientLands\Core;
//use core\API;
use pocketmine\command\PluginCommand;
use function array_filter;
use function array_map;
use function count;
use function implode;
use function sort;
use const SORT_STRING;

class ListCommand extends Command{

    private $plugin;

    const EXTRA_SLOTS = 0;

    public function __construct(){
        parent::__construct("list");
        $this->setDescription("Checks for all the online players!");
        $this->setUsage("/list");
		$this->plugin = Core::getInstance();
    }

	public function execute(CommandSender $sender, string $commandLabel, array $args){
		if(!$this->testPermission($sender)){
			return true;
		}

		$playerNames = array_map(function(Player $player) : string{
			return $player->getName();
		}, array_filter($this->getOnlinePlayers(), function(Player $player) use ($sender) : bool{
			return $player->isOnline() and (!($sender instanceof Player) or $sender->canSee($player));
		}));
		sort($playerNames, SORT_STRING);

		$sender->sendMessage(new TranslationContainer("commands.players.list", [count($playerNames), $sender->getServer()->getMaxPlayers() - self::EXTRA_SLOTS]));
		$sender->sendMessage(implode(", ", $playerNames));

		return true;
	}

	public function getOnlinePlayers(): array{
        return $this->plugin->getServer()->getOnlinePlayers();
    }
}