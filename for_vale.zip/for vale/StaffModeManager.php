<?php

namespace Sinkerz\AncientLands\staffmode;

use jojoe77777\FormAPI\FormAPI;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\MenuIds;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\mcpe\protocol\types\GameMode;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use Sinkerz\AncientLands\brokengems\BrokenGemManager;
use Sinkerz\AncientLands\Core;

class StaffModeManager implements Listener {
//
//    /**
//     * @var Config
//     */
//    private $bans;

    public function __construct(){
//        $this->bans = new Config(Core::getInstance()->getDataFolder() . "bans.yml", Config::JSON);
        Core::getInstance()->getServer()->getPluginManager()->registerEvents($this, Core::getInstance());
    }

    private $staffMode = [];
    private $inventories;

    public function isInStaffMode(Player $player): bool{
        return isset($this->staffMode[$player->getName()]);
    }

    public function setInStaffMode(Player $player): void{
        $this->staffMode[$player->getName()] = $player;
    }

    public function removeFromStaffMode(Player $player): void{
        if(isset($this->staffMode[$player->getName()])){
            unset($this->staffMode[$player->getName()]);
        }
    }

    /**
     * @param Player $player
     * @return Item[]
     */
    public function getInventory(Player $player): array{
        if(!isset($this->inventories[$player->getName()])){
            return [];
        }
        return $this->inventories[$player->getName()];
    }

    public function saveInventory(Player $player): void{
        $this->inventories[$player->getName()] = $player->getInventory()->getContents();
    }

    public function removeInventory(Player $player): void{
        if(isset($this->inventories[$player->getName()])) unset($this->inventories[$player->getName()]);
    }

    public static $staffChat = [];

    public function onChat(PlayerChatEvent $event): void{
        $player = $event->getPlayer();
        $message = $event->getMessage();
        // Staff Chat Private Only
        if (isset(self::$staffChat[$player->getName()])) {
            foreach(Core::getInstance()->getServer()->getOnlinePlayers() as $target) {
                if ($target->hasPermission("permission.staff") && $player->hasPermission("permission.staff")) {
                    $target->sendMessage(TextFormat::YELLOW . "§8[§6SC§8] " . TextFormat::GOLD . $player->getName() . ": " . TextFormat::GREEN . $message);
                    $event->setCancelled(true);
                }
            }
        }
    }

	public function onDrop(PlayerDropItemEvent $event)
	{
		$player = $event->getPlayer();
			if($this->isInStaffMode($player)){
				$event->setCancelled();
		}
	}
                public function onInteract(PlayerInteractEvent $event): void{
        $player = $event->getPlayer();
        $item = $event->getItem();
        if($this->isInStaffMode($player)){
            if($item->getNamedTag()->hasTag(self::INSPECT)){
		   $menu = InvMenu::create(MenuIds::TYPE_DOUBLE_CHEST);
		   $menu->readonly(true);
		   $menu->setName("§r§6§l" . $entity->getName() . "'§r§7 s Inventory");
		   $helmet = $entity->getArmorInventory()->getHelmet();
		   $chestplate = $entity->getArmorInventory()->getChestplate();
		   $leggings = $entity->getArmorInventory()->getLeggings();
		   $boots = $entity->getArmorInventory()->getBoots();
		   $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
		   $entityInventory = $entity->getInventory()->getContents();
		   $menu->getInventory()->setContents($entityInventory);
		   $menu->getInventory()->setItem(47, $helmet);
		   $menu->getInventory()->setItem(48, $chestplate);
		   $menu->getInventory()->setItem(50, $leggings);
		   $menu->getInventory()->setItem(51, $boots);
		   $menu->send($damager);
		   $damager->sendMessage("§r§e(§6§l!§r§e) Checking Inventory.");

	    }
            if($item->getNamedTag()->hasTag(self::STAFFMODE)){
                $player->setGamemode(GameMode::SURVIVAL);
                $val = $item->getNamedTag()->getTag(self::STAFFMODE)->getValue();
                switch($val){
                    case self::RANDOMTP:
                        $rand = $player->getServer()->getOnlinePlayers()[array_rand($player->getServer()->getOnlinePlayers())];
                        $player->teleport($rand);
                        $player->sendMessage(TextFormat::GRAY . "You teleported to " . TextFormat::GREEN . $rand->getName());
                        break;
                    case self::BAN:
                        $callable = function(Player $player, $data): void{
                            if($data !== null){
                                switch($data){
                                    case "banplayers":
                                        $form = new SimpleForm(function(Player $player, $data): void{
                                            if($data !== null){
                                                $chosenPlayer = $player->getServer()->getPlayer($data);
                                                $form = new CustomForm(function(Player $player, $data)use($chosenPlayer): void{
                                                    if($data !== null){
                                                        $days = $data["days"];
                                                        $hours = $data["hours"];
                                                        $minutes = $data["minutes"];
                                                        $rsn = $data["rsn"];
                                                        $datetime = new \DateTime();
                                                        $player->getServer()->getNameBans()->addBan(
                                                            $chosenPlayer->getName(),
                                                            $rsn === "" ? "Banned by admin" : $rsn,
                                                            $datetime->add(new \DateInterval('P' . $days . 'D' . 'T' . $hours . 'H' . $minutes . 'M')),
                                                            $player->getName()
                                                        );
                                                        $array = [
                                                            TextFormat::GREEN . $chosenPlayer->getName() . " has been banned from the server",
                                                            TextFormat::AQUA . "Time:",
                                                            TextFormat::AQUA . "Days " . TextFormat::GOLD . $days,
                                                            TextFormat::AQUA . "Hours " . TextFormat::GOLD . $hours,
                                                            TextFormat::AQUA . "Minutes " . TextFormat::GOLD . $minutes,
                                                            TextFormat::AQUA . "Reason " . TextFormat::GOLD . ($rsn === "" ? "Banned by admin" : $rsn)
                                                        ];
                                                        $chosenPlayer->kick();
                                                        $player->getServer()->broadcastMessage(implode(TextFormat::EOL, $array));
                                                    }
                                                });
                                                $form->addSlider("Days", 0, 30, 1, 0, "days");
                                                $form->addSlider("Hours", 0 , 24, 1, 0, "hours");
                                                $form->addSlider("Minutes", 0,60, 1, 0, "minutes");
                                                $form->addInput("Reason", "Banned by admin", "Banned by admin", "rsn");
                                                $form->setTitle(TextFormat::BOLD . TextFormat::RED . $data);
                                                $player->sendForm($form);
                                            }
                                        });
                                        foreach($player->getServer()->getOnlinePlayers() as $onlinePlayer){
                                            $form->addButton($onlinePlayer->getName(), -1, "", $onlinePlayer->getName());
                                        }
                                        $form->setContent(TextFormat::GRAY . "Select a player to continue");
                                        $form->setTitle(TextFormat::BOLD . TextFormat::RED . "PLAYER LIST");
                                        $player->sendForm($form);
                                        break;
                                    case "checkplayers":
                                        $bans = $player->getServer()->getNameBans()->getEntries();
                                        if(empty($bans)){
                                            $player->sendMessage(TextFormat::BOLD . TextFormat::RED . "No players are banned.");
                                            return;
                                        }

                                        foreach($bans as $ban){
                                            $form = new SimpleForm(function(Player $player, $data): void {
                                                if ($data !== null) {
                                                    $entry = $player->getServer()->getNameBans()->getEntry($data);
                                                    if ($entry->getExpires() === null) {
                                                        return;
                                                    }
                                                    if ($entry !== null) {
                                                        $form = new SimpleForm(function (Player $player, $data) use ($entry): void {
                                                            if ($data !== null) {
                                                                switch ($data) {
                                                                    case "banplayer":
                                                                        $player->getServer()->broadcastMessage(TextFormat::GREEN . $entry->getName() . " has been unbanned");
                                                                        $player->getServer()->getNameBans()->remove($entry->getName());
                                                                        break;
                                                                }
                                                            }
                                                        });

                                                        $timestamp = $entry->getExpires()->getTimestamp();
                                                        $datetime = new \DateTime();
                                                        $now = $datetime->getTimestamp();
                                                        $showTime = Core::secondsToTime($timestamp - $now);
                                                        $array = [
                                                            TextFormat::BOLD . TextFormat::DARK_GRAY . "(" . TextFormat::RED . "Information to Player" . TextFormat::DARK_GRAY . ")",
                                                            TextFormat::RED . "Expires in: ",
                                                            "",
                                                            TextFormat::RED . "Days: " . TextFormat::GRAY . $showTime["d"],
                                                            TextFormat::RED . "Hours: " . TextFormat::GRAY . $showTime["h"],
                                                            TextFormat::RED . "Minutes: " . TextFormat::GRAY . $showTime["m"],
                                                            TextFormat::RED . "Seconds: " . TextFormat::GRAY . $showTime["s"],
                                                            "",
                                                            TextFormat::RED . "Reason: " . TextFormat::GRAY . $entry->getReason() ?? "Banned by admin",
                                                            TextFormat::RED . "Banned by: " . TextFormat::GRAY . $entry->getSource() ?? "Unknown"
                                                        ];
                                                        $form->setContent(implode(TextFormat::EOL, $array));
                                                        $form->addButton(TextFormat::BOLD . TextFormat::RED . "UNBAN PLAYER", -1, "", "banplayer");
                                                        $form->setTitle(TextFormat::BOLD . TextFormat::RED . "UNBAN PLAYER");
                                                        $player->sendForm($form);
                                                    }
                                                }
                                            });

                                            $form->addButton(TextFormat::RED . $ban->getName(),-1,"", $ban->getName());
                                            $form->setTitle(TextFormat::BOLD . TextFormat::RED . "BAN ENTRIES");
                                            $player->sendForm($form);
                                        }
                                        break;
                                }
                            }
                        };
                        $form = new SimpleForm($callable);
                        $form->setTitle(TextFormat::BOLD . TextFormat::RED . "BAN OPTIONS");
                        $form->addButton(TextFormat::RED . "BAN PLAYERS", -1, "", "banplayers");
                        $form->addButton(TextFormat::RED . "CHECK BAN PLAYERS", -1, "", "checkplayers");
                        $player->sendForm($form);
                        break;
                    case self::TELEPORT:
                        $form = new SimpleForm(function(Player $player, $data): void{
                            if($data !== null){
                                $chosen = $player->getServer()->getPlayer($data);
                                $player->teleport($chosen);
                                $player->sendMessage(TextFormat::GREEN . "You teleported to " . TextFormat::WHITE . $chosen->getName());
                            }
                        });
                        foreach($player->getServer()->getOnlinePlayers() as $onlinePlayer){
                            $form->addButton(TextFormat::RED . $onlinePlayer->getName(), -1, "", $onlinePlayer->getName());
                        }
                        $form->setTitle(TextFormat::BOLD . TextFormat::RED . "PLAYERLIST");
                        $player->sendForm($form);
                        break;
                    case self::INSPECT:
		   			$menu = InvMenu::create(MenuIds::TYPE_DOUBLE_CHEST);
		   			$menu->readonly(true);
		   			$menu->setName("§r§6§l" . $entity->getName() . "'§r§7 s Inventory");
		   			$helmet = $entity->getArmorInventory()->getHelmet();
		   			$chestplate = $entity->getArmorInventory()->getChestplate();
		   			$leggings = $entity->getArmorInventory()->getLeggings();
		   			$boots = $entity->getArmorInventory()->getBoots();
		   			$menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
		   			$entityInventory = $entity->getInventory()->getContents();
		   			$menu->getInventory()->setContents($entityInventory);
		   			$menu->getInventory()->setItem(47, $helmet);
		   			$menu->getInventory()->setItem(48, $chestplate);
		   			$menu->getInventory()->setItem(50, $leggings);
		   			$menu->getInventory()->setItem(51, $boots);
		   			$menu->send($damager);
		   			$damager->sendMessage("§r§e(§6§l!§r§e) Checking Inventory.");
                    case self::VANISH:
                        $player->sendMessage(TextFormat::GREEN . "Vanished");
                        foreach($player->getServer()->getOnlinePlayers() as $onlinePlayer){
                            $onlinePlayer->hidePlayer($player);
                        }
                        $player->getServer()->removePlayerListData($player->getUniqueId());
                        $this->switchVanish($player);
                        break;
                    case self::UNVANISH:
                        foreach($player->getServer()->getOnlinePlayers() as $onlinePlayer){
                            $onlinePlayer->showPlayer($player);
                        }
                        $player->sendMessage(TextFormat::RED . "Unvanished");
                        $this->staffModeItems($player);
                        $player->getServer()->updatePlayerListData($player->getUniqueId(), $player->getId(), $player->getDisplayName(), $player->getSkin(), $player->getXuid());
                        break;
                        // this will be normal for the hidden player, but other players will not be able to even see u on the /list or query 
                }
            }
        }
    }

    const UNVANISH = "unvanish";

    public function switchVanish(Player $player): void{
        $unvanish = ItemFactory::get(ItemIds::DYE, 13);
        $unvanish->setCustomName(TextFormat::BOLD.TextFormat::RED . "Unvanish");
        $unvanish->setNamedTagEntry(new StringTag(self::STAFFMODE, self::UNVANISH));
        $player->getInventory()->setItem(8, $unvanish);
    }

    public function onEntity(EntityDamageByEntityEvent $event): void{
        $damager = $event->getDamager();
        $entity = $event->getEntity();
        if($damager instanceof Player && $entity instanceof Player){
            if($entity->isImmobile()) $event->setCancelled();
            if($damager->isImmobile()) $event->setCancelled();
            if($this->isInStaffMode($damager)){
                $hand = $damager->getInventory()->getItemInHand();
                if($hand->getNamedTag()->hasTag(self::STAFFMODE)){
                    switch($hand->getNamedTag()->getTag(self::STAFFMODE)->getValue()){
                        case self::FREEZE:
                            if($entity->isImmobile()){
                                $event->setCancelled();
                                $entity->setImmobile(false);
				$entity->sendMessage("§r§e(§6§l!§r§e) You have been §6§lunfrozen.");
				$damager->sendMessage("§r§e(§6§l!§r§e) You succesfully §6§lunfroze §r§e{$entity->getName()} .");
                            }else{
                                $event->setCancelled();
                                $entity->setImmobile(true);
				$entity->sendMessage("§r§e(§6§l!§r§e) You have been §6§lfrozen.");
				$damager->sendMessage("§r§e(§6§l!§r§e) You succesfully §6§lfroze §r§e{$entity->getName()} .");
                            }
                            break;
                        case self::PLAYERINFO:
                            $array = [
                                TextFormat::GRAY . "-------------",
                                TextFormat::RED . "Tag: " . TextFormat::GRAY . $entity->getName(),
                                TextFormat::RED . "Ping: " . TextFormat::GRAY . $entity->getPing() . "ms",
                                TextFormat::RED . "Address: " . TextFormat::GRAY . $entity->getAddress(),
                                TextFormat::RED . "Health: " . TextFormat::GRAY . $entity->getHealth() . " Health",
                                TextFormat::GRAY . "-------------",
                            ];
                            $damager->sendMessage(implode(TextFormat::EOL, $array));
                            $event->setCancelled();
                            break;

			}
               }
            }
		}
	}
    public function onCommand(PlayerCommandPreprocessEvent $event): void{
        $player = $event->getPlayer();
        $name = $player->getName();
        $message = $event->getMessage();
        // Permission Colour Chat
        $command = $this->colorMessage($message, $player);
        if (empty($command)) {
            $event->setCancelled();
        }
        $event->setMessage((string) $command);
    }

    public function onQuit(PlayerQuitEvent $event): void{
        $player = $event->getPlayer();
        if($player !== null){
            if(isset(self::$staffChat[$player->getName()])){
                unset(self::$staffChat[$player->getName()]);
            }
        }
    }

    public function colorMessage(string $message, Player $player = null, bool $force = false): ?string{
        $message = preg_replace_callback(
            "/(\\\&|\&)[0-9a-fk-or]/",
            function(array $matches) {
                return str_replace("\\§", "&", str_replace("&", "§", $matches[0]));
            },
            $message
        );
        if (strpos($message, "§") !== false && ($player instanceof Player) && !$player->hasPermission("core.colorchat.bypass") && !$force) {
            $player->sendMessage(TextFormat::RED . "You don't have permissions to use color chat");
            return null;
        }
        return $message;
    }

    const STAFFMODE = "staffmode";
    const RANDOMTP = 1;
    const BAN = 2;
    const TELEPORT = 3;
    const FREEZE = 4;
    const PLAYERINFO = 5;
    const INSPECT = 6;
    const VANISH = 7;

    public function staffModeItems(Player $player): void{
        $player->getInventory()->clearAll();
        $randomtp = ItemFactory::get(ItemIds::COMPASS);
        $randomtp->setCustomName(TextFormat::BOLD . TextFormat::DARK_GREEN . "RANDOMTP");
        $randomtp->setNamedTagEntry(new StringTag(self::STAFFMODE, self::RANDOMTP));

        $ban = ItemFactory::get(ItemIds::NETHERBRICK);
        $ban->setCustomName(TextFormat::BOLD . TextFormat::RED . "BAN");
        $ban->setNamedTagEntry(new StringTag(self::STAFFMODE, self::BAN));

        $teleport = ItemFactory::get(ItemIds::BOOK);
        $teleport->setCustomName(TextFormat::BOLD . TextFormat::DARK_AQUA . "TELEPORT");
        $teleport->setNamedTagEntry(new StringTag(self::STAFFMODE, self::TELEPORT));

        $freeze = ItemFactory::get(ItemIds::PACKED_ICE);
        $freeze->setCustomName(TextFormat::BOLD . TextFormat::GREEN . "FREEZE");
        $freeze->setNamedTagEntry(new StringTag(self::STAFFMODE, self::FREEZE));

        $playerinfo = ItemFactory::get(ItemIds::BLAZE_ROD);
        $playerinfo->setCustomName(TextFormat::BOLD . TextFormat::RED . "PLAYERINFO");
        $playerinfo->setNamedTagEntry(new StringTag(self::STAFFMODE, self::PLAYERINFO));

        $inspect = ItemFactory::get(ItemIds::BOOK);
        $inspect->setCustomName(TextFormat::BOLD . TextFormat::YELLOW . "INSPECT");
        $inspect->setNamedTagEntry(new StringTag(self::STAFFMODE, self::INSPECT));

        $vanish = ItemFactory::get(ItemIds::DYE, 5);
        //to 14
        $vanish->setCustomName(TextFormat::BOLD . TextFormat::GREEN . "VANISH");
        $vanish->setNamedTagEntry(new StringTag(self::STAFFMODE, self::VANISH));

        $contents = [
            0 => $randomtp,
            1 => $ban,
            2 => $teleport,
            4 => $freeze,
            6 => $playerinfo,
            7 => $inspect,
            8 => $vanish
        ];
        foreach($contents as $index => $item){
            $player->getInventory()->setItem($index, $item);
        }
    }

}