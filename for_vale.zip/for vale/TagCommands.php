<?php

namespace Sinkerz\AncientLands\commands\types;

use Sinkerz\AncientLands\Core;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\item\Durable;
use pocketmine\plugin\Plugin;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

use jojoe77777\FormAPI;
use _64FF00\PureChat\PureChat;

class TagCommands extends Command{
	
	/** @var array */
	public $plugin;

	public function __construct() {
        parent::__construct("tag");
        $this->setDescription("Give it tag");
        $this->setUsage("/tag");
		$this->setAliases(["tags"]);		
        $this->setPermission("core.command.tag");
		$this->plugin = Core::getInstance();
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool{
		if (!$sender->hasPermission("core.command.tag")) {
			$sender->sendMessage(TextFormat::RED . "You do not have permission to use this command");
			return false;
		}
		if (!$sender instanceof Player) {
			$sender->sendMessage(TextFormat::RED . "This command can be only used in-game.");
			return false;
		}
		$this->TagsUI($sender);
		return true;
	}
	
	/**
	 * @param TagsUI
	 * @param Player $player
     */
	public function TagsUI(Player $player) : void{
		$api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $player, int $data = null) {
        $result = $data;
        if ($result === null) {
            return;
        }
		switch($result) {
			case 0:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§aVoter§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "VOTER");
			break;
			case 1:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§dUrMuM§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "UrMuM");
			break;	
			case 2:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8<§1Hacker§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "HACKER");
			break;	
			case 3:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§cP§6V§cP§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "PVP");
			break;	
			case 4:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§6NO§aLIFE§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "NOLIFE");
			break;	
			case 5:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§6N§cOO§6B§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "NOOB");
			break;	
			case 6:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§aHold§2The§9L§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "HOLDTHEL");
			break;	
			case 7:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§aAB§300§aSE§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "AB00SE");
			break;
			case 8:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§9EZ§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "EZ");
			break;	
			case 9:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§eKarma§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "Karma");
			break;	
			case 10:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§2GOD§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "God");
			break;	
			case 11:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§a0§30§9F§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "OOF");
			break;		
			case 12:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§aOh§2Crap§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "OhCrap");
			break;		
			case 13:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§aE§9Girl§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "EGIRL");
			break;	
			case 14:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§aE§3Boy§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "EBOY");
			break;		
			case 15:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§6TRY§eHARD§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "TRYHARD");
			break;	
			case 16:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§aSuck§9It§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "SuckIt");
			break;	
			case 17:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§aScammer§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "Scammer");
			break;	
			case 18:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§8§6Corona§eVirus§8"), $player);
			$player->sendMessage(TextFormat::GREEN . "Set Tag To " . TextFormat::GREEN . "CoronaVirus");
			break;	
			case 19:
			$ppchat = $this->plugin->getServer()->getPluginManager()->getPlugin("PureChat");
			$ppchat->setSuffix((TextFormat::GREEN . "§a"), $player);
			$player->sendMessage(TextFormat::GREEN . "§aYou removed your tag");
			break;			
		    }
		});
		$form->setTitle(TextFormat::BOLD . TextFormat::GREEN . "Tags");
		$form->setContent(TextFormat::GREEN . "Select tags");
		$form->addButton(TextFormat::GREEN . "VOTER");
		$form->addButton(TextFormat::GREEN . "UrMuM");
		$form->addButton(TextFormat::GREEN . "HACKER");
		$form->addButton(TextFormat::GREEN . "PVP");	
		$form->addButton(TextFormat::GREEN . "NOLIFE");
		$form->addButton(TextFormat::GREEN . "NOOB");		
		$form->addButton(TextFormat::GREEN . "HoldTheL");
		$form->addButton(TextFormat::GREEN . "AB00SE");
		$form->addButton(TextFormat::GREEN . "EZ");
		$form->addButton(TextFormat::GREEN . "Karma");	
		$form->addButton(TextFormat::GREEN . "God");
		$form->addButton(TextFormat::GREEN . "OOF");	
		$form->addButton(TextFormat::GREEN . "OhCrap");
		$form->addButton(TextFormat::GREEN . "EGIRL");
		$form->addButton(TextFormat::GREEN . "EBOY");	
		$form->addButton(TextFormat::GREEN . "TRYHARD");	
		$form->addButton(TextFormat::GREEN . "SuckIt");
		$form->addButton(TextFormat::GREEN . "Scammer");	
		$form->addButton(TextFormat::GREEN . "CoronaVirus");		
		$form->addButton(TextFormat::GREEN . "§lRemove");			
		$form->sendToPlayer($player);
	}
}
