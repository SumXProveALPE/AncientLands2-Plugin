<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants;

use DaPigGuy\PiggyCustomEnchants\enchants\armor\AngelEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\AngelicEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\AntiKnockbackEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\ArmoredEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\AttackerDeterrentEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\BerserkerEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\boots\FrostWalkerEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\boots\MagmaWalkerEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\boots\MetaphysicalEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\boots\StompEnchantment;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\boots\WarmerEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\chestplate\CursedEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\chestplate\ObscureEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\chestplate\RagdollEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\chestplate\ShockWaveEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\CloakingEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\DefenseEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\DemonicEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\DiminishEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\DoomedEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\EndershiftEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\EnlightedEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\DeflectEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\FrozenEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\HeavyEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\helmet\AntitoxinEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\helmet\ClarityEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\helmet\DestructionEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\helmet\FocusedEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\helmet\BloodBerserkEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\helmet\ImplantsEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\helmet\MeditationEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\helmet\NourishEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\helmet\ResilienceEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\helmet\WeakeningEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\MoltenEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\ObsidianShieldEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\OverloadEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\DisarmorProtectionEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\EvasionEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\PhoenixEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\PoisonousCloudEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\RemendyEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\ReviveEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\SelfDestructEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\ShieldedEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\GearsEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\SpringsEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\TankEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\PainkillerEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\DodgeEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\TricksterEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\UnholyEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\ValorEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\VitaminsEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\VoodooEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\armor\HealingFactorEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;
use DaPigGuy\PiggyCustomEnchants\enchants\miscellaneous\AutoRepairEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\miscellaneous\LuckyEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\miscellaneous\RadarEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\miscellaneous\ReforgedEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\miscellaneous\SoulboundEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\miscellaneous\ToggleableEffectEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\AutoSellEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\BleedEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\CleaveEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\ConfusionEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\DevourEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\GenJutsuEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\HellForgeEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\InsanityEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\LotusEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\LumberjackEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\PummelEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\SoulStealEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\axes\WrathEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\EnergizingEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\ExplosiveEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\HasteEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\hoe\FarmerEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\hoe\FertilizerEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\hoe\HarvestEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\KeyPlusEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\MoneyFarmEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\pickaxe\BlockMasterEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\pickaxe\JackpotEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\pickaxe\MinerLuckEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\PouchPlusEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\QuickeningEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\GrindEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\DrillerEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\SmeltingEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\tools\TelepathyEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\AerialEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\BlackOutEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\BlessedEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\AutoAimEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\BombardmentEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\BountyHunterEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\GrapplingEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\HeadhunterEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\HealingEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\MissileEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\MolotovEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\ParalyzeEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\PiercingEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\ShuffleEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\bows\VolleyEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\ConditionalDamageMultiplierEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\AssassinEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\DeathbringerEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\DeathforgedEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\DeepWoundsEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\DemiseEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\DisarmingProtectionEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\DominateEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\DsrStaffEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\EnrageEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\ExecuteEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\FeatherWeightEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\FlingEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\GooeyEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\GravityEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\HallucinationEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\InquisitiveEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\LacedWeaponEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\LifestealEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\LightningEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\NeutralizeEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\OverDoseEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\PoisonEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\RazoredgedEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\SharpenEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\SilenceEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\SkillSwipeEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\SolitudeEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\SpitsWebEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\weapons\VampireEnchant;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\item\enchantment\Enchantment;
use ReflectionException;
use ReflectionProperty;
use SplFixedArray;

/**
 * Class CustomEnchantManager
 * @package DaPigGuy\PiggyCustomEnchants
 */
class CustomEnchantManager
{
    /** @var PiggyCustomEnchants */
    private static $plugin;

    /** @var CustomEnchant[] */
    public static $enchants = [];

    /**
     * @param PiggyCustomEnchants $plugin
     * @throws ReflectionException
     */
    public static function init(PiggyCustomEnchants $plugin): void
    {
        self::$plugin = $plugin;
        $vanillaEnchantments = new SplFixedArray(1024);

        $property = new ReflectionProperty(Enchantment::class, "enchantments");
        $property->setAccessible(true);
        foreach ($property->getValue() as $key => $value) {
            $vanillaEnchantments[$key] = $value;
        }
        $property->setValue($vanillaEnchantments);

        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::CURSED, "Cursed", [Effect::WITHER], [60], [1], CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::DRUNK, "Drunk", [Effect::SLOWNESS, Effect::MINING_FATIGUE, Effect::NAUSEA], [60, 60, 60], [1, 1, 0]));
        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::FROZEN, "Frozen", [Effect::SLOWNESS], [10], [0.1]));
        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::HARDENED, "Hardened", [Effect::WEAKNESS], [60], [1], CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::POISONED, "Poisoned", [Effect::POISON], [60], [1], CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::REVULSION, "Revulsion", [Effect::NAUSEA], [20], [0], CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::DOOMED, "Doomed", [Effect::BLINDNESS, Effect::WITHER, Effect::SLOWNESS], [15, 15, 15], [1, 1, 1], CustomEnchant::RARITY_MYTHIC));

        self::registerEnchantment(new ConditionalDamageMultiplierEnchant($plugin, CustomEnchantIds::AERIAL, "Aerial", function (EntityDamageByEntityEvent $event) {
            return $event->getDamager()->isOnGround();
        }, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new ConditionalDamageMultiplierEnchant($plugin, CustomEnchantIds::CHARGE, "Charge", function (EntityDamageByEntityEvent $event) {
            return $event->getDamager()->isSprinting();
        }, CustomEnchant::RARITY_UNCOMMON));

        self::registerEnchantment(new LacedWeaponEnchant($plugin, CustomEnchantIds::BLIND, "Blind", CustomEnchant::RARITY_COMMON, [Effect::BLINDNESS], [3], [0], [1]));
        self::registerEnchantment(new LacedWeaponEnchant($plugin, CustomEnchantIds::BLOODLOST, "Bloodlost", CustomEnchant::RARITY_MYTHIC, [Effect::INSTANT_DAMAGE]));
        self::registerEnchantment(new LacedWeaponEnchant($plugin, CustomEnchantIds::CRIPPLE, "Cripple", CustomEnchant::RARITY_UNCOMMON, [Effect::NAUSEA, Effect::SLOWNESS], [50, 50], [0, 1]));
		self::registerEnchantment(new LacedWeaponEnchant($plugin, CustomEnchantIds::INFLUX, "Influx", CustomEnchant::RARITY_MYTHIC, [Effect::POISON, Effect::WITHER], [100, 100], [0, 1]));
        self::registerEnchantment(new LacedWeaponEnchant($plugin, CustomEnchantIds::POISON, "Poison", CustomEnchant::RARITY_COMMON, [Effect::POISON]));
		self::registerEnchantment(new LacedWeaponEnchant($plugin, CustomEnchantIds::SHATTERGLASS, "Shatterglass", CustomEnchant::RARITY_MYTHIC, [Effect::WITHER]));
        self::registerEnchantment(new LacedWeaponEnchant($plugin, CustomEnchantIds::WITHER, "Wither", CustomEnchant::RARITY_COMMON, [Effect::WITHER], [2], [0], [2]));

        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::AEGIS, "Aegis", 5, CustomEnchant::TYPE_ARMOR_INVENTORY, CustomEnchant::ITEM_TYPE_ARMOR, Effect::RESISTANCE, -1, 0, CustomEnchant::RARITY_COMMON));
		self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::ANGEL, "Angel", 3, CustomEnchant::TYPE_ARMOR_INVENTORY, CustomEnchant::ITEM_TYPE_ARMOR, Effect::REGENERATION, -1,0, CustomEnchant::RARITY_COMMON));
		self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::ANGELIC, "Angelic", 5, CustomEnchant::TYPE_ARMOR_INVENTORY, CustomEnchant::ITEM_TYPE_ARMOR, Effect::REGENERATION, -1,0, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::ENRAGED, "Enraged", 5, CustomEnchant::TYPE_CHESTPLATE, CustomEnchant::ITEM_TYPE_CHESTPLATE, Effect::STRENGTH, -1));
		self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::KNIGHT, "Knight", 10, CustomEnchant::TYPE_ARMOR_INVENTORY, CustomEnchant::ITEM_TYPE_ARMOR, Effect::RESISTANCE, -1, 0, CustomEnchant::RARITY_MYTHIC));
		self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::VITAMINS, "Vitamins", 1, CustomEnchant::TYPE_ARMOR_INVENTORY, CustomEnchant::ITEM_TYPE_ARMOR, Effect::SATURATION, 0, 0, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::GLOWING, "Glowing", 1, CustomEnchant::TYPE_HELMET, CustomEnchant::ITEM_TYPE_HELMET, Effect::NIGHT_VISION, 0, 0, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::HASTE, "Haste", 5, CustomEnchant::TYPE_HAND, CustomEnchant::ITEM_TYPE_TOOLS, Effect::HASTE, 0, 1, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::OBSIDIANSHIELD, "Obsidian Shield", 1, CustomEnchant::TYPE_ARMOR_INVENTORY, CustomEnchant::ITEM_TYPE_ARMOR, Effect::FIRE_RESISTANCE, 0, 0, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::OXYGENATE, "Oxygenate", 1, CustomEnchant::TYPE_HAND, CustomEnchant::ITEM_TYPE_PICKAXE, Effect::WATER_BREATHING, 0, 0, CustomEnchant::RARITY_UNCOMMON));
		self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::PANTHER, "Panther", 1, CustomEnchant::TYPE_HAND, CustomEnchant::ITEM_TYPE_PICKAXE, Effect::NIGHT_VISION, 0, 1));
		self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::RAGE, "Rage", 5, CustomEnchant::TYPE_HAND, CustomEnchant::ITEM_TYPE_WEAPON, Effect::STRENGTH, 0, 1, CustomEnchant::RARITY_UNCOMMON));
		self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::REFORGE, "Reforge", 10, CustomEnchant::TYPE_HAND, CustomEnchant::ITEM_TYPE_WEAPON, Effect::STRENGTH, 0, 1));

        self::registerEnchantment(new AntitoxinEnchant($plugin, CustomEnchantIds::ANTITOXIN, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new AutoAimEnchant($plugin, CustomEnchantIds::AUTOAIM, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new AutoRepairEnchant($plugin, CustomEnchantIds::AUTOREPAIR, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new ArmoredEnchant($plugin, CustomEnchantIds::ARMORED, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new BerserkerEnchant($plugin, CustomEnchantIds::BERSERKER));
        self::registerEnchantment(new BlessedEnchant($plugin, CustomEnchantIds::BLESSED, CustomEnchant::RARITY_UNCOMMON));
		self::registerEnchantment(new BloodBerserkEnchant($plugin, CustomEnchantIds::BLOODBERSERK, CustomEnchant::RARITY_MYTHIC));
		self::registerEnchantment(new ClarityEnchant($plugin, CustomEnchantIds::CLARITY, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new DeathbringerEnchant($plugin, CustomEnchantIds::DEATHBRINGER, CustomEnchant::RARITY_RARE));
		self::registerEnchantment(new DeathforgedEnchant($plugin, CustomEnchantIds::DEATHFORGED, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new EnergizingEnchant($plugin, CustomEnchantIds::ENERGIZING));
        self::registerEnchantment(new DrillerEnchant($plugin, CustomEnchantIds::DRILLER), CustomEnchant::RARITY_RARE);
        self::registerEnchantment(new EnlightedEnchant($plugin, CustomEnchantIds::ENLIGHTED, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new FarmerEnchant($plugin, CustomEnchantIds::FARMER, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new FertilizerEnchant($plugin, CustomEnchantIds::FERTILIZER, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new FocusedEnchant($plugin, CustomEnchantIds::FOCUSED, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new GooeyEnchant($plugin, CustomEnchantIds::GOOEY, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new HallucinationEnchant($plugin, CustomEnchantIds::HALLUCINATION, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new HarvestEnchant($plugin, CustomEnchantIds::HARVEST, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new HeavyEnchant($plugin, CustomEnchantIds::HEAVY, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new ImplantsEnchant($plugin, CustomEnchantIds::IMPLANTS, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new JackpotEnchant($plugin, CustomEnchantIds::JACKPOT, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new LifestealEnchant($plugin, CustomEnchantIds::LIFESTEAL, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new LightningEnchant($plugin, CustomEnchantIds::LIGHTNING, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new LuckyEnchant($plugin, CustomEnchantIds::LUCKY, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new LumberjackEnchant($plugin, CustomEnchantIds::LUMBERJACK, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new MeditationEnchant($plugin, CustomEnchantIds::MEDITATION, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new NourishEnchant($plugin, CustomEnchantIds::NOURISH, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new OverloadEnchant($plugin, CustomEnchantIds::OVERLOAD));
        self::registerEnchantment(new QuickeningEnchant($plugin, CustomEnchantIds::QUICKENING, CustomEnchant::RARITY_UNCOMMON));
		self::registerEnchantment(new GrindEnchant($plugin, CustomEnchantIds::GRIND, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new RadarEnchant($plugin, CustomEnchantIds::RADAR));
        self::registerEnchantment(new ReviveEnchant($plugin, CustomEnchantIds::REVIVE, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new SelfDestructEnchant($plugin, CustomEnchantIds::SELFDESTRUCT));
        self::registerEnchantment(new ShieldedEnchant($plugin, CustomEnchantIds::SHIELDED, CustomEnchant::RARITY_UNCOMMON));
		self::registerEnchantment(new SpringsEnchant($plugin, CustomEnchantIds::SPRINGS, CustomEnchant::RARITY_COMMON));
		self::registerEnchantment(new GearsEnchant($plugin, CustomEnchantIds::GEARS, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new SmeltingEnchant($plugin, CustomEnchantIds::SMELTING, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new TankEnchant($plugin, CustomEnchantIds::TANK, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new TelepathyEnchant($plugin, CustomEnchantIds::TELEPATHY, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new VampireEnchant($plugin, CustomEnchantIds::VAMPIRE, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new VolleyEnchant($plugin, CustomEnchantIds::VOLLEY, CustomEnchant::RARITY_UNCOMMON));
		self::registerEnchantment(new SpitsWebEnchant($plugin, CustomEnchantIds::SPITSWEB, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new SilenceEnchant($plugin, CustomEnchantIds::SILENCE, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new RazoredgedEnchant($plugin, CustomEnchantIds::RAZOREDGED, CustomEnchant::RARITY_MYTHIC));
		self::registerEnchantment(new DeflectEnchant($plugin, CustomEnchantIds::DEFLECT));
		self::registerEnchantment(new PainkillerEnchant($plugin, CustomEnchantIds::PAINKILLER, CustomEnchant::RARITY_RARE));
		self::registerEnchantment(new DodgeEnchant($plugin, CustomEnchantIds::DODGE, CustomEnchant::RARITY_UNCOMMON));
		self::registerEnchantment(new VoodooEnchant($plugin, CustomEnchantIds::VOODOO, CustomEnchant::RARITY_UNCOMMON));
		self::registerEnchantment(new HealingFactorEnchant($plugin, CustomEnchantIds::HEALINGFACTOR, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new EvasionEnchant($plugin, CustomEnchantIds::EVASION, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new AssassinEnchant($plugin, CustomEnchantIds::ASSASSIN, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new AngelEnchant($plugin, CustomEnchantIds::ANGEL, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new AngelicEnchant($plugin, CustomEnchantIds::ANGELIC, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new AntiKnockbackEnchant($plugin, CustomEnchantIds::ANTIKNOCKBACK, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new CloakingEnchant($plugin, CustomEnchantIds::CLOAKING, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new DefenseEnchant($plugin, CustomEnchantIds::DEFENSE, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new DemonicEnchant($plugin, CustomEnchantIds::DEMONIC, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new DiminishEnchant($plugin, CustomEnchantIds::DIMINISH, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new DisarmingProtectionEnchant($plugin, CustomEnchantIds::DISARMINGPROTECTION, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new DoomedEnchant($plugin, CustomEnchantIds::DOOMED, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new EndershiftEnchant($plugin, CustomEnchantIds::ENDERSHIFT, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new FrozenEnchant($plugin, CustomEnchantIds::FROZEN, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new MoltenEnchant($plugin, CustomEnchantIds::MOLTEN, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new ObsidianShieldEnchant($plugin, CustomEnchantIds::OBSIDIANSHIELD, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new PhoenixEnchant($plugin, CustomEnchantIds::PHOENIX, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new RemendyEnchant($plugin, CustomEnchantIds::REMENDY, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new TricksterEnchant($plugin, CustomEnchantIds::TRICKSTER, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new UnholyEnchant($plugin, CustomEnchantIds::UNHOLY, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new ValorEnchant($plugin, CustomEnchantIds::VALOR, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new VitaminsEnchant($plugin, CustomEnchantIds::VITAMINS, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new DestructionEnchant($plugin, CustomEnchantIds::DESTRUCTION, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new ResilienceEnchant($plugin, CustomEnchantIds::RESILIENCE, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new WeakeningEnchant($plugin, CustomEnchantIds::WEAKENING, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new CursedEnchant($plugin, CustomEnchantIds::CURSED, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new ObscureEnchant($plugin, CustomEnchantIds::OBSCURE, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new RagdollEnchant($plugin, CustomEnchantIds::RAGDOLL, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new ShockWaveEnchant($plugin, CustomEnchantIds::SHOCKWAVE, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new FrostWalkerEnchant($plugin, CustomEnchantIds::FROSTWALKER));
        self::registerEnchantment(new MagmaWalkerEnchant($plugin, CustomEnchantIds::MAGMAWALKER));
        self::registerEnchantment(new MetaphysicalEnchant($plugin, CustomEnchantIds::METAPHYSICAL, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new StompEnchantment($plugin, CustomEnchantIds::STOMP));
        self::registerEnchantment(new WarmerEnchant($plugin, CustomEnchantIds::WARMER, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new ReforgedEnchant($plugin, CustomEnchantIds::REFORGE, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new SoulboundEnchant($plugin, CustomEnchantIds::SOULBOUND, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new AutoSellEnchant($plugin, CustomEnchantIds::AUTOSELL, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new ExplosiveEnchant($plugin, CustomEnchantIds::EXPLOSIVE, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new HasteEnchant($plugin, CustomEnchantIds::HASTE, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new KeyPlusEnchant($plugin, CustomEnchantIds::KEYPLUS, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new MoneyFarmEnchant($plugin, CustomEnchantIds::MONEYFARM, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new PouchPlusEnchant($plugin, CustomEnchantIds::POUCHPLUS, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new BlockMasterEnchant($plugin, CustomEnchantIds::BLOCKMASTER, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new MinerLuckEnchant($plugin, CustomEnchantIds::MINERLUCK, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new BleedEnchant($plugin, CustomEnchantIds::BLEED, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new CleaveEnchant($plugin, CustomEnchantIds::CLEAVE, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new ConfusionEnchant($plugin, CustomEnchantIds::CONFUSION, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new DevourEnchant($plugin, CustomEnchantIds::DEVOUR, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new MetaphysicalEnchant($plugin, CustomEnchantIds::METAPHYSICAL, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new GenJutsuEnchant($plugin, CustomEnchantIds::GENJUTSU, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new HellForgeEnchant($plugin, CustomEnchantIds::HELLFORGE, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new InsanityEnchant($plugin, CustomEnchantIds::INSANITY, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new PummelEnchant($plugin, CustomEnchantIds::PUMMEL, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new SoulStealEnchant($plugin, CustomEnchantIds::SOULSTEAL, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new WrathEnchant($plugin, CustomEnchantIds::WRATH, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new AerialEnchant($plugin, CustomEnchantIds::AERIAL, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new BlackOutEnchant($plugin, CustomEnchantIds::BLACKOUT, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new DeepWoundsEnchant($plugin, CustomEnchantIds::DEEPWOUNDS, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new DemiseEnchant($plugin, CustomEnchantIds::DEMISE, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new DisarmingProtectionEnchant($plugin, CustomEnchantIds::DISARMINGPROTECTION, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new DisarmorProtectionEnchant($plugin, CustomEnchantIds::DISARMORPROTECTION, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new DominateEnchant($plugin, CustomEnchantIds::DOMINATE, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new EnrageEnchant($plugin, CustomEnchantIds::ENRAGE, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new ExecuteEnchant($plugin, CustomEnchantIds::EXECUTE, CustomEnchant::RARITY_UNCOMMON)); 
        self::registerEnchantment(new FeatherWeightEnchant($plugin, CustomEnchantIds::FEATHERWEIGHT, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new FlingEnchant($plugin, CustomEnchantIds::FLING, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new GravityEnchant($plugin, CustomEnchantIds::GRAVITY, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new InquisitiveEnchant($plugin, CustomEnchantIds::INQUISITIVE, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new NeutralizeEnchant($plugin, CustomEnchantIds::NEUTRALIZE, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new OverDoseEnchant($plugin, CustomEnchantIds::OVERDOSE, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new PoisonEnchant($plugin, CustomEnchantIds::POISON, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new SharpenEnchant($plugin, CustomEnchantIds::SHARPEN, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new SkillSwipeEnchant($plugin, CustomEnchantIds::SKILLSWIPE, CustomEnchant::RARITY_RARE));
        self::registerEnchantment(new SolitudeEnchant($plugin, CustomEnchantIds::SOLITUDE, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new BombardmentEnchant($plugin, CustomEnchantIds::BOMBARDMENT));
        self::registerEnchantment(new BountyHunterEnchant($plugin, CustomEnchantIds::BOUNTYHUNTER));
        self::registerEnchantment(new GrapplingEnchant($plugin, CustomEnchantIds::GRAPPLING));
        self::registerEnchantment(new HeadhunterEnchant($plugin, CustomEnchantIds::HEADHUNTER));
        self::registerEnchantment(new HealingEnchant($plugin, CustomEnchantIds::HEALING));
        self::registerEnchantment(new MissileEnchant($plugin, CustomEnchantIds::MISSILE));
        self::registerEnchantment(new MolotovEnchant($plugin, CustomEnchantIds::MOLOTOV));
        self::registerEnchantment(new ParalyzeEnchant($plugin, CustomEnchantIds::PARALYZE));
        self::registerEnchantment(new PiercingEnchant($plugin, CustomEnchantIds::PIERCING));
        self::registerEnchantment(new ShuffleEnchant($plugin, CustomEnchantIds::SHUFFLE));
    }

    /**
     * @return PiggyCustomEnchants
     */
    public static function getPlugin(): PiggyCustomEnchants
    {
        return self::$plugin;
    }

    /**
     * @param CustomEnchant $enchant
     */
    public static function registerEnchantment(CustomEnchant $enchant): void
    {
        Enchantment::registerEnchantment($enchant);
        /** @var CustomEnchant $enchant */
        $enchant = Enchantment::getEnchantment($enchant->getId());
        self::$enchants[$enchant->getId()] = $enchant;

        self::$plugin->getLogger()->debug("Custom Enchantment '" . $enchant->getName() . "' registered with id " . $enchant->getId());
    }

    /**
     * @param int|Enchantment $id
     * @throws ReflectionException
     */
    public static function unregisterEnchantment($id): void
    {
        $id = $id instanceof Enchantment ? $id->getId() : $id;
        self::$enchants[$id]->unregister();
        self::$plugin->getLogger()->debug("Custom Enchantment '" . self::$enchants[$id]->getName() . "' unregistered with id " . self::$enchants[$id]->getId());
        unset(self::$enchants[$id]);

        $property = new ReflectionProperty(Enchantment::class, "enchantments");
        $property->setAccessible(true);
        $value = $property->getValue();
        unset($value[$id]);
        $property->setValue($value);
    }

    /**
     * @return CustomEnchant[]
     */
    public static function getEnchantments(): array
    {
        return self::$enchants;
    }

    /**
     * @param int $id
     * @return CustomEnchant|null
     */
    public static function getEnchantment(int $id): ?CustomEnchant
    {
        return self::$enchants[$id] ?? null;
    }

    /**
     * @param string $name
     * @return CustomEnchant|null
     */
    public static function getEnchantmentByName(string $name): ?CustomEnchant
    {
        foreach (self::$enchants as $enchant) {
            if (
                strtolower(str_replace(" ", "", $enchant->getName())) === strtolower(str_replace(" ", "", $name)) ||
                strtolower(str_replace(" ", "", $enchant->getDisplayName())) === strtolower(str_replace(" ", "", $name))
            ) return $enchant;
        }
        return null;
    }
}
