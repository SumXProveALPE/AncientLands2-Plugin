<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\tools\axes;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use DaPigGuy\PiggyCustomEnchants\utils\Utils;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\item\Axe;
use pocketmine\Player;

class InsanityEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Insanity";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_RARE;
    /** @var int */
    public $maxLevel = 8;

    /** @var int */
    
    public function getDefaultExtraData(): array
    {
        return ["base" => 6, "multiplier" => 0.1];
    }


    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $entity = $event->getEntity();
            if ($entity instanceof Player) {
                $damager = $event->getDamager();
                if ($damager instanceof Player) {
                    if ($damager->getInventory()->getItemInHand() instanceof Axe) {
                        $event->setModifier($this->extraData["base"] + $level * $this->extraData["multiplier"], CustomEnchantIds::INSANITY);
                    }
                }
            }
        }
    }

    public function getItemType(): int
    {
        return CustomEnchant::ITEM_TYPE_AXE;
    }
}
