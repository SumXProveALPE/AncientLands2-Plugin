<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\tools\axes;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use DaPigGuy\PiggyCustomEnchants\PiggyCustomEnchants;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use ReflectionException;



class PummelEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Pummel";
    /** @var int */
    public $cooldownDuration = 66;
    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_AXE;

    public function getReagent(): array
    {
        return [EntityDamageEvent::class];
    }

    public function getDefaultExtraData(): array
    {
        return ["speedDurationMultiplier" => 0.1, "speedBaseAmplifier" => 0.3, "speedAmplifierMultiplier" => 0.1, "strengthDurationMultiplier" => 0.1, "strengthBaseAmplifier" => 0.3, "strengthAmplifierMultiplier" => 0.1];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageEvent) {
			$entity = $event->getEntity();
            if (!$entity->hasEffect(Effect::SLOWNESS)) {
$durationMultiplier = 1;
$amplifierMultiplier = 2;
$baseAmplifier = 2;
$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::SLOWNESS), $durationMultiplier * $level, $level * $amplifierMultiplier + $baseAmplifier, false));
				}
				$player->sendMessage("§eYou have pummeled enemy");
				}
if (!($event->getEntity() instanceof Player)) { # If damaged entity is NOT player
    return; # Cancel the function execution
}
$event->getEntity()->sendMessage("§cThe Enemy Has Pummeled You");
	}
}