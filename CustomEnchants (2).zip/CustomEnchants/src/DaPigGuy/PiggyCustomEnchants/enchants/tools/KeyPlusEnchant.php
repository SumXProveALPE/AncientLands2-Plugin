<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\tools;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\command\ConsoleCommandSender;

/**
 * Class QuickeningEnchant
 * @package DaPigGuy\PiggyCustomEnchants\enchants\tools
 */
class KeyPlusEnchant extends BlockBreakingEnchant
{
    /** @var string */
    public $name = "KeyPlus";
    
    public $maxLevel = 10;
	

    /**
     * @return array
     */
    public function getReagent(): array
    {
        return [BlockBreakEvent::class];
    }


    /**
     * @return array
     */
    public function getDefaultExtraData(): array
    {
        return ["duration" => 40, "baseAmplifier" => 5, "amplifierMultiplier" => 5];
    }

    /**
     * @param Player $player
     * @param Item $item
     * @param Inventory $inventory
     * @param int $slot
     * @param Event $event
     * @param int $level
     * @param int $stack
     */
    public function breakBlocks(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof BlockBreakEvent) {
            if ($player->getCurrentTotalXp()) {
                $this->console = new ConsoleCommandSender();
                if(mt_rand(0, 215) < 5) {
                   switch(mt_rand(0, 7)) {
				       case 1: 
				       $this->plugin->getServer()->dispatchCommand($this->console, 'crate Common 1 ' . $player->getName());	
				       break;
				       case 2: 
				       $this->plugin->getServer()->dispatchCommand($this->console, 'crate Rare 1 ' . $player->getName());	
				       break;
				       case 3: 
				       $this->plugin->getServer()->dispatchCommand($this->console, 'crate Legendary 1 ' . $player->getName());	
				       break;
                       case 7:
                       case 4:
				       $player->sendMessage("§a§l(!) §r§aAwww, You found a Brokey Common key, try mining again..");
				       break;	
				       case 5: 
				       $player->sendMessage("§a§l(!) §r§aAwww, You found a Brokey Legendary key, try mining again..");	
				       break;			
				       case 6: 
				       $player->sendMessage("§a§l(!) §r§aAwww, You found a Brokey Rare key, try mining again..");
				       break;
                   }
				}					
            }
        }
    }

    /**
     * @return int
     */
    public function getItemType(): int
    {
        return CustomEnchant::ITEM_TYPE_TOOLS;
    }
}