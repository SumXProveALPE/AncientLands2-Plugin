<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\armor;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;

class AngelicEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Angelic";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_RARE;

    /** @var int */
    public $usageType = CustomEnchant::TYPE_ARMOR_INVENTORY;
    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_ARMOR;

    public function getDefaultExtraData(): array
    {
        return ["durationMultiplier" => 60, "baseAmplifier" => 0, "amplifierMultiplier" => 1];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            			$entity = $event->getEntity();
			if (!$entity->hasEffect(Effect::REGENERATION)) {
	$durationMultiplier = 3;
	$amplifierMultiplier = 4;
	$baseAmplifier = 10;
    $cooldown = 50;
	$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), $durationMultiplier * $level, $level * $amplifierMultiplier + $baseAmplifier, false));
				}
		$player->sendMessage("Angelic is healing you");
   		 	}
  		}	
	
	/**
     * @return int
     */
	public function getUsageType(): int
    {
        return CustomEnchant::TYPE_ARMOR_INVENTORY;
    }

    /**
     * @return int
     */
    public function getItemType(): int
    {
        return CustomEnchant::ITEM_TYPE_ARMOR;
   	}
}