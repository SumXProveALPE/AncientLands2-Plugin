<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\armor;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;

class UnholyEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Unholy";
    /** @var int */
    public $cooldownDuration = 20;
    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_ARMOR;
	/** @var int */
    public $usageType = CustomEnchant::TYPE_ARMOR_INVENTORY;

    public function getDefaultExtraData(): array
    {
        return ["speedDurationMultiplier" => 200, "speedBaseAmplifier" => 3, "speedAmplifierMultiplier" => 1, "strengthDurationMultiplier" => 200, "strengthBaseAmplifier" => 3, "strengthAmplifierMultiplier" => 1];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
			$damager = $event->getDamager();
			if (!$damager->hasEffect(Effect::WEAKNESS)) {
				$effect = new EffectInstance(Effect::getEffect(Effect::WEAKNESS), $this->extraData["speedDurationMultiplier"] * $level, $level * $this->extraData["speedAmplifierMultiplier"] + $this->extraData["speedBaseAmplifier"], false);
				$damager->addEffect($effect);
			}
			if (!$damager->hasEffect(Effect::WITHER)) {
				$effect = new EffectInstance(Effect::getEffect(Effect::WITHER), $this->extraData["speedDurationMultiplier"] * $level, $level * $this->extraData["speedAmplifierMultiplier"] + $this->extraData["speedBaseAmplifier"], false);
				$damager->addEffect($effect);
			}
			$player->sendMessage("§a§l*** §e§lUnholy §a§l***");
			if (!($damager instanceof Player)) {
				return;
			}
			$damager->sendMessage("§c§l*** §e§lUnholy §c§l***");
			return;
        }
    }
	
	/**
     * @return int
     */
	public function getUsageType(): int
    {
        return CustomEnchant::TYPE_ARMOR_INVENTORY;
    }

    /**
     * @return int
     */
    public function getItemType(): int
    {
        return CustomEnchant::ITEM_TYPE_ARMOR;
    }
}