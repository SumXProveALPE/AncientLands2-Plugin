<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\armor;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\utils\Utils;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class HealingFactorEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Healing Factor";
    
    /** @var int */
    public $rarity = CustomEnchant::RARITY_UNCOMMON;
    /** @var int */
    public $maxLevel = 5;

    public function getReagent(): array
    {
        return [EntityDamageEvent::class];
    }

    public function getDefaultExtraData(): array
    {
        return ["cooldown" => 300, "resistanceDurationMultiplier" => 60, "resistanceBaseAmplifier" => 2, "resistanceAmplifierMultiplier" => 1];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageEvent) {
            if ($player->getHealth() - $event->getFinalDamage() <= 4) {
                if (!$player->hasEffect(Effect::REGENERATION)) {
                    $effect = new EffectInstance(Effect::getEffect(Effect::REGENERATION), $this->extraData["resistanceDurationMultiplier"] * $level, $level * $this->extraData["resistanceAmplifierMultiplier"] + $this->extraData["resistanceBaseAmplifier"], false);
                    $player->addEffect($effect);
                    $this->setCooldown($player, $this->extraData["cooldown"]);
                    $player->sendMessage("§r§a§l(!) §r§eHealing Factor: §aYour Healing Factor enchant activated");
                }
            }
        }
    }

    public function getUsageType(): int
    {
        return CustomEnchant::TYPE_ARMOR_INVENTORY;
    }

    /**
     * @return int
     */
    public function getItemType(): int
    {
        return CustomEnchant::ITEM_TYPE_ARMOR;
    }
}
