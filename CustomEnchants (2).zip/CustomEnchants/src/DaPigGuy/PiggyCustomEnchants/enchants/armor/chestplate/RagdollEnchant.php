<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\armor\chestplate;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;

class RagdollEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Ragdoll";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_COMMON;

    /** @var int */
    public $usageType = CustomEnchant::TYPE_CHESTPLATE;
    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_CHESTPLATE;

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
			$entity = $event->getEntity();
			$durationMultiplier = 3;
			$amplifierMultiplier = 3;
			$baseAmplifier = 4;
			$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::LEVITATION), $durationMultiplier * $level, $level * $amplifierMultiplier + $baseAmplifier, false));
			}
			$player->sendMessage("§bPushed The Enemy!");
			$event->getEntity()->sendMessage("§cThe Enemy Has Pushed You! §8(§7RAGDOLL§8)");
        }
	
	/**
     * @return int
     */
	public function getUsageType(): int
    {
        return CustomEnchant::TYPE_ARMOR_INVENTORY;
    }

    /**
     * @return int
     */
    public function getItemType(): int
    {
        return CustomEnchant::ITEM_TYPE_ARMOR;
    }
}