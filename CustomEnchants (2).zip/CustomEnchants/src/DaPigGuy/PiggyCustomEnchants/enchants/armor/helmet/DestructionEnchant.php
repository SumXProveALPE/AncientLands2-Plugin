<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\armor\helmet;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\entity\Effect;

class DestructionEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Destruction";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_RARE;
    /** @var int */
    public $maxLevel = 5;
    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_HELMET;

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageEvent) {
			$entity = $event->getEntity();
			if ($entity instanceof Living) {
				$event->getEntity()->removeEffect(Effect::STRENGTH);
				$event->getEntity()->removeEffect(Effect::SPEED);
				$event->getEntity()->removeEffect(Effect::JUMP_BOOST);
		}
		$player->sendMessage("§r§a§l*** §r§6§lDestruction §r§a§l***");
		}
if (!($event->getEntity() instanceof Player)) { # If damaged entity is NOT player
    return; # Cancel the function execution
}
$event->getEntity()->sendMessage("§r§c§l*** §r§6§lDestruction §r§c§l***");
	}
}