<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants;

/**
 * Class CustomEnchantIds
 * @package DaPigGuy\PiggyCustomEnchants\enchants
 */
class CustomEnchantIds
{
    /**
     * Global
     */
    const AUTOREPAIR = 100;
    const SOULBOUND = 101;

    /**
     * Weapons
     */
    const SILENCE = 290;
    const AERIAL = 102;
    const ASSASSIN = 104;
    const BLACKOUT = 105;
    const BLESSED = 107;
    const BLIND = 108;
    const CONDITIONALDAMAGEMULTIPLIER = 109;
    const CHARGE = 110;
    const CRIPPLE = 111;
    const DEATHBRINGER = 112;
    const DEMISE = 113;
    const DOOMED = 114;
    const DEEPWOUNDS = 115;
    const DISARMING = 116;
    const DISARMINGPROTECTION = 117;
    const DISARMOR = 118;
    const DOMINATE = 119;
    const ENRAGE = 120;
    const EXECUTE = 121;
    const LUCKY = 122;
    const LACEDWEAPON = 123;
    const FEATHERWEIGHT = 124;
    const FLING = 125;
    const FREEZE = 126;
    const GOOEY = 127;
    const GRAVITY = 128;
    const INQUISITIVE = 129;
    const NEUTRALIZE = 130;
    const SHARPEN = 131;
    const SKILLSWIPE = 132;
    const HALLUCINATION = 133;
    const HEADLESS = 134;
    const ICEASPECT = 135;
    const LIFESTEAL = 136;
    const LIGHTNING = 137;
    const POISON = 138;
    const VAMPIRE = 139;
    const WITHER = 140;
	const RAGE = 141;
	const BLOODLOST = 142;
	const SHATTERGLASS = 143;
	const INFLUX = 144;
	const REFORGE = 145;
	const DEATHFORGED = 146;
	const SPITSWEB = 147;
	const INSANITY = 148;
    const RAZOREDGED = 149;

    /**
     * Sword
     */

    /**
     * Bows
     */
    const AUTOAIM = 150;
    const BLAZE = 151;
    const BOMBARDMENT = 152;
    const BOUNTYHUNTER = 153;
    const FIREWORK = 154;
    const GRAPPLING = 155;
    const HEADHUNTER = 156;
    const HEALING = 157;
    const HOMING = 158;
    const MISSILE = 159;
    const MOLOTOV = 160;
    const PARALYZE = 161;
    const PIERCING = 162;
    const PORKIFIED = 163;
    const SHUFFLE = 164;
    const VOLLEY = 165;
    const WITHERSKULL = 166;

    /**
     * Tools
     */
    const DRILLER = 167;
    const ENERGIZING = 168;
    const EXPLOSIVE = 169;
    const HASTE = 170;
    const JACKPOT = 171;
    const OXYGENATE = 172;
    const QUICKENING = 173;
    const SMELTING = 174;
    const TELEPATHY = 175;
	const PANTHER = 176;
	const GRIND = 177;
	const RAGESFORTUNE = 178;
	const WOVENSHACK = 179;

    /**
     * Pickaxes
     */

    /**
     * Axes
     */
    const LUMBERJACK = 180;

    /**
     * Shovels
     */

    /**
     * Hoes
     */
    const FARMER = 181;
    const FERTILIZER = 182;
    const HARVEST = 183;

    /**
     * Armor
     */
	const ADRENALINE = 184;
	const DEFLECT = 185;
    const PAINKILLER = 186;
    const DODGE = 187;
	const VOODOO = 188;
    const HEALINGFACTOR = 189;
    const MOLTEN = 190;
    const ENLIGHTED = 191;
    const HARDENED = 192;
    const POISONED = 193;
    const FROZEN = 194;
    const OBSIDIANSHIELD = 195;
    const REVULSION = 196;
    const SELFDESTRUCT = 197;
    const CURSED = 198;
    const ENDERSHIFT = 199;
    const DRUNK = 200;
    const BERSERKER = 201;
    const CLOAKING = 202;
    const REVIVE = 203;
    const SHRINK = 204;
    const GROW = 205;
    const EVASION = 206;
    const CACTUS = 207;
    const ANTIKNOCKBACK = 208;
    const FORCEFIELD = 209;
    const OVERLOAD = 210;
    const ARMORED = 211;
    const TANK = 212;
    const HEAVY = 213;
    const SHIELDED = 214;
    const POISONOUSCLOUD = 215;
	const AEGIS = 216;
	const ANGEL = 217;
	const VITAMINS = 218;
	const KNIGHT = 219;
	const BLOODBERSERK = 220;

    /**
     * Helmet
     */
    const ANTITOXIN = 221;
    const FOCUSED = 222;
    const GLOWING = 223;
    const IMPLANTS = 224;
    const MEDITATION = 225;
	const NOURISH = 226;
    const CLARITY = 227;
	const IMFASTAFBOI = 228;

    /**
     * Chestplate
     */
    const CHICKEN = 229;
    const ENRAGED = 230;
    const PARACHUTE = 231;
    const PROWL = 232;
    const SPIDER = 233;
    const VACUUM = 234;

    /**
     * Leggings
     */

    /**
     * Boots
     */
    const GEARS = 235;
    const JETPACK = 236;
    const MAGMAWALKER = 237;
    const SPRINGS = 238;
    const STOMP = 239;

    /**
     * Compass
     */
    const RADAR = 240;

    // To sort
    const ANGELIC = 241;
    const REMENDY = 242;
    const DEFENSE = 243;
    const DEMONIC = 244;
    const DIMINISH  = 245;
    const PHOENIX = 246;
    const TRICKSTER = 247;
    const UNHOLY = 248;
    const VALOR = 249;
    const DESTRUCTION = 250;
    const RESILIENCE = 251;
    const WEAKENING = 252;
    const OBSCURE = 253;
    const RAGDOLL = 254;
    const SHOCKWAVE = 255;
    const FROSTWALKER = 256;
    const METAPHYSICAL = 257;
    const WARMER = 258;
    const AUTOSELL = 259;
    const KEYPLUS = 300;
    const MONEYFARM = 301;
    const POUCHPLUS  = 302;
    const BLOCKMASTER = 303;
    const MINERLUCK = 304;
    const BLEED = 305;
    const CLEAVE = 306;
    const CONFUSION = 307;
    const DEVOUR = 308;
    const GENJUTSU = 260;
    const HELLFORGE = 261;
    const LOTUS = 262;
    const PUMMEL = 263;
    const SOULSTEAL = 264;
    const WRATH = 265;
    const DISARMORPROTECTION = 266;
    const DSRSTAFF = 267;
    const OVERDOSE = 268;
    const SOLITUDE = 269;
}