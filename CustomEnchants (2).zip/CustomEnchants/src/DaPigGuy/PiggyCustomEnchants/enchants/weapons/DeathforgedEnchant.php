<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;

/**
 * Class Deathforged
 * @package DaPigGuy\PiggyCustomEnchants\enchants\weapons
 */
class DeathforgedEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Deathforged";
    
    public $maxLevel = 10;

    /**
     * @return array
     */
    public function getDefaultExtraData(): array
    {
        return ["cooldown" => 60, "base" => 5, "multiplier" => 0.1];
    }
    
    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $cost = 10000;
			if ($player->getCurrentTotalXp() - $cost < 0) {
			    $player->sendPopup("§cYour Deathforged Enchant Didn't work, you need §6" . $cost . " EXP");
			} else {     
			    $event->setModifier($this->extraData["base"] + $level * $this->extraData["multiplier"], CustomEnchantIds::DEATHFORGED);
			    $player->addTitle("§a§l", "§r§6You activated Deathforged to§e " . $event->getEntity()->getName() . "§6!", 10, 10, 10);
                $player->subtractXp($cost);
                $this->setCooldown($player, $this->extraData["cooldown"]);
			}
        }
    }

    public function getItemType(): int
    {
        return CustomEnchant::ITEM_TYPE_SWORD;
    }
}