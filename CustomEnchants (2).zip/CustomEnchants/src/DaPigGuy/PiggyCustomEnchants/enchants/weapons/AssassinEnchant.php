<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;
use DaPigGuy\PiggyCustomEnchants\utils\Utils;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Axe;
use pocketmine\item\Item;
use pocketmine\item\Sword;
use pocketmine\Player;

class AssassinEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Assassin";
    
    /** @var int */
    public $rarity = CustomEnchant::RARITY_RARE;
    /** @var int */
    public $maxLevel = 8;
    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_SWORD;

    public function getDefaultExtraData(): array
    {
        return ["base" => 4, "multiplier" => 0.1];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Player) {
                $entity = $event->getEntity();
                if ($entity instanceof Player) {
                    if ($damager->getInventory()->getItemInHand() instanceof Axe) {
                        $event->setModifier($this->extraData["base"] + $level * $this->extraData["multiplier"], CustomEnchantIds::ASSASSIN);
                $player->sendMessage("§a§l*** §6§lAssassin §a§l***");
		    	}
				if (!($event->getEntity() instanceof Player)) { # If damaged entity is NOT player
    				return; # Cancel the function execution
				}
				$event->getEntity()->sendMessage("§c§l*** §6§lAssassin §c§l***");
                    }
               }
          }
     }
}
