<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\PiggyCustomEnchants;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use ReflectionException;

class FreezeEnchant extends ReactiveEnchantment
{
    /** @var array */
    private $effectIds = [Effect::SLOWNESS];
    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_SWORD;
    /** @var array */
    private $baseDuration = [0];
    /** @var array */
    private $baseAmplifier = [0];
    /** @var int[] */
    private $durationMultiplier = [10];
    /** @var int[] */
    private $amplifierMultiplier = [1];

    /**
     * @throws ReflectionException
     */
    public function __construct(PiggyCustomEnchants $plugin, int $id, string $name, int $rarity = self::RARITY_COMMON, array $effectIds = [Effect::SLOWNESS], array $durationMultiplier = [10], array $amplifierMultiplier = [.01], array $baseDuration = [0], array $baseAmplifier = [0])
    {
        $this->name = $name;
        $this->effectIds = $effectIds;
        $this->durationMultiplier = $durationMultiplier;
        $this->amplifierMultiplier = $amplifierMultiplier;
        $this->baseDuration = $baseDuration;
        $this->baseAmplifier = $baseAmplifier;
        parent::__construct($plugin, $id);
    }

    public function getDefaultExtraData(): array
    {
        return ["durationMultiplier" => $this->durationMultiplier, "amplifierMultiplier" => $this->amplifierMultiplier, "baseDuration" => $this->baseDuration, "baseAmplifier" => $this->baseAmplifier];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $entity = $event->getEntity();
            if ($entity instanceof Living) {
                $entities = $player->getLevel()->getNearbyEntities($player->getBoundingBox()->expandedCopy(10, 10, 10), $player);
                foreach ($entities as $entity) {
					foreach ($this->effectIds as $key => $effectId) {
						$entity->addEffect(new EffectInstance(Effect::getEffect($effectId), ($this->extraData["baseDuration"][$key] ?? 0) + ($this->extraData["durationMultiplier"][$key] ?? 10) * $level, ($this->extraData["baseAphlifier"][$key] ?? 0) + ($this->extraData["aphlifierMultiplier"][$key] ?? 1) * $level));
					}
					$player->sendMessage("§a Freeze has Activated");
		            }
if (!($event->getEntity() instanceof Player)) { # If damaged entity is NOT player
    return; # Cancel the function execution
}
$event->getEntity()->sendMessage("§cFreeze has Activated!");
			}
		}
	}
}