<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use DaPigGuy\PiggyCustomEnchants\utils\Utils;
use pocketmine\block\Block;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\nbt\NetworkLittleEndianNBTStream;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\mcpe\protocol\BlockActorDataPacket;
use pocketmine\Player;
use pocketmine\scheduler\ClosureTask;
use pocketmine\tile\Tile;
use pocketmine\utils\TextFormat;

class SpitsWebEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Spits Web";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_MYTHIC;
    /** @var int */
    public $maxLevel = 5;
    /** @var int */

    /** @var array */
    public static $hallucinating;

    public function getDefaultExtraData(): array
    {
        return ["cooldown" => 60];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            $cost = 20000;
            $exp = $player->getCurrentTotalXp();
			if ($player->getCurrentTotalXp() - $cost < 0) {
			    $player->sendPopup("§cYour Spits Web Enchant Didn't work, you need §6" . $cost . " EXP");
			} else {  
			    if ($damager instanceof Player) {
			        if ($damager->getInventory()->getItemInHand()->hasEnchantment(333)) {
			            $player->sendMessage("§a§l(!)§r §bSpits Web: §r§eYour Spits Web Activated");
                        $player->sendMessage("§l§a(!) §r§eCooldown: §a60 Seconds");
                        $player->sendMessage("§l§a(!) §r§eRemaining EXP: §a" . number_format($exp));
                        $player->subtractXp($cost);
			            $entity = $event->getEntity();
			            if ($entity instanceof Player && !isset(self::$hallucinating[$entity->getName()])) {
			                $this->setCooldown($player, $this->extraData["cooldown"]);
			                $originalPosition = $entity->getPosition();
			                self::$hallucinating[$entity->getName()] = true;
			                $this->plugin->getScheduler()->scheduleRepeatingTask(($task = new ClosureTask(function () use ($entity, $originalPosition): void {
			                    for ($x = $originalPosition->x - 1; $x <= $originalPosition->x + 1; $x++) {
			                        for ($y = $originalPosition->y - 0; $y <= $originalPosition->y + 0; $y++) {
			                            for ($z = $originalPosition->z - 1; $z <= $originalPosition->z + 1; $z++) {
			                                $position = new Position($x, $y, $z, $originalPosition->getLevel());
			                                $block = Block::get(Block::COBWEB, 0, $position);
			                                $position->getLevel()->sendBlocks([$entity], [$block]);
			                            }
                                    }
                                }
                            })), 1);
                            $this->plugin->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($originalPosition, $entity, $task): void {
                                $task->getHandler()->cancel();
                                for ($y = -1; $y <= 3; $y++) {
                                    $startBlock = $originalPosition->getLevel()->getBlock($originalPosition->add(0, $y));
                                    $originalPosition->getLevel()->sendBlocks([$entity], array_merge([$startBlock], $startBlock->getHorizontalSides(), [
                                        $startBlock->getSide(Vector3::SIDE_NORTH)->getSide(Vector3::SIDE_EAST),
                                        $startBlock->getSide(Vector3::SIDE_NORTH)->getSide(Vector3::SIDE_WEST),
                                        $startBlock->getSide(Vector3::SIDE_SOUTH)->getSide(Vector3::SIDE_EAST),
                                        $startBlock->getSide(Vector3::SIDE_SOUTH)->getSide(Vector3::SIDE_WEST)
                                    ]));
								}
								unset(self::$hallucinating[$entity->getName()]);
							}), 10 * 8);	
						}
					}
				}
			}
		}
	}
}



