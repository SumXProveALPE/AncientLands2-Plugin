<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\Player;

class DisarmingEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Disarming";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_UNCOMMON;
    public static $disarming = [];

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $entity = $event->getEntity();
            if ($entity instanceof Player) {
                if($entity->getInventory()->getItemInHand()->getId() !== ItemIds::AIR){
                    foreach($entity->getInventory()->getContents() as $item){
                        if($item->hasEnchantment(CustomEnchantIds::DISARMING_PROTECT)){
                            $entity->sendMessage("(!) You got disarming protection!");
                            return;
                        }
                    }
                    $entity->dropItem($entity->getInventory()->getItemInHand());
                    $entity->getInventory()->setItemInHand(ItemFactory::get(ItemIds::AIR));
                }
            }
        }
    }

}