<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\Player;

class DisarmorEnchant extends DisarmingEnchant
{
    public static $disarmored = [];
    /** @var string */
    public $name = "Disarmor";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_UNCOMMON;

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $entity = $event->getEntity();
            if ($entity instanceof Player) {
                if (count($armorContents = $entity->getArmorInventory()->getContents(false)) > 0) {
                    $item = $armorContents[array_rand($armorContents)];
                    foreach($armorContents as $item){
                        if($item->hasEnchantment(CustomEnchantIds::DISARMOR_PROTECT)){
                            $entity->sendMessage("(!) You got disarmor protection!");
                            return;
                        }
                    }
                    $entity->getArmorInventory()->removeItem($item);
                    $entity->dropItem($item);
                }
            }
        }
    }
}