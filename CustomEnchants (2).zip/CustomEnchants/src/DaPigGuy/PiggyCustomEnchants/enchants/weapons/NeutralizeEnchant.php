<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\entity\Effect;

class NeutralizeEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Neutralize";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_MYTHIC;
    /** @var int */
    public $maxLevel = 4;
    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_SWORD;

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
      	    $cooldown = 300; # Cooldown before another activation
			$event->getEntity()->removeEffect(Effect::RESISTANCE);
			$event->getEntity()->removeEffect(Effect::SATURATION);
			$event->getEntity()->removeEffect(Effect::ABSORPTION);
			$event->getEntity()->removeEffect(Effect::SPEED);
			$event->getEntity()->removeEffect(Effect::JUMP_BOOST);
			$event->getEntity()->removeEffect(Effect::NIGHT_VISION);
			$event->getEntity()->removeEffect(Effect::HEALTH_BOOST);
			$event->getEntity()->removeEffect(Effect::STRENGTH);
		}
		$player->sendMessage("§aNeutralized Enemy Buffs");
if (!($event->getEntity() instanceof Player)) { # If damaged entity is NOT player
    return; # Cancel the function execution
}
$event->getEntity()->sendMessage("§cYou have been Neutralized");
	}
}
