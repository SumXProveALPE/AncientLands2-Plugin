<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;

class GravityEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Gravity";
    /** @var int */
    public $cooldownDuration = 20;
    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_SWORD;

    public function getReagent(): array
    {
        return [EntityDamageEvent::class];
    }

    public function getDefaultExtraData(): array
    {
        return ["speedDurationMultiplier" => 200, "speedBaseAmplifier" => 3, "speedAmplifierMultiplier" => 1, "strengthDurationMultiplier" => 200, "strengthBaseAmplifier" => 3, "strengthAmplifierMultiplier" => 1];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $entity = $event->getEntity();
            if($entity instanceof Living) {
                if (!$entity->hasEffect(Effect::LEVITATION)) {
                    $effect = new EffectInstance(Effect::getEffect(Effect::LEVITATION), 2, 2, false);
                    $entity->addEffect($effect);
                $this->setCooldown($player, $this->extraData["cooldown"]);
                }
                $player->sendMessage("§a§l*** §6§lGravity §a§l***");

                $entity = $event->getEntity();
                if($entity instanceof Player){
                    $entity->sendMessage("§c§l*** §6§lGravity §c§l***");
                }

            }
        }
    }
}