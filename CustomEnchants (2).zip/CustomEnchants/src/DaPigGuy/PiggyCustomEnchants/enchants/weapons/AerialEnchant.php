<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;

class AerialEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Aerial";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_COMMON;
    /** @var int */
    public $maxLevel = 5;
    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_SWORD;
    /** @var int */
    public $time = 5;

    public function getDefaultExtraData(): array
    {
        return ["duration" => 5];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            $enchantment = $damager->getInventory()->getItemInHand()->getEnchantment(CustomEnchantIds::AERIAL);
            if ($enchantment !== null) {
                if (!$damager->isOnGround()) {
                    $event->setBaseDamage($event->getBaseDamage() * (1 + 0.10 * $enchantment->getLevel()));
                }
                $player->sendMessage("§a§l*** §b§lAerial §a§l***");
                }
if (!($event->getEntity() instanceof Player)) { # If damaged entity is NOT player
    return; # Cancel the function execution
}
$event->getEntity()->sendMessage("§c§l*** §b§lAerial §c§l***");
        }
    }
}