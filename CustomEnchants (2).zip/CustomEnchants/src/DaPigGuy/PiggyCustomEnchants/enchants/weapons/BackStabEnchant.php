<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;
use DaPigGuy\PiggyCustomEnchants\utils\Utils;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;

class BackStabEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "BackStab";

    /** @var int */
    public $rarity = CustomEnchant::RARITY_COMMON;
    /** @var int */
    public $maxLevel = 10;

    public function getDefaultExtraData(): array
    {
        return ["base" => 2, "multiplier" => 0.1];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            $entity = $event->getEntity();
            if ($enchantment !== null) {
                if ($damager->getDirectionVector()->dot($entity->getDirectionVector()) > 0) {
                    $event->setBaseDamage($event->getBaseDamage() * (1 + 0.10 * $enchantment->getLevel()));
                }
            }
        }
    }


    public function getItemType(): int
    {
        return CustomEnchant::ITEM_TYPE_SWORD;
    }
}

