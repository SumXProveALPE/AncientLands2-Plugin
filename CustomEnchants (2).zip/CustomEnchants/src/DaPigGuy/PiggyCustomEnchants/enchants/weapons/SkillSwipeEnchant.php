<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\entity\Effect;
use pocketmine\entity;

class SkillSwipeEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Skill Swipe";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_UNCOMMON;
    /** @var int */
    public $maxLevel = 3;
    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_SWORD;

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $entity = $event->getEntity();
if (!($event->getEntity() instanceof Player)) { # If damaged entity is NOT player
    return; # Cancel the function execution
}
			if ($entity instanceof Living) {
		      	if ($entity->getXpLevel() >= 5) {
					$entity->setXpLevel($entity->getXpLevel() - 5);
		     	    $damager = $event->getDamager();
					if ($damager->getXpLevel() >=0) {
						$damager->setXpLevel($damager->getXpLevel() + 5);
					}
				}
			}
		}
	}
}
