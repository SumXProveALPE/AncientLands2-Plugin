<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;

/**
 * Class Deathforged
 * @package DaPigGuy\PiggyCustomEnchants\enchants\weapons
 */
class RazoredgedEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Razoredged";
    
    public $maxLevel = 3;

    /**
     * @return array
     */
    public function getDefaultExtraData(): array
    {
        return ["cooldown" => 300, "base" => 8, "multiplier" => 0.1];
    }

    public function getItemType(): int
    {
        return CustomEnchant::ITEM_TYPE_AXE;
    }
    
    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $cost = 100000;
			if ($player->getCurrentTotalXp() - $cost < 0) {
			    $player->sendPopup("§cYour Razoredged Enchant Didn't work, you need §6" . $cost . " EXP");
			} else {     
			    $event->setModifier($this->extraData["base"] + $level * $this->extraData["multiplier"], CustomEnchantIds::RAZOREDGED);
			    $player->addTitle("§a§l", "§r§6You activated Razoredged Enchant to§e " . $event->getEntity()->getName() . "§6!", 10, 10, 10);
                $player->subtractXp($cost);
                $this->setCooldown($player, $this->extraData["cooldown"]);
			}
        }
    }
}