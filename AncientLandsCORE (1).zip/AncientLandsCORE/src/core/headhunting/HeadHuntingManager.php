<?php

namespace core\headhunting;

use core\AncientLands;

# Pocketmine
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\entity\Entity;
use pocketmine\plugin\PluginBase;
use pocketmine\level\Level;
use pocketmine\utils\Config;

# Class
class HeadHuntingManager {

    private $plugin;

    public function __construct(AncientLands $plugin){
        $this->plugin = $plugin;
    }

    public function getHHLevel(Player $player){
        $this->player_file = new Config($this->plugin->getDataFolder() . "HeadHunting/" . strtolower($player->getName()), Config::YAML, array(
                "exp" => 0,
                "level" => 1
            ));
        $level = $this->player_file->get("level");
        return $level;
        }

        public function getHHEXP(Player $player){
            $this->player_file = new Config($this->plugin->getDataFolder() . "HeadHunting/" . strtolower($player->getName()), Config::YAML, array(
                "exp" => 0,
                "level" => 1
            ));
        $exp = $this->player_file->get("exp");
        return $exp;
        }

        public function getHHProgress(Player $player){
            $this->player_file = new Config($this->plugin->getDataFolder() . "HeadHunting/" . strtolower($player->getName()), Config::YAML, array(
                "exp" => 0,
                "level" => 1
            ));
        $exp = $this->player_file->get("exp");
        $level = $this->player_file->get("level");
        $levelPoint = $level * 100;
        $division = $exp / $levelPoint;
        $progress = $division * 100;
        return round($progress, 2);
        }
}