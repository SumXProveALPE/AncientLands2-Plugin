<?php

namespace core\headhunting;

use core\AncientLands;

# Pocketmine Uses
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\entity\Entity;
use pocketmine\nbt\tag\StringTag;
use pocketmine\utils\Config;

# Entities
use core\entity\types\Skeleton;
use core\entity\types\Zombie;

# HeadHunting Listener
class HeadHuntingListener implements Listener{

    private $plugin;

    public function __construct(AncientLands $plugin){
    $this->plugin->getServer()->getPluginManager()->registerEvents($this, $plugin);
    }

    public function onJoin(PlayerJoinEvent $event){
        $player = $event->getPlayer();
            $this->hh = new Config($this->getDataFolder() . "HeadHunting/" . strtolower($player->getName()), Config::YAML, array(
                "exp" => 0,
                "level" => 1
            ));
            $this->hh;
      }

    public function onEntityDeath(EntityDeathEvent $event){
        $entity = $event->getEntity();

        # Zombie
        if($entity instanceof Zombie){
            $cause = $entity->getLastDamageCause();
            if($cause instanceof EntityDamageByEntityEvent){
                $damager = $cause->getDamager();
                if($damager instanceof Player){
                    $roll = mt_rand(1, 100);
                    $percent = 15;
                    if($roll <= $percent){
                        $head = Item::get(397, 2, 1);
                        $head->setCustomName("§l§2Zombie §aHead §r§7(Bring to HeadHunter)");
                        $head->setLore(["§r§7Oh look at that... You've found a mob head! You must be lucky!",
                                        "§r§7This one seems to be a §l§2Zombie §aHead§r§7.. Anyways, bring it",
                                        "§r§7to the §l§6Head§eHunting §r§7master at spawn to claim your prize.",
                                        " ",
                                        "§r§eValue: $5,000 (per head) | 50 HeadHunting EXP",
                                        "§r§eRarity: §e§k||||"
                                      ]);
                        $head->setNamedTagEntry(new StringTag("zombiehead", "yep"));
                        $drops = array($head, Item::get(367, 0, 2));
                        $event->setDrops($drops);
                    }
                } else {
                    $roll = mt_rand(1, 100);
                    $percent = 25;
                    if($roll <= $percent){
                        $head = Item::get(397, 2, 1);
                        $head->setCustomName("§l§2Zombie §aHead §r§7(Bring to HeadHunter)");
                        $head->setLore(["§r§7Oh look at that... You've found a mob head! You must be lucky!",
                        "§r§7This one seems to be a §l§2Zombie §aHead§r§7.. Anyways, bring it",
                        "§r§7to the §l§6Head§eHunting §r§7master at spawn to claim your prize.",
                        " ",
                        "§r§eValue: $5,000 (per head) | 50 HeadHunting EXP",
                        "§r§eRarity: §e§k||||"
                                      ]);
                        $head->setNamedTagEntry(new StringTag("zombiehead", "yep")); 
                        $drops = array($head, Item::get(367, 0, 2));
                        $event->setDrops($drops);
                }
            }
        }

        # Skeleton
    } elseif($entity instanceof Skeleton){
        $cause = $entity->getLastDamageCause();
            if($cause instanceof EntityDamageByEntityEvent){
                $damager = $cause->getDamager();
                if($damager instanceof Player){
                    $roll = mt_rand(1, 100);
                    $percent = 15;
                    if($roll <= $percent){
                        $head = Item::get(397, 0, 1);
                        $head->setCustomName("§l§7Skeleton §8Head §r§7(Bring to HeadHunter)");
                        $head->setLore(["§r§7Oh look at that... You've found a mob head! You must be lucky!",
                                        "§r§7This one seems to be a §l§7Skeleton §8Head§r§7.. Anyways, bring it",
                                        "§r§7to the §l§6Head§eHunting §r§7master at spawn to claim your prize.",
                                        " ",
                                        "§r§eValue: $3,000 (per head) | 30 HeadHunting EXP",
                                        "§r§eRarity: §e§k||||"
                                      ]);
                        $head->setNamedTagEntry(new StringTag("skeletonhead", "yep"));
                        $drops = array($head, Item::get(352, 0, 2));
                        $event->setDrops($drops);
                    }
                } else {
                    $roll = mt_rand(1, 100);
                    $percent = 15;
                    if($roll <= $percent){
                        $head = Item::get(397, 0, 1);
                        $head->setCustomName("§l§7Skeleton §8Head §r§7(Bring to HeadHunter)");
                        $head->setLore(["§r§7Oh look at that... You've found a mob head! You must be lucky!",
                                        "§r§7This one seems to be a §l§7Skeleton §8Head§r§7.. Anyways, bring it",
                                        "§r§7to the §l§6Head§eHunting §r§7master at spawn to claim your prize.",
                                        " ",
                                        "§r§eValue: $3,000 (per head) | 30 HeadHunting EXP",
                                        "§r§eRarity: §e§k||||"
                                      ]);
                        $head->setNamedTagEntry(new StringTag("skeletonhead", "yep"));
                        $drops = array($head, Item::get(352, 0, 2));
                        $event->setDrops($drops);
                }
            }
        }
    }

    }
}