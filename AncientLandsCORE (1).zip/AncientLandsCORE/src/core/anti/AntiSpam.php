<?php

namespace core\anti;

use core\AncientLands;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\CommandExecutor;
use pocketmine\utils\TextFormat;
use core\anti\ProfanityFilter;
use pocketmine\event\player\PlayerCommandPreprocessEvent;

class AntiSpam implements CommandExecutor, Listener {

    private $plugin;

    private $players = [];
    public $profanityfilter;

  public function __construct(AncientLands $plugin){
  $this->plugin = $plugin;
  $this->onEnable();

  }

    public function onEnable()
    {
        $this->plugin->getServer()->getPluginManager()->registerEvents($this, $this->plugin);
        $this->plugin->saveDefaultConfig();
        if ($this->plugin->getConfig()->get("antiswearwords") || $this->plugin->getConfig()->get("antirudenames")) {
            $this->plugin->saveResource("swearwords.yml", false);
            $this->profanityfilter = new ProfanityFilter($this);
            $this->plugin->getLogger()->info(TEXTFORMAT::GREEN . "AntiSpamPro Swear Filter Enabled");
        }
    }

    public function onChat(PlayerChatEvent $e) {
        if ($e->isCancelled() || ($player = $e->getPlayer())->isClosed() || $player->hasPermission("asp.bypass")) return;
        if (isset($this->players[spl_object_hash($player)]) && (time() - $this->players[spl_object_hash($player)]["time"] <= intval($this->plugin->getConfig()->get("delay")))) {
            $this->players[spl_object_hash($player)]["time"] = time();
            $this->players[spl_object_hash($player)]["warnings"] = $this->players[spl_object_hash($player)]["warnings"] + 1;

            if ($this->players[spl_object_hash($player)]["warnings"] === $this->plugin->getConfig()->get("warnings")) {
				$player->sendMessage(TEXTFORMAT::RED . $this->plugin->getConfig()->get("lastwarning"));
                $e->setCancelled();
                return;
            }
            if ($this->players[spl_object_hash($player)]["warnings"] > $this->plugin->getConfig()->get("warnings")) {
                $e->setCancelled();

                switch (strtolower($this->plugin->getConfig()->get("action"))) {
                    case "kick":
						$player->kick($this->plugin->getConfig()->get("kickmessage"));
                        break;

                    case "ban":
						$player->setBanned(true);
                        break;

                    case "banip":

						$this->plugin->getServer()->getIPBans()->addBan($player->getAddress(), $this->plugin->getConfig()->get("banmessage"), null, $player->getName());
						$this->plugin->getServer()->getNetwork()->blockAddress($player->getAddress(), -1);
						$player->setBanned(true);

                        break;

                    default:
                        break;
                }

                return;
            }
			$player->sendMessage(TEXTFORMAT::RED . $this->plugin->getConfig()->get("message1"));
			$player->sendMessage(TEXTFORMAT::GREEN . $this->plugin->getConfig()->get("message2"));
            $e->setCancelled();
        } else {
            $this->players[spl_object_hash($player)] = array("time" => time(), "warnings" => 0);
            if ($this->plugin->getConfig()->get("antiswearwords") && $this->profanityfilter->hasProfanity($e->getMessage())) {
				$player->sendMessage(TEXTFORMAT::RED . $this->plugin->getConfig()->get("swearmessage"));
                $e->setCancelled(true);
            }
        }
    }

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool{
        if (!isset($args[0])) {
            if ($sender instanceof Player) {
                $sender->getPlayer()->sendMessage(TEXTFORMAT::GREEN . "Banmode: " . $this->plugin->getConfig()->get("action") . "  " . "Delay: " . $this->plugin->getConfig()->get("delay") . " seconds");
            } else {
                $this->plugin->getLogger()->info("Banmode: " . $this->plugin->getConfig()->get("action") . "  " . "Delay: " . $this->plugin->getConfig()->get("delay") . " seconds");
            }
            return true;
        }

        switch (strtolower($args[0])) {

            case "help":

                if ($sender instanceof Player) {
                    $sender->getPlayer()->sendMessage(TEXTFORMAT::YELLOW . $t->get("help1"));
                    $sender->getPlayer()->sendMessage(TEXTFORMAT::YELLOW . $this->plugin->getConfig()->get("help2"));
                    $sender->getPlayer()->sendMessage(TEXTFORMAT::YELLOW . $this->plugin->getConfig()->get("help3"));
                    $sender->getPlayer()->sendMessage(TEXTFORMAT::YELLOW . $this->plugin->getConfig()->get("help4"));
                } else {
                    $this->plugin->getLogger()->info($this->plugin->getConfig()->get("help1"));
                    $this->plugin->getLogger()->info($this->plugin->getConfig()->get("help2"));
                    $this->plugin->getLogger()->info($this->plugin->getConfig()->get("help3"));
                    $this->plugin->getLogger()->info($this->plugin->getConfig()->get("help4"));
                }

                return true;

            case "banip":
            case "ban":
            case "kick":
                $this->plugin->getConfig()->set("action", strtolower($args[0]));
                $this->plugin->getConfig()->save();

                if ($sender instanceof Player) {
                    $sender->getPlayer()->sendMessage(TEXTFORMAT::GREEN . $this->plugin->getConfig()->get("set" . strtolower($args[0]) . "kickmessage"));
                } else {
                    $this->plugin->getLogger()->info($this->plugin->getConfig()->get("set" . strtolower($args[0]) . "message"));
                }

                return true;


            case "set":
                if (isset($args[1]) && is_numeric($args[1]) && $args[1] <= 3 && $args[1] > 0) {
                    $this->plugin->getConfig()->set("delay", $args[1]);
                    $this->plugin->getConfig()->save();

                    if ($sender instanceof Player) {
                        $sender->getPlayer()->sendMessage(TEXTFORMAT::GREEN . $this->plugin->getConfig()->get("setdelay"));
                    } else {
                        $this->plugin->getLogger()->info($this->plugin->getConfig()->get("setdelay"));
                    }
                } else {

                    if ($sender instanceof Player) {
                        $sender->getPlayer()->sendMessage(TEXTFORMAT::RED . $this->plugin->getConfig()->get("invaliddelay"));
                    } else {
                        $this->plugin->getLogger()->info($this->plugin->getConfig()->get("invaliddelay"));
                    }
                }

                return true;

            default:
                break;
        }
        return false;
    }

    /**
     * @param PlayerCommandPreprocessEvent $event
     *
     * @priority LOWEST
     */

    public function onPlayerCommand(PlayerCommandPreprocessEvent $event) {
        if ($event->isCancelled() || $event->getPlayer()->isClosed()) return;
        if (($sender = $event->getPlayer())->hasPermission("asp.bypass")) return;
        $message = $event->getMessage();
        if ($message[0] != "/") {
            return;
        }
        if (isset($this->players[spl_object_hash($sender)]) && (time() - $this->players[spl_object_hash($sender)]["time"] <= intval($this->plugin->getConfig()->get("delay")))) {
            $this->players[spl_object_hash($sender)]["time"] = time();
            $this->players[spl_object_hash($sender)]["warnings"] = $this->players[spl_object_hash($sender)]["warnings"] + 1;

            if ($this->players[spl_object_hash($sender)]["warnings"] === $this->plugin->getConfig()->get("warnings")) {
                $sender->sendMessage(TEXTFORMAT::RED . $this->plugin->getConfig()->get("lastwarning"));
                $event->setCancelled(true);
                return;
            }
            if ($this->players[spl_object_hash($sender)]["warnings"] > $this->plugin->getConfig()->get("warnings")) {
                $event->setCancelled(true);

                switch (strtolower($this->plugin->getConfig()->get("action"))) {
                    case "kick":
                        $sender->kick($this->plugin->getConfig()->get("kickmessage"));
                        break;

                    case "ban":
                        $sender->setBanned(true);
                        break;

                    case "banip":

                        $this->plugin->getServer()->getIPBans()->addBan($sender->getAddress(), $this->plugin->getConfig()->get("banmessage"), null, $sender->getName());
                        $this->plugin->getServer()->getNetwork()->blockAddress($sender->getAddress(), -1);
                        $sender->setBanned(true);

                        break;

                    default:
                        break;
                }
                return;
            }
            $sender->sendMessage(TEXTFORMAT::RED . $this->plugin->getConfig()->get("message1"));
            $sender->sendMessage(TEXTFORMAT::GREEN . $this->plugin->getConfig()->get("message2"));
            $event->setCancelled();
        } else {
            $this->players[spl_object_hash($sender)] = array("time" => time(), "warnings" => 0);
        }
    }

    public function onQuit(PlayerQuitEvent $e)
    {
        if (isset($this->players[spl_object_hash($e->getPlayer())])) {
            unset($this->players[spl_object_hash($e->getPlayer())]);
        }
    }

    public function onLogin(PlayerLoginEvent $e)
    {
		if ($e->isCancelled() || $e->getPlayer()->isClosed()) return;
        if ($this->plugin->getConfig()->get("antirudenames") && $this->profanityfilter->hasProfanity($e->getPlayer()->getName())) {
            $e->getPlayer()->kick("No Rude Names Allowed");
            $e->setCancelled(true);
        }
    }

    public function getProfanityFilter()
    {
        return $this->profanityfilter;
    }
}
