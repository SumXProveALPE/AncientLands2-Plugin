<?php

declare(strict_types=1);

namespace core\anti;

use core\AncientLands;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\Player;

class AntiAdvertising implements Listener{

    /** @var AncientLands */
    private $plugin;
    /** @var array */
    private $links;

    public function __construct(AncientLands $plugin){
        $this->plugin = $plugin;
        $this->links = [".leet.cc", ".playmc.pe", ".net", ".com", ".us", ".us.to",".co", ".co.uk", ".ddns", ".ddns.net", ".cf", ".pe", ".me", ".cc", ".ru", ".eu", ".tk", ".gq", ".ga", ".ml", ".org", ".1", ".2", ".3", ".4", ".5", ".6", ".7", ".8", ".9", "my server", "my sever", "ma server", "mah server", "ma sever", "mah sever"];
    }

    public function onChat(PlayerChatEvent $event) : void{
        $msg = $event->getMessage();
        $player = $event->getPlayer();
        if(!$player instanceof Player) return;
        if($player->hasPermission("alpe.anti.advertise")){
        }else{
            foreach($this->links as $links){
                if(strpos($msg, $links) !== false){
                    $player->sendMessage("§l§aALPE§7Chat §a»§r §cDo not advertise, or you might get banned!");
                    $event->setCancelled();
                    return;
                }
            }
        }
    }
}
