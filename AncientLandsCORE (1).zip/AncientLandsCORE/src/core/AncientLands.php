<?php
declare(strict_types=1);

namespace core;

use core\addons\EffectShopCMD;
use core\addons\EnchantShop;
use core\addons\ListCommand;
use core\AncientLandsPlayer;


use core\addons\GeneratorCommands;
use core\addons\AncientLandsSOTWCommands;
use core\addons\DeathLoreCommands;
use core\addons\XpCommands;
use core\addons\WildCommands;
use core\addons\CharmAttributes;
use core\addons\DivineAttributes;
use core\addons\SatanicAttributes;
use core\addons\Items;

use core\database\Database;
use core\level\LevelManager;
use core\level\LevelListener;
use core\level\tile\Generator;
use core\level\block\BGenerator;

use core\addons\ranknotes\Aphrodite;
use core\addons\ranknotes\Apollo;
use core\addons\ranknotes\Ares;
use core\addons\ranknotes\Athena;
use core\addons\ranknotes\Demeter;
use core\addons\ranknotes\Hades;
use core\addons\ranknotes\Hermes;
use core\addons\ranknotes\Minotaur;
use core\addons\ranknotes\Poseidon;
use core\addons\ranknotes\Zeus;

use core\addons\currencynotes\xpbottle;
use core\addons\currencynotes\lxpbottle;
use core\addons\currencynotes\moneynote;


use core\miningrewards\MRListener;
use core\miningrewards\MRManager;
use core\sessions\SessionListener;
use core\utils\form\CustomForm;
use core\utils\form\Form;
use core\utils\form\ModalForm;
use core\utils\form\SimpleForm;

use core\anti\{
    AntiAdvertising, AntiSpam, ProfanityFilter, AntiSwearing
};


use core\event\DeathEvent;
use core\event\StoneEvents;
use core\event\KeyEvents;
use core\event\RankEvents;
use core\tp\task\DenyTask;
use core\event\AllEvents;

use core\headhunting\HeadHuntingListener;
use core\headhunting\HeadHuntingManager;

use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\entity\Entity;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\Plugin;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\plugin\PluginBase;
use muqsit\invmenu\{InvMenu, InvMenuHandler};
use pocketmine\tile\Tile;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\command\Command;
use pocketmine\event\Listener;
use pocketmine\scheduler\PluginTask;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\PiggyCustomEnchants;
use DaPigGuy\PiggyCustomEnchants\CustomEnchantManager;
use onebone\economyapi\EconomyAPI;
use jojoe77777\FormAPI;
use _64FF00\PureChat\PureChat;
use _64FF00\PurePerms\PurePerms;

class AncientLands extends PluginBase{

    public static $SERVER_NAME = "§a§lAL§7PE §r§7| §7OP §aFactions";

	public static $instance;

	public array $tpa = [];

	public function onLoad() : void{
	    
		// CustomEnchants Plugin
		$ce = $this->getServer()->getPluginManager()->getPlugin("PiggyCustomEnchants");
		if ($ce instanceof PiggyCustomEnchants) {
			$this->getServer()->getLogger()->notice("Load PureChat CustomEnchants!");
		} else {
			$this->getServer()->getLogger()->warning("Error no Plugin CustomEnchants!");
		}		
		// EconomyAPI Plugin
		$economyAPI = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
		if ($economyAPI instanceof EconomyAPI) {
			$this->getServer()->getLogger()->notice("Load PureChat EconomyAPI!");
		} else {
			$this->getServer()->getLogger()->warning("Error no Plugin EconomyAPI!");
		}
		// FormAPI Plugin
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		if ($api instanceof FormAPI) {
			$this->getServer()->getLogger()->notice("Load FormAPI successful!");
		} else {
			$this->getServer()->getLogger()->warning("Error no Plugin FormAPI!");
		}
		// PurePerms Plugin
		$purePerms = $this->getServer()->getPluginManager()->getPlugin("PurePerms");
		if ($purePerms instanceof PurePerms) {
			$this->getServer()->getLogger()->notice("Load PureChat PurePerms!");
		} else {
			$this->getServer()->getLogger()->warning("Error no Plugin PurePerms!");
		}
		// PureChat Plugin
		$pureChat = $this->getServer()->getPluginManager()->getPlugin("PureChat");
		if ($pureChat instanceof PureChat) {
			$this->getServer()->getLogger()->notice("Load PureChat successful!");
		} else {
			$this->getServer()->getLogger()->warning("Error no Plugin PureChat!");
		}
	}
	/**
	 * @var array
	 */
	public $TPRequests;

	/**
	 * @var array
	 */
	public $lastRequest;


	/** @var array */
	public function onEnable(): void
	{
		self::$instance = $this;
		new AntiSpam($this);
		Database::init();
		MRManager::getInstance()->registerLevel(1, 10, 1, 15);
		$this->saveDefaultConfig();
		$this->lastRequest = [];
		$this->TPRequests = [];
		$this->config = $this->getConfig();
		$this->autoDenialTime = $this->config->get("autodenial-time");
		if (!is_dir($this->getDataFolder())) {
			mkdir($this->getDataFolder());
		}
		if (!is_dir($this->getDataFolder() . "alias")) {
			mkdir($this->getDataFolder() . "alias");
		}
		if (!is_dir($this->getDataFolder() . "alias/cid")) {
			mkdir($this->getDataFolder() . "alias/cid");
		}
		if (!is_dir($this->getDataFolder() . "alias/ip")) {
			mkdir($this->getDataFolder() . "alias/ip");
		}
		if (!is_dir($this->getDataFolder() . "cooldown")) {
			mkdir($this->getDataFolder() . "cooldown");
		}
		if (!is_dir($this->getDataFolder() . "player")) {
			mkdir($this->getDataFolder() . "player");
			$this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("list"));
			$this->getServer()->getCommandMap()->register("effectshop", new EffectShopCMD("effectshop", $this));
			$this->getServer()->getCommandMap()->register("enchantshop", new EnchantShop("enchantshop", $this));
			$this->getServer()->getCommandMap()->register("list", new ListCommand("list", $this));
			$this->getServer()->getCommandMap()->register("sotw", new AncientLandsSOTWCommands("sotw", $this));
			$this->getServer()->getCommandMap()->register("ca", new CharmAttributes("ca", $this));
			$this->getServer()->getCommandMap()->register("deathlore", new DeathLoreCommands("deathlore", $this));
			$this->getServer()->getCommandMap()->register("dwa", new DivineAttributes("dwa", $this));
			$this->getServer()->getCommandMap()->register("generator", new GeneratorCommands("generator", $this));
			$this->getServer()->getCommandMap()->register("sa", new SatanicAttributes("sa", $this));
			$this->getServer()->getCommandMap()->register("wild", new WildCommands("wild", $this));
			$this->getServer()->getCommandMap()->register("xpshop", new XpCommands("xpshop", $this));
			$this->getServer()->getCommandMap()->register("aphrodite", new Aphrodite("aphrodite", $this));
			$this->getServer()->getCommandMap()->register("apollo", new Apollo("apollo", $this));
			$this->getServer()->getCommandMap()->register("ares", new Ares("ares", $this));
			$this->getServer()->getCommandMap()->register("athena", new Athena("athena", $this));
			$this->getServer()->getCommandMap()->register("demeter", new Demeter("demeter", $this));
			$this->getServer()->getCommandMap()->register("hades", new Hades("hades", $this));
			$this->getServer()->getCommandMap()->register("hermes", new Hermes("hermes", $this));
			$this->getServer()->getCommandMap()->register("minotaur", new Minotaur("minotaur", $this));
			$this->getServer()->getCommandMap()->register("poseidon", new Poseidon("poseidon", $this));
			$this->getServer()->getCommandMap()->register("zeus", new Zeus("zeus", $this));
			$this->getServer()->getCommandMap()->register("xpbottle", new xpbottle("xpbottle", $this));
			$this->getServer()->getCommandMap()->register("lxpbottle", new lxpbottle("lxpbottle", $this));
			$this->getServer()->getCommandMap()->register("moneynote", new moneynote("moneynote", $this));

			$this->levelManager = new LevelManager($this);

			#events
			$this->getServer()->getPluginManager()->registerEvents(new DeathEvent($this), $this);
			$this->getServer()->getPluginManager()->registerEvents(new KeyEvents($this), $this);
			$this->getServer()->getPluginManager()->registerEvents(new RankEvents($this), $this);
			$this->getServer()->getPluginManager()->registerEvents(new StoneEvents($this), $this);
			$this->getServer()->getPluginManager()->registerEvents(new AllEvents($this), $this);
			$this->getServer()->getPluginManager()->registerEvents(new MRListener($this), $this);
			$this->getServer()->getPluginManager()->registerEvents(new SessionListener($this), $this);
			$this->getServer()->getPluginManager()->registerEvents(new AllEvents($this), $this);

		}
	}

	/**
	 * @param Player $requester
	 * @param Player $target
	 * @param string $type
	 */
	public function addTPRequest(Player $requester, Player $target, string $type): void{
		$task = $this->getScheduler()->scheduleDelayedTask(new DenyTask($this, $requester, $target), $this->autoDenialTime * 20);
		$this->TPRequests[$requester->getName()] = [$type, $target->getName(), $task->getTaskId()];
		$this->lastRequest[$target->getName()] = $requester->getName();
	}

	/**
	 * @param Player $requester
	 */
	public function removeTPRequest(Player $requester): void{
		$data = $this->TPRequests[$requester->getName()];
		unset($this->TPRequests[$requester->getName()]);
		$this->getScheduler()->cancelTask($data[2]);
	}

	/**
	 * @param Player $requester
	 * @return string
	 */
	public function getRequestType(Player $requester): string{
		return $this->TPRequests[$requester->getName()][0];
	}

	/**
	 * @param Player $target
	 * @return mixed|Player|null
	 */
	public function getLastIncomingRequest(Player $target){
		$search = $this->lastRequest[$target->getName()];
		if($this->getServer()->getPlayer($search) !== null){
			return $this->getServer()->getPlayer($search);
		}
		return $search;
	}

	/**
	 * @param Player $player
	 * @return bool
	 */
	public function hasOutgoingRequest(Player $player): bool{
		if(in_array($player->getName(), array_keys($this->TPRequests))){
			return true;
		}
		return false;
	}

	/**
	 * @param Player $player
	 * @return bool
	 */
	public function hasIncomingRequest(Player $player): bool{
		foreach(array_values($this->TPRequests) as $request){
			if(in_array($player->getName(), $request)){
				return true;
			}
		}
		return false;
	}

	/**
	 * @param Player $requester
	 * @param Player $target
	 * @return bool
	 */
	public function hasIncomingRequestFrom(Player $requester, Player $target): bool{
		foreach($this->TPRequests[$requester->getName()] as $request){
			if(in_array($target->getName(), $request)){
				return true;
			}
		}
		return false;
	}

	static function getInstance(): self{
		return self::$instance;
	}
        public function getLevelManager(): LevelManager{
	    return $this->levelManager;
        }

	private function createEnchant(){
        Enchantment::registerEnchantment(new Enchantment(100, "", 0, 0, 0, 1));
        $enchantment = Enchantment::getEnchantment(100);
        $this->enchInst = new EnchantmentInstance($enchantment, 1);
    }
}
