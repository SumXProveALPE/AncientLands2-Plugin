<?php

namespace core\entity\types;

use pocketmine\item\Item;
use pocketmine\entity\Monster;

class Zombie extends Monster {

	public const NETWORK_ID = self::ZOMBIE;

	public $width = 0.6;
	public $height = 1.8;

	public function getName() : string{
		return "Zombie";
	}

	public function getDrops(): array{
		$drops = [
			Item::get(Item::ROTTEN_FLESH, 0, mt_rand(0, 2))
		];
}