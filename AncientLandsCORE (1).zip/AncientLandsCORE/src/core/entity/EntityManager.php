<?php

namespace core\entity;

use core\AncientLands;

# Pocketmine
use pocketmine\entity\Entity;

# Entities
use core\entity\types\Skeleton;
use core\entity\types\Zombie;

# Class
class EntityManager {

    private $plugin;

    public function __construct(AncientLands $plugin){
        $this->plugin = $plugin;
    }

    public function registerEntities(): void{
        Entity::registerEntity(Skeleton::class, true);
        Entity::registerEntity(Zombie::class, true);
    }
}