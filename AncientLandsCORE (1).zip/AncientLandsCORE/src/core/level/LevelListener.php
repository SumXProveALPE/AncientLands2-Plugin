<?php

declare(strict_types = 1);

namespace core\level;


use core\level\tile\Generator;
use core\AncientLands;
use core\AncientLandsPlayer;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\inventory\FurnaceSmeltEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\level\Position;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class LevelListener implements Listener {

    /** @var AncientLands */
    private $core;

    /**
     * LevelListener constructor.
     *
     * @param AncientLands $core
     */
    public function __construct(AncientLands $core) {
        $this->core = $core;
    }


    /**
     * @priority HIGHEST
     * @param PlayerInteractEvent $event
     */
    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $tile = $block->getLevel()->getTile($block);
        $item = $event->getItem();
       
        if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK and $tile instanceof Generator and $block->getItemID() === $item->getID() and $tile->getStack() < $tile->getMaxStackSize()) {
            $stack = $tile->getStack() + 1;
            $tile->setStack($stack);
            $maxStackSize = $tile->getMaxStackSize();
            $player->sendMessage(TextFormat::colorize("&8&l(&c&l!&8&l) &r&aStacked &6{$stack}/{$maxStackSize} &8&l(&c&l!&8&l)"));
            $player->getInventory()->setItemInHand($item->setCount($item->getCount() - 1));
            $event->setCancelled();
        }
        if($event->getAction() === PlayerInteractEvent::LEFT_CLICK_BLOCK and $tile instanceof Generator and $block->getItemID() === $item->getID()){
            $stack = $tile->getStack();
            $maxStackSize = $tile->getMaxStackSize();
            $player->sendMessage(TextFormat::colorize("&8&l(&b&l!&8&l) &r&aCurrent Stacked Generators: &6{$stack}&c/&6{$maxStackSize} &8&l(&b&l!&8&l)"));
            $event->setCancelled();
        }
        }


    /**
     * @priority LOWEST
     * @param FurnaceSmeltEvent $event
     */
    public function onFurnaceSmelt(FurnaceSmeltEvent $event): void {
        $id = $event->getResult()->getId();
        if($id >= Block::PURPLE_GLAZED_TERRACOTTA and $id <= Block::BLACK_GLAZED_TERRACOTTA) {
            $event->setCancelled();
        }
    }
}