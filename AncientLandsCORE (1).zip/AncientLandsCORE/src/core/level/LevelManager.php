<?php

declare(strict_types = 1);

namespace core\level;

use core\level\block\BGenerator;
use core\AncientLands;
use pocketmine\block\BlockFactory;
use pocketmine\item\Item;
use pocketmine\tile\Tile;
use ReflectionException;

class LevelManager {

    /** @var AncientLands */
    private $core;

    /**
     * LevelManager constructor.
     *
     * @param AncientLands $core
     *
     */
    public function __construct(AncientLands $core) {
        $this->core = $core;
        $core->getServer()->getPluginManager()->registerEvents(new LevelListener($core), $core);
        $this->init();
    }

    /**
     * @throws ReflectionException
     */
    public function init(): void {
        BlockFactory::registerBlock(new BGenerator(Item::BLACK_GLAZED_TERRACOTTA, Item::get(Item::COAL, 0, 1), BGenerator::AUTO), true);
        BlockFactory::registerBlock(new BGenerator(Item::BROWN_GLAZED_TERRACOTTA, Item::get(Item::COAL_ORE, 0, 1), BGenerator::MINING), true);
        BlockFactory::registerBlock(new BGenerator(Item::GRAY_GLAZED_TERRACOTTA, Item::get(Item::DYE, 4, 1), BGenerator::AUTO), true);
        BlockFactory::registerBlock(new BGenerator(Item::CYAN_GLAZED_TERRACOTTA, Item::get(Item::LAPIS_ORE, 0, 1), BGenerator::MINING), true);
        BlockFactory::registerBlock(new BGenerator(Item::PINK_GLAZED_TERRACOTTA, Item::get(Item::DYE, 4, 1), BGenerator::AUTO), true);
        BlockFactory::registerBlock(new BGenerator(Item::BLUE_GLAZED_TERRACOTTA, Item::get(Item::LAPIS_ORE, 0, 1), BGenerator::MINING), true);
        BlockFactory::registerBlock(new BGenerator(Item::GRAY_GLAZED_TERRACOTTA, Item::get(Item::IRON_INGOT, 0, 1), BGenerator::AUTO), true);
        BlockFactory::registerBlock(new BGenerator(Item::SILVER_GLAZED_TERRACOTTA, Item::get(Item::IRON_ORE, 0, 1), BGenerator::MINING), true);
        BlockFactory::registerBlock(new BGenerator(Item::YELLOW_GLAZED_TERRACOTTA, Item::get(Item::GOLD_INGOT, 0, 1), BGenerator::AUTO), true);
        BlockFactory::registerBlock(new BGenerator(Item::ORANGE_GLAZED_TERRACOTTA, Item::get(Item::GOLD_ORE, 0, 1), BGenerator::MINING), true);
        BlockFactory::registerBlock(new BGenerator(Item::LIGHT_BLUE_GLAZED_TERRACOTTA, Item::get(Item::DIAMOND, 0, 1), BGenerator::AUTO), true);
        BlockFactory::registerBlock(new BGenerator(Item::PURPLE_GLAZED_TERRACOTTA, Item::get(Item::DIAMOND_ORE, 0, 1), BGenerator::MINING), true);
        BlockFactory::registerBlock(new BGenerator(Item::LIME_GLAZED_TERRACOTTA, Item::get(Item::EMERALD, 0, 1), BGenerator::AUTO), true);
        BlockFactory::registerBlock(new BGenerator(Item::GREEN_GLAZED_TERRACOTTA, Item::get(Item::EMERALD_ORE, 0, 1), BGenerator::MINING), true);
        Tile::registerTile(\core\level\tile\Generator::class);
    }
}
