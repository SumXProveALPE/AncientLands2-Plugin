<?php


namespace core\database;


use core\AncientLands;
use pocketmine\Player;
use SQLite3;

class Database
{

	//fucking idiot whoever coded this shit -vaqle

    public static $dataBase;

    public static function init() {
        self::$dataBase = new SQLite3(AncientLands::getInstance()->getDataFolder() . "PlayerData.db");
        self::$dataBase->exec("CREATE TABLE IF NOT EXISTS Players(Uuid TEXT PRIMARY KEY DEFAULT NULL, Username TEXT DEFAULT NULL, Level INT DEFAULT 1, MinedBlocks INT DEFAULT 0)");
    }

    public static function createData(Player $player) {
        $name = $player->getName();
        $uuid = $player->getUniqueId()->toString();
        $value = self::$dataBase->prepare("INSERT INTO Players(Uuid, Username) VALUES (:uuid, :username)");
        $value->bindParam(":uuid", $uuid);
        $value->bindParam(":username", $name);
        $value->execute();
    }

    public static function exist(Player $player) :bool{
        $uuid = $player->getUniqueId()->toString();
        $value = self::$dataBase->prepare("SELECT Uuid FROM Players WHERE Uuid =:uuid");
        $value->bindParam(":uuid", $uuid);
        return !($value->execute()->fetchArray() == null);
    }

    public static function getMRLevel(Player $player) :int {
        $uuid = $player->getUniqueId()->toString();
        $value = self::$dataBase->prepare("SELECT * FROM Players WHERE Uuid =:uuid");
        $value->bindParam(":uuid", $uuid);
        $array = $value->execute()->fetchArray();
        return $array['Level'];
    }

    public static function getMinedBlocks(Player $player) :int{
        $uuid = $player->getUniqueId()->toString();
        $value = self::$dataBase->prepare("SELECT * FROM Players WHERE Uuid =:uuid");
        $value->bindParam(":uuid", $uuid);
        $array = $value->execute()->fetchArray();
        return $array['MinedBlocks'];
    }

    public static function updateMinedBlocks(Player $player, int $blocks) {
        $uuid = $player->getUniqueId()->toString();
        $value = self::$dataBase->prepare("UPDATE Players SET MinedBlocks =:blocks WHERE Uuid =:uuid");
        $value->bindParam(":blocks", $blocks);
        $value->bindParam(":uuid", $uuid);
        $value->execute();
    }

    public static function updateLevel(Player $player, int $level) {
        $uuid = $player->getUniqueId()->toString();
        $value = self::$dataBase->prepare("UPDATE Players SET Level =:lvl WHERE Uuid =:uuid");
        $value->bindParam(":lvl", $level);
        $value->bindParam(":uuid", $uuid);
        $value->execute();
    }

}