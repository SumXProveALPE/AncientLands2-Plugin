<?php

namespace core\addons;

use core\AncientLands;
use core\utils\form\CustomForm;
use core\utils\form\SimpleForm;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\item\Durable;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;
use pocketmine\plugin\Plugin;
use onebone\economyapi\EconomyAPI;

use jojoe77777\FormAPI;

class EnchantShop extends PluginCommand
{

	/** @var array */
	public $plugin;

	public function __construct($name, AncientLands $plugin)
	{
		parent::__construct($name, $plugin);
		$this->setDescription("Buy Enchantments");
		$this->setAliases(["es"]);
		$this->setPermission("core.command.enchantshop");
		$this->plugin = $plugin;
	}

	/**
	 * @param CommandSender $sender
	 * @param string $alias
	 * @param array $args
	 * @return bool
	 */
	public function execute(CommandSender $sender, string $commandLabel, array $args): bool
	{
		if ($sender instanceof ConsoleCommandSender) {
			$sender->sendMessage(TextFormat::RED . "This command can be only used in-game.");
			return false;
		}
		$this->enchantUI($sender);
		return true;
	}

	/**
	 * @param CeShopUI
	 * @param Player $player
	 */
	public function enchantUI(Player $player): void
	{
		$api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = new SimpleForm(function (Player $player, int $data = null) {
			$result = $data;
			if ($result === null) {
				return;
			}
			switch ($result) {
				case 0:
					$this->PROT($player);
					break;
				case 1:
					$this->SHARP($player);
					break;
				case 2:
					$this->UNBREAKING($player);
					break;
				case 3:
					$this->EFF($player);
					break;
			}
		});
		$exp = $player->getCurrentTotalXp();
		$form->setTitle(TextFormat::BOLD . TextFormat::GREEN . "Enchant Shop");
		$form->setContent(TextFormat::AQUA . "Enchantment Shop");
		$form->addButton(TextFormat::RED . "Protection: 60k Per level");
		$form->addButton(TextFormat::RED . "Sharpness: 50k Per level");
		$form->addButton(TextFormat::RED . "Unbreaking: 30k Per level");
		$form->addButton(TextFormat::RED . "Efficency: 100k Per level");
		$form->sendToPlayer($player);
	}

	/**
	 * @param Player $player
	 */
	public function PROT(Player $player): void
	{
		$api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = new CustomForm(function (Player $player, array $data = null) {
			$result = $data[1];
			if ($result != null) {
				$cost = 60000 * $result;
				$money = EconomyAPI::getInstance()->myMoney($player);
				if ($money < $cost) {
					$player->sendMessage(TextFormat::RED . "You do not have enough $ to buy Protection {$result}");
				} else {
					$book = Item::get(Item::ENCHANTED_BOOK, 0, 1);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), $result));
					$player->getInventory()->addItem($book);
					EconomyAPI::getInstance()->reduceMoney($player, $cost);
					$player->sendMessage(TextFormat::GREEN . "You have bought Protection {$result} for {$cost}");
				}
				return true;
			}
		});
		$form->setTitle(TextFormat::BOLD . TextFormat::GREEN . "Protection");
		$form->addLabel("§aProtection: 10,000$ Per level");
		$form->addSlider("Level", 1, 10, 1);
		$form->sendToPlayer($player);
	}


	public function UNBREAKING(Player $player): void
	{
		$api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = new CustomForm(function (Player $player, array $data = null) {
			$result = $data[1];
			if ($result != null) {
				$cost = 30000 * $result;
				if ($player->getCurrentTotalXp() - $cost < 0) {
					$player->sendMessage(TextFormat::RED . "You do not have enough $ to buy Unbreaking {$result}");
				} else {
					$book = Item::get(Item::ENCHANTED_BOOK, 0, 1);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), $result));
					$player->getInventory()->addItem($book);
					EconomyAPI::getInstance()->reduceMoney($player, $cost);
					$player->sendMessage(TextFormat::GREEN . "You have bought Unbreaking {$result} for {$cost}");
				}
				return true;
			}
		});
		$form->setTitle(TextFormat::BOLD . TextFormat::GREEN . "Unbreaking");
		$form->addLabel("§aUnbreaking: 30,000$ Per level");
		$form->addSlider("Level", 1, 10, 1);
		$form->sendToPlayer($player);
	}


	public function EFF(Player $player): void
	{
		$api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = new CustomForm(function (Player $player, array $data = null) {
			$result = $data[1];
			if ($result != null) {
				$cost = 30000 * $result;
				if ($player->getCurrentTotalXp() - $cost < 0) {
					$player->sendMessage(TextFormat::RED . "You do not have enough $ to buy Efficency {$result}");
				} else {
					$book = Item::get(Item::ENCHANTED_BOOK, 0, 1);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), $result));
					$player->getInventory()->addItem($book);
					EconomyAPI::getInstance()->reduceMoney($player, $cost);
					$player->sendMessage(TextFormat::GREEN . "You have bought Efficency {$result} for {$cost}");
				}
				return true;
			}
		});
		$form->setTitle(TextFormat::BOLD . TextFormat::GREEN . "Effeciecny");
		$form->addLabel("§aEfficency: 30,000$ Per level");
		$form->addSlider("Level", 1, 10, 1);
		$form->sendToPlayer($player);
	}

	public function SHARP(Player $player): void
	{
		$api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = new CustomForm(function (Player $player, array $data = null) {
			$result = $data[1];
			if ($result != null) {
				$cost = 50000 * $result;
				if ($player->getCurrentTotalXp() - $cost < 0) {
					$player->sendMessage(TextFormat::RED . "You do not have enough $ to buy Sharpness {$result}");
				} else {
					$book = Item::get(Item::ENCHANTED_BOOK, 0, 1);
					$book->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), $result));
					$player->getInventory()->addItem($book);
					EconomyAPI::getInstance()->reduceMoney($player, $cost);
					$player->sendMessage(TextFormat::GREEN . "You have bought Sharpness {$result} for {$cost}");
				}
				return true;
			}
		});
		$form->setTitle(TextFormat::BOLD . TextFormat::GREEN . "Sharpness");
		$form->addLabel("§aSharpness: 50,000$ Per level");
		$form->addSlider("Level", 1, 10, 1);
		$form->sendToPlayer($player);
	}
}