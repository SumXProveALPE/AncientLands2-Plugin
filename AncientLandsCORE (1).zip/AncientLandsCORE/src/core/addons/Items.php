<?php

namespace core\addons;

use core\AncientLands;


use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\level\particle\DestroyBlockParticle;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\LevelEventPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\Player;
use pocketmine\Server;

class Items implements Listener { 

    
    private $plugin;

    public function __construct(AncientLands $plugin)
    {
        $this->plugin = $plugin;
        $this->plugin->getServer()->getPluginManager()->registerEvents($this, $plugin);
    }

    public function onCrate(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $inv = $player->getInventory();
        $hand = $inv->getItemInHand();
        $nbt = $hand->getNamedTag();
        
        	// Money Note $1,000 - $5,000
            if ($hand->getId() == 339 and $hand->getDamage() == 0 and $hand->getCustomName() == "§aMoney §eNote §7(Right Click)") {
            $event->setCancelled(true);
            $hand->setCount($hand->getCount() - 1);
            $inv->setItemInHand($hand);
            $reward = (1);
            switch($reward){
                # $1,000
                case 1:
                //
                break;
                # $2,000 
                case 2:
                //
                break;
                # $3,000  
                case 3:
                //
                break;
                # $4,000 
                case 4:
                //
                break;
                # $5,000
                case 5:
                //
                break;
            }
            }

        	// Money Note $10,000 - $50,000
       		if ($hand->getId() == 339 and $hand->getDamage() == 1 and $hand->getCustomName() == "§aMoney Note §7(Right Click)") {
            $event->setCancelled(true);
            $hand->setCount($hand->getCount() - 1);
            $inv->setItemInHand($hand);
            }
        	// Money Note $50,000 - $100,000
        	if ($hand->getId() == 339 and $hand->getDamage() == 2 and $hand->getCustomName() == "§aMoney Note §7(Right Click)") {
            $event->setCancelled(true);
            $hand->setCount($hand->getCount() - 1);
            $inv->setItemInHand($hand);
            }
        	// Money Note $100,000 - $300,000
        	if ($hand->getId() == 339 and $hand->getDamage() == 3 and $hand->getCustomName() == "§aMoney Note §7(Right Click)") {
            $event->setCancelled(true);
            $hand->setCount($hand->getCount() - 1);
            $inv->setItemInHand($hand);
            }
        	// Experience Bottle 1,000 - 4,000
        	if ($hand->getId() == 384 and $hand->getDamage() == 0 and $hand->getCustomName() == "§bExperience §3Bottle §7(Right Click)") {
            $event->setCancelled(true);
            $hand->setCount($hand->getCount() - 1);
            $inv->setItemInHand($hand);
            }
        	// Experience Bottle 5,000 - 8,000
        	if ($hand->getId() == 384 and $hand->getDamage() == 1 and $hand->getCustomName() == "§bExperience §3Bottle §7(Right Click)") {
            $event->setCancelled(true);
            $hand->setCount($hand->getCount() - 1);
            $inv->setItemInHand($hand);
            }
        	// Experience Bottle 8,000 - 10,000
        	if ($hand->getId() == 384 and $hand->getDamage() == 2 and $hand->getCustomName() == "§bExperience §3Bottle §7(Right Click)") {
            $event->setCancelled(true);
            $hand->setCount($hand->getCount() - 1);
            $inv->setItemInHand($hand);
            }
        	// Experience Bottle 10,000 - 15,000
        	if ($hand->getId() == 384 and $hand->getDamage() == 3 and $hand->getCustomName() == "§bExperience §3Bottle §7(Right Click)") {
            $event->setCancelled(true);
            $hand->setCount($hand->getCount() - 1);
            $inv->setItemInHand($hand);
            }
            if ($hand->getId() == 409 and $hand->getDamage() == 2 and $hand->getCustomName() == "§7Fractured §8Stone") {
            $event->setCancelled(true);
            $hand->setCount($hand->getCount() - 1);
            $inv->setItemInHand($hand);
            $reward = mt_rand(1,6);
            switch ($reward) {
                case 1:
                $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' TimeStone');
                $player->sendMessage("§b§l>> §r§aYou have recieved an TimeStone");
                break;

                case 2:
                $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' SpaceStone');
                $player->sendMessage("§b§l>> §r§aYou have recieved an SpaceStone");
                break;

                case 3:
                $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' SoulStone');
                $player->sendMessage("§b§l>> §r§aYou have recieved an SoulStone");
                break;

                case 4:
                $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' RealityStone');
                $player->sendMessage("§b§l>> §r§aYou have recieved an RealityStone");
                break;

                case 5:
                $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' PowerStone');
                $player->sendMessage("§b§l>> §r§aYou have recieved an PowerStone");
                break;

                case 6:
                $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' MindStone');
                $player->sendMessage("§b§l>> §r§aYou have recieved an MindStone");
                break;
            }
            }
            if ($hand->getId() == 138 and $hand->getDamage() == 0 and $hand->getCustomName() == "§e§lRisky Bundle") {
                $event->setCancelled(true);
                $hand->setCount($hand->getCount() - 1);
                $inv->setItemInHand($hand);
                $reward = mt_rand(1,25);
                switch ($reward) {
                    case 1:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 2:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 3:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 4:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 5:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 6:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 7:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 8:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 9:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 10:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 11:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 12:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 13:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 14:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 15:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    case 16:
                    $box = Item::get(54, 0, 1);
                    $box->setCustomName("§e§lDragon §r§7Bundle");
                    $player->sendMessage("§a§l(!) §r§aThe Ancient Essence has granted you with an lucky fate! Luckily you recieved a Bundle!");
                    $box->setLore([
                        ""
                    ]);
                    $player->getInventory()->addItem($box);
                    $player->getLevel()->broadcastLevelSoundEvent($player, LevelEventPacket::EVENT_SOUND_TOTEM);
                    $player->sendTitle("§e§l§k0§a9§d5§c3§64§58§40");
                    break;

                    case 17:
                    $box = Item::get(54, 0, 1);
                    $box->setCustomName("§a§lAncientLands SOTW §r§7Bundle");
                    $player->sendMessage("§a§l(!) §r§aThe Ancient Essence has granted you with an lucky fate! Luckily you recieved a Bundle!");
                    $box->setLore([
                     ""
                    ]);
                    $player->getInventory()->addItem($box);
                    $player->getLevel()->broadcastLevelSoundEvent($player, LevelEventPacket::EVENT_SOUND_TOTEM);
                    $player->sendTitle("§e§l§k0§a9§d5§c3§64§58§40");
                    break;

                    case 18:
                    $box = Item::get(54, 0, 1);
                    $box->setCustomName("§b§lNew Generation Bundle");
                    $player->sendMessage("§a§l(!) §r§aThe Ancient Essence has granted you with an lucky fate! Luckily you recieved a Bundle!");
                    $player->getInventory()->addItem($box);
                    $player->getLevel()->broadcastLevelSoundEvent($player, LevelEventPacket::EVENT_SOUND_TOTEM);
                    $player->sendTitle("§e§l§k0§a9§d5§c3§64§58§40");
                    break;

                    case 19:
                    $box = Item::get(54, 0, 1);
                    $box->setCustomName("§a§lGems §r§7Bundle");
                    $player->sendMessage("§a§l(!) §r§aThe Ancient Essence has granted you with an lucky fate! Luckily you recieved a Bundle!");
                    $box->setLore([
                    ""
                    ]);
                    $player->getInventory()->addItem($box);
                    $player->getLevel()->broadcastLevelSoundEvent($player, LevelEventPacket::EVENT_SOUND_TOTEM);
                    $player->sendTitle("§e§l§k0§a9§d5§c3§64§58§40");
                    break;

                    case 20:
                    $box = Item::get(54, 0, 1);
                    $box->setCustomName("§6§lKeys §r§7Bundle");
                    $player->sendMessage("§a§l(!) §r§aThe Ancient Essence has granted you with an lucky fate! Luckily you recieved a Bundle!");
                    $box->setLore([
                     ""
                    ]);
                    $player->getInventory()->addItem($box);
                    $player->getLevel()->broadcastLevelSoundEvent($player, LevelEventPacket::EVENT_SOUND_TOTEM);
                    $player->sendTitle("§e§l§k0§a9§d5§c3§64§58§40");
                    break;
                        
                    case 21:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;
                        
                    case 22:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;
                        
                    case 23:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;
                        
                    case 24:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;
                        
                    case 25:
                    $player->sendMessage("§c§l(!) §r§cThe Ancient Essence has granted you with an unlucky fate! Sadly you didn't recieve a Bundle!");
                    break;

                    
                   
                }
                }

            
        	
        
        








        	// Thevil (Banned Item)
        	if ($hand->getId() == 145 and $hand->getDamage() == 0) {
            $event->setCancelled(true);
            $hand->setCount($hand->getCount() - 1);
            $inv->setItemInHand($hand);
            $player->sendMessage("§6§l>> §r§cWhoops! Looks like this item is banned.");
            }
        	// Item Frame (Banned Item);
        	if ($hand->getId() == 389 and $hand->getDamage() == 0) {
            $event->setCancelled(true);
            $hand->setCount($hand->getCount() - 1);
            $inv->setItemInHand($hand);
            $player->sendMessage("§6§l>> §r§cWhoops! Looks like this item is banned.");

            }
            if ($hand->getId() == 54 and $hand->getDamage() == 1 and $hand->getCustomName() == "§eVote §bLootBag §r§7(Right-Click)") {
                $event->setCancelled(true);
                $hand->setCount($hand->getCount() - 1);
                $inv->setItemInHand($hand);
                $reward = mt_rand(1,10);
                switch ($reward) {
                    case 1:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givexp 50000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 50k EXP");
                    break;

                    case 2:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givexp 100000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 100k EXP");
                    break;

                    case 3:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'item styx ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved an STYX AXE");
                    break;

		    case 4:
		    $item = Item::get(403, 0, 1);
		    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wrath"), 1));
                    $item->setCustomName("§r§l§4Wrath I\nEnchantment Book");
                    $item->setLore([
                    '§r§eChance to disable enemy',
                    '§r§7Sword Enchantment',
                    '§r§7Combine it into item to enchant'
                    ]);
                    $player->sendMessage("§l§b» §r§aYou earn Wrath Custom Enchantment");
                    if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
		    break;

		    case 5:
		    $item = Item::get(403, 0, 1);
		    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wrath"), 2));
                    $item->setCustomName("§r§l§4Wrath II\nEnchantment Book");
                    $item->setLore([
                    '§r§eChance to disable enemy',
                    '§r§7Sword Enchantment',
                    '§r§7Combine it into item to enchant'
                    ]);
                    $player->sendMessage("§l§b» §r§aYou earn Wrath Custom Enchantment");
                    if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
		    break;

                    case 6:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givexp 25000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 25k EXP");
                    break;

                    case 7:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 25000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 25k Money");
                    break;

                    case 8:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 50000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 50k Money");
                    break;

                    case 9:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 100000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 100k Money");
                    break;

		    case 10:
		    $item = Item::get(403, 0, 1);
		    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 6));
                    $item->setCustomName("§r§l§4BlackOut VI\nEnchantment Book");
                    $item->setLore([
                    '§r§eChance to disable enemy',
                    '§r§7Sword Enchantment',
                    '§r§7Combine it into item to enchant'
                    ]);
                    $player->sendMessage("§l§b» §r§aYou earn Wrath Custom Enchantment");
                    if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
		    break;

		    case 11:
		    $item = Item::get(403, 0, 1);
		    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 5));
                    $item->setCustomName("§r§l§4BlackOut V\nEnchantment Book");
                    $item->setLore([
                    '§r§eChance to disable enemy',
                    '§r§7Sword Enchantment',
                    '§r§7Combine it into item to enchant'
                    ]);
                    $player->sendMessage("§l§b» §r§aYou earn BlackOut Custom Enchantment");
                    if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
		    break;

}
}