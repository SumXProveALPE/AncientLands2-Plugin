<?php

namespace core\addons;

use core\AncientLands;
use core\utils\form\SimpleForm;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\Player;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;

use onebone\economyapi\EconomyAPI;
use jojoe77777\FormAPI;
use pocketmine\utils\Utils;

class EffectShopCMD extends PluginCommand
{

	/** @var array */
	public $plugin;

	public function __construct($name, AncientLands $plugin)
	{
		parent::__construct($name, $plugin);
		$this->setDescription("effectshop");
		$this->setUsage("/effectshop");
		$this->setPermission("core.command.effectshop");
		$this->economy = EconomyAPI::getInstance();
		$this->plugin = $plugin;
	}

	/**
	 * @param CommandSender $sender
	 * @param string $alias
	 * @param array $args
	 * @return bool
	 */
	public function execute(CommandSender $sender, string $commandLabel, array $args): bool
	{
		if (!$sender->hasPermission("core.command.shop")) {
			$sender->sendMessage(TextFormat::RED . "You do not have permission to use this command");
			return false;
		}
		if ($sender instanceof ConsoleCommandSender) {
			$sender->sendMessage(TextFormat::RED . "This command can be only used in-game.");
			return false;
		}
		$this->efffectshop($sender);
		return true;
	}

	/**
	 * @param ShopUI
	 * @param Player $player
	 */
	public function efffectshop(Player $player): void
	{
		$form = new SimpleForm(function (Player $player, int $data = null) {
			$result = $data;
			if ($result === null) {
				return;
			}
			switch ($result) {
				case 0:
					$this->EFFECTUI($player);
					break;
			}
		});
		$form->setTitle(TextFormat::BOLD . TextFormat::RED . "EFFECT SHOP");
		$form->setContent(TextFormat::GRAY . "Effects!");
		$form->addButton(TextFormat::BLUE . "Buy Effects");
		$form->sendToPlayer($player);
	}

	/**
	 * @param BlockUI
	 * @param Player $player
	 */
	public function EFFECTUI(Player $player): void
	{
		$api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = new SimpleForm(function (Player $player, int $data = null) {
			$result = $data;
			if ($result === null) {
				return;
			}
			switch ($result) {
				case 0:
					$this->efffectshop($player);
					break;
				case 1:
					$this->strength($player);
					break;
				case 2:
					$this->NV($player);
					break;
				case 3:
					$this->RESIS($player);
					break;
				case 4:
					$this->regen($player);
					break;
				case 5:
					$this->Invis($player);
					break;
				case 6:
					$this->jump($player);
					break;
				case 7:
					$this->speed($player);
					break;
			}
		});
		$form->setTitle(TextFormat::BOLD . TextFormat::GREEN . "Blocks Page 1");
		$form->setContent(TextFormat::AQUA . "Select Effect To Buy!");
		$form->addButton(TextFormat::BLACK . "Back");
		$form->addButton(TextFormat::GREEN . "Stregnth II\n§9$20,000 2 Minutes");
		$form->addButton(TextFormat::GREEN . "Night Vision II\n§9$20,000 2 Minutes");
		$form->addButton(TextFormat::GREEN . "Resistance II\n§9$20,000 2 Minutes");
		$form->addButton(TextFormat::GREEN . "Regeneration II\n§9$20,000 2 Minutes");
		$form->addButton(TextFormat::GREEN . "Invis \n§9$20,000 2 Minutes");
		$form->addButton(TextFormat::GREEN . "Jump Boost \n§9$20,000 2 Minutes");
		$form->addButton(TextFormat::GREEN . "Speed \n§9$20,000 2 Minutes");
		$form->sendToPlayer($player);
	}


	public function NV(Player $player): void
	{
		$money = EconomyAPI::getInstance()->myMoney($player);
		if ($money >= 20000) {
			EconomyAPI::getInstance()->reduceMoney($player, 20000);
			$eff = new EffectInstance(Effect::getEffect(Effect::NIGHT_VISION), 4000, 1);
			$player->addEffect($eff);
		} else {
			$player->sendMessage("§r§c§l(!) You dont have enough cash for this!");
		}
	}

	public function RESIS(Player $player): void
	{
		$money = EconomyAPI::getInstance()->myMoney($player);
		if ($money >= 20000) {
			EconomyAPI::getInstance()->reduceMoney($player, 20000);
			$eff = new EffectInstance(Effect::getEffect(Effect::RESISTANCE), 4000, 1);
			$player->addEffect($eff);
		} else {
			$player->sendMessage("§r§c§l(!) You dont have enough cash for this!");
		}
	}

	public function regen(Player $player): void
	{
		$money = EconomyAPI::getInstance()->myMoney($player);
		if ($money >= 20000) {
			EconomyAPI::getInstance()->reduceMoney($player, 20000);
			$eff = new EffectInstance(Effect::getEffect(Effect::REGENERATION), 4000, 1);
			$player->addEffect($eff);
		} else {
			$player->sendMessage("§r§c§l(!) You dont have enough cash for this!");
		}
	}

	public function Invis(Player $player): void
	{
		$money = EconomyAPI::getInstance()->myMoney($player);
		if ($money >= 20000) {
			EconomyAPI::getInstance()->reduceMoney($player, 20000);
			$eff = new EffectInstance(Effect::getEffect(Effect::INVISIBILITY), 4000, 1);
			$player->addEffect($eff);
		} else {
			$player->sendMessage("§r§c§l(!) You dont have enough cash for this!");
		}
	}

	public function jump(Player $player): void
	{
		$money = EconomyAPI::getInstance()->myMoney($player);
		if ($money >= 20000) {
			EconomyAPI::getInstance()->reduceMoney($player, 20000);
			$eff = new EffectInstance(Effect::getEffect(Effect::JUMP_BOOST), 4000, 1);
			$player->addEffect($eff);
		} else {
			$player->sendMessage("§r§c§l(!) You dont have enough cash for this!");
		}
	}

	public function speed(Player $player): void
	{
		$money = EconomyAPI::getInstance()->myMoney($player);
		if ($money >= 20000) {
			EconomyAPI::getInstance()->reduceMoney($player, 20000);
			$eff = new EffectInstance(Effect::getEffectByName("Speed"), 4000, 1);
			$player->addEffect($eff);
		} else {
			$player->sendMessage("§r§c§l(!) You dont have enough cash for this!");
		}
	}

	public function strength(Player $player): void
	{
		$money = EconomyAPI::getInstance()->myMoney($player);
		if ($money >= 20000) {
			EconomyAPI::getInstance()->reduceMoney($player, 20000);
			$eff = new EffectInstance(Effect::getEffectByName("Strength"), 4000, 1);
			$player->addEffect($eff);
		} else {
			$player->sendMessage("§r§c§l(!) You dont have enough cash for this!");
		}
	}
}