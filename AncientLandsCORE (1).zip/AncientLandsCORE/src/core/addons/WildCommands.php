<?php

namespace core\addons;

use core\AncientLands;

# Pocketmine
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use pocketmine\event\Listener;
use pocketmine\level\Location;
use pocketmine\level\Position;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;
use pocketmine\command\PluginCommand;
use pocketmine\command\CommandSender;
use pocketmine\event\entity\EntityDamageEvent;

# Wild Class
class WildCommands extends PluginCommand implements Listener{

    private $plugin;
    private $inWild = [];

    public function __construct($name, AncientLands $plugin){
        $this->plugin = $plugin;
        parent::__construct($name, $plugin);
        $this->setDescription("Teleport into the wild.");
        $this->setUsage("/wild");
        $this->setPermission("cmd.wild");
        $this->plugin->getServer()->getPluginManager()->registerEvents($this, $plugin);
    }

    public function execute(CommandSender $sender, string $label, array $args): bool{
        if (!$sender->hasPermission("cmd.wild")) {
			$sender->sendMessage("§l§1(§b!§1) §r§cYou do not have permission to use this command.");
			return false;
		}
		if ($sender instanceof ConsoleCommandSender) {
			$sender->sendMessage("§l§1(§b!§1) §r§cThis command can only be used in-game.");
			return false;
		}
        $level = $this->plugin->getServer()->getLevelByName("world");
        $x = mt_rand(-2500, 2500);
        $y = mt_rand(100, 128);
        $z = mt_rand(-2500, 2500);
        $sender->teleport(new Position($x, $y, $z, $level));
        $this->inWild[] = $sender->getName();
        $sender->sendMessage("§l§8(§5!§8) §r§7You have Teleported into the §eWilderness!");
        $sender->addTitle("§eWilderness");
        $sender->addsubTitle("§bbuild bases explore the vast wilderness");
        return true;
    }

    public function onDamage(EntityDamageEvent $event) : void{
        $entity = $event->getEntity();
        if(!$entity instanceof Player) return;
        if($event->getCause() === EntityDamageEvent::CAUSE_FALL){
            if(in_array($entity->getName(), $this->inWild)){
                unset($this->inWild[array_search($entity->getName(), $this->inWild)]);
                $event->setCancelled(true);
            }
        }
    }
}