<?php

namespace core\addons;

use core\AncientLands;

use pocketmine\command\ConsoleCommandSender;
use pocketmine\level\Position;
use pocketmine\command\PluginCommand;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\Server;

class ListCommand extends PluginCommand
{

	private $plugin;

	public function __construct($name, AncientLands $plugin)
	{
		$this->plugin = $plugin;
		parent::__construct($name, $plugin);
		$this->setDescription("list all the online players.");
		$this->setUsage("/list");
		$this->setPermission("cmd.list");
	}

	public function execute(CommandSender $sender, string $label, array $args): bool
	{
		if (!$sender->hasPermission("cmd.list")) {
			$sender->sendMessage("§l§1(§b!§1) §r§cYou do not have permission to use this command.");
			return false;
		}
		if ($sender instanceof ConsoleCommandSender) {
			$sender->sendMessage("§l§1(§b!§1) §r§cThis command can only be used in-game.");
			return false;
		}
		$online = count(Server::getInstance()->getOnlinePlayers());
		$max = Server::getInstance()->getMaxPlayers();
		$sender->sendMessage("§r§6§lONLINE PLAYERS §r§7($online) / ($max)");
		$sender->sendMessage("§r§7Below Listed is All the Online Players on the Network:");
		$sender->sendMessage("§r§6Players: §r§7{$this->getPlayers()}");

		return true;
	}

	public  function getPlayers()
	{
		$onlines = AncientLands::getInstance()->getServer()->getOnlinePlayers();
		$playersList = "";
		foreach ($onlines as $player){
			if($player instanceof Player){
					$playersList.= $player->getName() . ", ";
				}
			}
		return $playersList ?? "None";
	}

}