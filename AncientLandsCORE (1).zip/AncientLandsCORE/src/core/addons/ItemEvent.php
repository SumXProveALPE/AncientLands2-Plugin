<?php

namespace Sinkerz\AncientLands\events;

use Sinkerz\AncientLands\Core;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Entity;
use pocketmine\entity\Zombie;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityEffectAddEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Explosion;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\PiggyCustomEnchants;
use DaPigGuy\PiggyCustomEnchants\CustomEnchantManager;
use onebone\economyapi\EconomyAPI;
use _64FF00\PurePerms\PPGroup;

class ItemEvents implements Listener{

	/** @var array */
	public $plugin;
	/**
	 * @var ConsoleCommandSender
	 */
	private $console;

	public const USE_COMMON = 1000;

	public const RARE_USE = 2000;

	public const UNCOMMON_USE = 6000;
	public const MYTHIC_USE = 10000;

	public function __construct(Core $plugin) {
		$this->plugin = $plugin;
		$this->console = new ConsoleCommandSender();
	}

	/**
	 * @param PlayerInteractEvent $event
	 */
	public function onTouch(PlayerInteractEvent $event) : void{
		$player = $event->getPlayer();
		$block = $event->getBlock();
		$inv = $player->getInventory();
		$hand = $inv->getItemInHand();
		$nbt = $hand->getNamedTag();
		if ($hand->getId() == 339 and $hand->getDamage() == 50) {
			if ($nbt->getByte("MoneyNote", false) == true) {
				if ($nbt->getInt("MoneyVersion", 1.0) == $this->plugin->money) {
					$money = $nbt->getInt("Money");
					EconomyAPI::getInstance()->addMoney($player->getName(), $money);
					$hand->setCount($hand->getCount() - 1);
					$inv->setItemInHand($hand);
					$player->sendTip("§l§b$ " . number_format($money) . "+");
					$event->setCancelled(true);
				}
			}
		}
		if ($hand->getId() == 384 and $hand->getDamage() == 50) {
			if ($nbt->getByte("ExperienceBottle", false) == true) {
				if ($nbt->getInt("ExperienceVersion", 1.0) == $this->plugin->experience) {
					$exp = $nbt->getInt("Experience");
					$player->addXp($exp);
					$hand->setCount($hand->getCount() - 1);
					$inv->setItemInHand($hand);
					$player->sendTip("§l§bEXP " . number_format($exp) . "+");
					$event->setCancelled(true);
				}
			}
		}
		// Custom \nEnchantment Book Tier: 1
		if ($hand->getId() == 340 and $hand->getDamage() == 100 and $hand->getCustomName() == "§r§bCommon Enchantment Book") {
			if($player->getCurrentTotalXp() <= self::USE_COMMON){
				$player->sendMessage("§r§cYou require more xp to open this §r§6Required EXP: ". self::USE_COMMON);
				return;
			}
			$hand->setCount($hand->getCount() - 1);
			$inv->setItemInHand($hand);
			$event->setCancelled(true);
			$reward = rand(1, 76);
			switch($reward) {
				case 1:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Telepathy"), 1));
					$item->setCustomName("§r§l§bTelepathy I\nEnchantment Book");
					$item->setLore([
						'§r§bAutomatically puts drops in inventory',
						'§r§7Tools Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$tag = $item->getNamedTag();
					$nbt->setInt("RandomToNotStack", mt_rand(-2147483647, 2147483647));
					$item->setNamedTag($nbt);
					$player->sendMessage("§l§b» §r§aYou earn Telepathy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					$player->sendMessage("§l§b» §r§aYou earn Telepathy Custom Enchantment");
					break;
				case 2:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Haste"), 1));
					$item->setCustomName("§r§l§bHaste I\nEnchantment Book");
					$item->setLore([
						'§r§bGives effect haste when hold',
						'§r§7Tools Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Haste Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 3:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Haste"), 2));
					$item->setCustomName("§r§l§bHaste II\nEnchantment Book");
					$item->setLore([
						'§r§bGives effect haste when hold',
						'§r§7Tools Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Haste Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 4:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Haste"), 3));
					$item->setCustomName("§r§l§bHaste III\nEnchantment Book");
					$item->setLore([
						'§r§bGives effect haste when hold',
						'§r§7Tools Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Haste Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 5:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Springs"), 1));
					$item->setCustomName("§r§l§bSprings I\nEnchantment Book");
					$item->setLore([
						'§r§bGives a jump boost',
						'§r§7Boots Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Springs Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 6:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Springs"), 2));
					$item->setCustomName("§r§l§bSprings II\nEnchantment Book");
					$item->setLore([
						'§r§bGives a jump boost',
						'§r§7Boots Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Springs Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 7:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Springs"), 3));
					$item->setCustomName("§r§l§bSprings III\nEnchantment Book");
					$item->setLore([
						'§r§bGives a jump boost',
						'§r§7Boots Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Springs Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 8:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cloaking"), 1));
					$item->setCustomName("§r§l§bCloaking I\nEnchantment Book");
					$item->setLore([
						'§r§bMakes skin invis',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cloaking Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 9:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Frozen"), 1));
					$item->setCustomName("§r§l§bFrozen I\nEnchantment Book");
					$item->setLore([
						'§r§bGives enemy slowness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Frozen Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 10:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Frozen"), 2));
					$item->setCustomName("§r§l§bFrozen II\nEnchantment Book");
					$item->setLore([
						'§r§bGives enemy slowness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Frozen Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 11:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Frozen"), 3));
					$item->setCustomName("§r§l§bFrozen III\nEnchantment Book");
					$item->setLore([
						'§r§bGives enemy slowness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Frozen Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 19:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("ShockWave"), 1));
					$item->setCustomName("§r§l§bShockWave I\nEnchantment Book");
					$item->setLore([
						'§r§bKnocks enemy back',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn ShockWave Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 20:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("ShockWave"), 2));
					$item->setCustomName("§r§l§bShockWave II\nEnchantment Book");
					$item->setLore([
						'§r§bKnocks enemy back',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn ShockWave Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 21:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("ShockWave"), 3));
					$item->setCustomName("§r§l§bShockWave III\nEnchantment Book");
					$item->setLore([
						'§r§bKnocks enemy back',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn ShockWave Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 22:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Confusion"), 1));
					$item->setCustomName("§r§l§bConfusion I\nEnchantment Book");
					$item->setLore([
						'§r§bGives Enemy Nausa',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Confusion Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 23:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Confusion"), 2));
					$item->setCustomName("§r§l§bConfusion II\nEnchantment Book");
					$item->setLore([
						'§r§bGives Enemy Nausa',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Confusion Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 24:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Confusion"), 3));
					$item->setCustomName("§r§l§bConfusion III\nEnchantment Book");
					$item->setLore([
						'§r§bGives Enemy Nausa',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Confusion Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 25:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Confusion"), 4));
					$item->setCustomName("§r§l§bConfusion IV\nEnchantment Book");
					$item->setLore([
						'§r§bGives Enemy Nausa',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Confusion Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 26:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Confusion"), 5));
					$item->setCustomName("§r§l§bConfusion V\nEnchantment Book");
					$item->setLore([
						'§r§bGives Enemy Nausa',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Confusion Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 27:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Pummel"), 1));
					$item->setCustomName("§r§l§bPummel I\nEnchantment Book");
					$item->setLore([
						'§r§bGives Enemy Slowness',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Pummel Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 28:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Pummel"), 2));
					$item->setCustomName("§r§l§bPummel II\nEnchantment Book");
					$item->setLore([
						'§r§bGives Enemy Slowness',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Pummel Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 29:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Pummel"), 3));
					$item->setCustomName("§r§l§bPummel III\nEnchantment Book");
					$item->setLore([
						'§r§bGives Enemy Slowness',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Pummel Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 30:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Smelting"), 1));
					$item->setCustomName("§r§l§bSmelting I\nEnchantment Book");
					$item->setLore([
						'§r§bAutomatically smelts drops when block broken',
						'§r§7Tools Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Smelting Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 31:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Glowing"), 1));
					$item->setCustomName("§r§l§bGlowing I\nEnchantment Book");
					$item->setLore([
						'§r§bGives effect night vision',
						'§r§7Helmets Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Glowing Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 32:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 1));
					$item->setCustomName("§r§l§bWither I\nEnchantment Book");
					$item->setLore([
						'§r§bInflict Wither on enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Wither Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 33:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 2));
					$item->setCustomName("§r§l§bWither II\nEnchantment Book");
					$item->setLore([
						'§r§bInflict Wither on enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Wither Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 34:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 3));
					$item->setCustomName("§r§l§bWither III\nEnchantment Book");
					$item->setLore([
						'§r§bInflict Wither on enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Wither Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 35:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 4));
					$item->setCustomName("§r§l§bWither IV\nEnchantment Book");
					$item->setLore([
						'§r§bInflict Wither on enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Wither Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 36:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 5));
					$item->setCustomName("§r§l§bWither V\nEnchantment Book");
					$item->setLore([
						'§r§bInflict Wither on enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Wither Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 37:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 1));
					$item->setCustomName("§r§l§bQuickening I\nEnchantment Book");
					$item->setLore([
						'§r§bGain speed upon breaking block',
						'§r§7Pickaxe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 38:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 1));
					$item->setCustomName("§r§l§bPoison I\nEnchantment Book");
					$item->setLore([
						'§r§bInflict Poison on enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Poison Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 39:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 2));
					$item->setCustomName("§r§l§bPoison II\nEnchantment Book");
					$item->setLore([
						'§r§bInflict Poison on enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Poison Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 40:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 3));
					$item->setCustomName("§r§l§bPoison III\nEnchantment Book");
					$item->setLore([
						'§r§bInflict Poison on enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Poison Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 41:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 4));
					$item->setCustomName("§r§l§bPoison IV\nEnchantment Book");
					$item->setLore([
						'§r§bInflict Poison on enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Poison Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 42:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 5));
					$item->setCustomName("§r§l§bPoison V\nEnchantment Book");
					$item->setLore([
						'§r§bInflict Poison on enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Poison Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 43:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Vampire"), 1));
					$item->setCustomName("§r§l§bVampire I\nEnchantment Book");
					$item->setLore([
						'§r§bConverts damage dealt into health',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Vampire Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 44:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blind"), 1));
					$item->setCustomName("§r§l§bBlind I\nEnchantment Book");
					$item->setLore([
						'§r§bInflict blindness upon hitting enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Blindness Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 45:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blind"), 2));
					$item->setCustomName("§r§l§bBlind II\nEnchantment Book");
					$item->setLore([
						'§r§bInflict blindness upon hitting enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Blindness Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 46:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blind"), 3));
					$item->setCustomName("§r§l§bBlind III\nEnchantment Book");
					$item->setLore([
						'§r§bInflict blindness upon hitting enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Blindness Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 47:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blind"), 4));
					$item->setCustomName("§r§l§bBlind IV\nEnchantment Book");
					$item->setLore([
						'§r§bInflict blindness upon hitting enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Blindness Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 48:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blind"), 5));
					$item->setCustomName("§r§l§bBlind V\nEnchantment Book");
					$item->setLore([
						'§r§bInflict blindness upon hitting enemies',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Blindness Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 49:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Obsidianshield"), 1));
					$item->setCustomName("§r§l§bObsidian Shield I\nEnchantment Book");
					$item->setLore([
						'§r§bGrants fire resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Obsidian Shield Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 50:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Aegis"), 1));
					$item->setCustomName("§r§l§bAegis I\nEnchantment Book");
					$item->setLore([
						'§r§bGrants resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Aegis Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 51:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Angel"), 1));
					$item->setCustomName("§r§l§bAngel I\nEnchantment Book");
					$item->setLore([
						'§r§bGrants regeneration',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Angel Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 52:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Angel"), 2));
					$item->setCustomName("§r§l§bAngel II\nEnchantment Book");
					$item->setLore([
						'§r§bGrants regeneration',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Angel Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 53:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Angel"), 3));
					$item->setCustomName("§r§l§bAngel III\nEnchantment Book");
					$item->setLore([
						'§r§bGrants regeneration',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Angel Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 54:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poisoned"), 3));
					$item->setCustomName("§r§l§bPoison I\nEnchantment Book");
					$item->setLore([
						'§r§bPoisons Attacker',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Poisoned Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 55:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poisoned"), 3));
					$item->setCustomName("§r§l§bPoison II\nEnchantment Book");
					$item->setLore([
						'§r§bPoisons Attacker',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Poisoned Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 56:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Aerial"), 1));
					$item->setCustomName("§r§l§bAerial I\nEnchantment Book");
					$item->setLore([
						'§r§bDoes more dmg to enemy in air',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Aerial Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 57:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Aerial"), 2));
					$item->setCustomName("§r§l§bAerial II\nEnchantment Book");
					$item->setLore([
						'§r§bDoes more dmg to enemy in air',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Aerial Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 58:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Aerial"), 3));
					$item->setCustomName("§r§l§bAerial III\nEnchantment Book");
					$item->setLore([
						'§r§bDoes more dmg to enemy in air',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Aerial Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 59:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Aerial"), 4));
					$item->setCustomName("§r§l§bAerial IV\nEnchantment Book");
					$item->setLore([
						'§r§bDoes more dmg to enemy in air',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Aerial Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 60:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Aerial"), 5));
					$item->setCustomName("§r§l§bAerial V\nEnchantment Book");
					$item->setLore([
						'§r§bDoes more dmg to enemy in air',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Aerial Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 66:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Solitude"), 1));
					$item->setCustomName("§r§l§bSolitude I\nEnchantment Book");
					$item->setLore([
						'§r§bSolitude',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Solitude Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 67:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Solitude"), 2));
					$item->setCustomName("§r§l§bSolitude II\nEnchantment Book");
					$item->setLore([
						'§r§bSolitude',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Solitude Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 68:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Solitude"), 3));
					$item->setCustomName("§r§l§bSolitude III\nEnchantment Book");
					$item->setLore([
						'§r§bSolitude',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Solitude Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 69:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poisoned"), 3));
					$item->setCustomName("§r§l§bPoison III\nEnchantment Book");
					$item->setLore([
						'§r§bPoisons Attacker',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Poisoned Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 70:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 1));
					$item->setCustomName("§r§l§bWither I\nEnchantment Book");
					$item->setLore([
						'§r§bChance to get Wither',
						'§r§7Wither Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Wither Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 71:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Feather Weight"), 1));
					$item->setCustomName("§r§l§bFeather Weight I\nEnchantment Book");
					$item->setLore([
						'§r§bFeather Weight',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Feather Weigth Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 72:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Feather Weight"), 2));
					$item->setCustomName("§r§l§bFeather Weight II\nEnchantment Book");
					$item->setLore([
						'§r§bFeather Weight',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Feather Weight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 73:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Feather Weight"), 3));
					$item->setCustomName("§r§l§bFeather Weight III\nEnchantment Book");
					$item->setLore([
						'§r§bFeather Weight',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Feather Weight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 74:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Feather Weight"), 4));
					$item->setCustomName("§r§l§bFeather Weight IV\nEnchantment Book");
					$item->setLore([
						'§r§bFeather Weight',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Feather Weight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 75:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Feather Weight"), 5));
					$item->setCustomName("§r§l§bFeather Weight V\nEnchantment Book");
					$item->setLore([
						'§r§bFeather Weight',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Feather Weight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 76:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Evasion"), 1));
					$item->setCustomName("§r§l§bEvasion I\nEnchantment Book");
					$item->setLore([
						'§r§bChance to evade bow attack',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Evasion Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
			}
		}

		// Custom \nEnchantment Book Tier: 2
		if ($hand->getId() == 340 and $hand->getDamage() == 101 and $hand->getCustomName() == "§r§eUncommon Enchantment Book") {
			if($player->getCurrentTotalXp() <= self::UNCOMMON_USE){
				$player->sendMessage("§r§cYou require more xp to open this §r§6Required EXP: ". self::UNCOMMON_USE);
				return;
			}
			$hand->setCount($hand->getCount() - 1);
			$inv->setItemInHand($hand);
			$event->setCancelled(true);
			$reward = rand(1, 103);
			switch($reward) {
				case 1:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Execute"), 1));
					$item->setCustomName("§r§l§eExecute I\nEnchantment Book");
					$item->setLore([
						'§r§eExecute',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Execute Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 2:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Execute"), 2));
					$item->setCustomName("§r§l§eExecute II\nEnchantment Book");
					$item->setLore([
						'§r§eExecute',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Execute Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 3:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Execute"), 3));
					$item->setCustomName("§r§l§eExecute III\nEnchantment Book");
					$item->setLore([
						'§r§eExecute',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Execute Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 4:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cursed"), 1));
					$item->setCustomName("§r§l§eCursed I\nEnchantment Book");
					$item->setLore([
						'§r§eGives wither to attacker',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cursed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 5:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cursed"), 2));
					$item->setCustomName("§r§l§eCursed II\nEnchantment Book");
					$item->setLore([
						'§r§eGives wither to attacker',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cursed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 6:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cursed"), 3));
					$item->setCustomName("§r§l§eCursed III\nEnchantment Book");
					$item->setLore([
						'§r§eGives wither to attacker',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cursed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 7:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cursed"), 4));
					$item->setCustomName("§r§l§eCursed IV\nEnchantment Book");
					$item->setLore([
						'§r§eGives wither to attacker',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cursed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 8:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cursed"), 5));
					$item->setCustomName("§r§l§eCursed V\nEnchantment Book");
					$item->setLore([
						'§r§eGives wither to attacker',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cursed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 9:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Fertilizer"), 1));
					$item->setCustomName("§r§l§eFertilizer I\nEnchantment Book");
					$item->setLore([
						'§r§eCreates farmland in a level radius around the block',
						'§r§7Hoe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Fertilizer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 10:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lumberjack"), 1));
					$item->setCustomName("§r§l§eLumberjack I\nEnchantment Book");
					$item->setLore([
						'§r§eMines all logs connected to log when broken',
						'§r§7Axe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lumberjack Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 11:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Focused"), 1));
					$item->setCustomName("§r§l§eFocused I\nEnchantment Book");
					$item->setLore([
						'§r§e20% (1 = level) chance Immunity to Nausea',
						'§r§7Helmets Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Focused Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 12:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Focused"), 2));
					$item->setCustomName("§r§l§eFocused II\nEnchantment Book");
					$item->setLore([
						'§r§e20% (1 = level) chance Immunity to Nausea',
						'§r§7Helmets Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Focused Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 13:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Focused"), 3));
					$item->setCustomName("§r§l§eFocused III\nEnchantment Book");
					$item->setLore([
						'§r§e20% (1 = level) chance Immunity to Nausea',
						'§r§7Helmets Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Focused Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 14:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blessed"), 1));
					$item->setCustomName("§r§l§eBlessed I\nEnchantment Book");
					$item->setLore([
						'§r§e20% (1 = level) chance Immunity to Nausea',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Blessed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 15:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blessed"), 2));
					$item->setCustomName("§r§l§eBlessed II\nEnchantment Book");
					$item->setLore([
						'§r§e20% (1 = level) chance Immunity to Nausea',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Blessed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 16:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blessed"), 3));
					$item->setCustomName("§r§l§eBlessed III\nEnchantment Book");
					$item->setLore([
						'§r§e20% (1 = level) chance Immunity to Nausea',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Blessed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 17:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Farmer"), 1));
					$item->setCustomName("§r§l§eFarmer I\nEnchantment Book");
					$item->setLore([
						'§r§eAutomatically replace seeds when crop is broken',
						'§r§7Hoe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Farmer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 18:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Nourish"), 1));
					$item->setCustomName("§r§l§eNourish I\nEnchantment Book");
					$item->setLore([
						'§r§eGrants immunty to wither',
						'§r§7Helmet Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Nourish Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 19:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Nourish"), 2));
					$item->setCustomName("§r§l§eNourish II\nEnchantment Book");
					$item->setLore([
						'§r§eGrants immunty to wither',
						'§r§7Helmet Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Nourish Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 20:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Nourish"), 3));
					$item->setCustomName("§r§l§eNourish III\nEnchantment Book");
					$item->setLore([
						'§r§eGrants immunty to wither',
						'§r§7Helmet Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Nourish Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 21:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Nourish"), 4));
					$item->setCustomName("§r§l§eNourish IV\nEnchantment Book");
					$item->setLore([
						'§r§eGrants immunty to wither',
						'§r§7Helmet Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Nourish Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 22:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Nourish"), 5));
					$item->setCustomName("§r§l§eNourish V\nEnchantment Book");
					$item->setLore([
						'§r§eGrants immunty to wither',
						'§r§7Helmet Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Nourish Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 23:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 1));
					$item->setCustomName("§r§l§eQuickening I\nEnchantment Book");
					$item->setLore([
						'§r§eGain speed upon breaking block',
						'§r§7Pickaxe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 24:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 2));
					$item->setCustomName("§r§l§eQuickening II\nEnchantment Book");
					$item->setLore([
						'§r§eGain speed upon breaking block',
						'§r§7Pickaxe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 25:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 3));
					$item->setCustomName("§r§l§eQuickening III\nEnchantment Book");
					$item->setLore([
						'§r§eGain speed upon breaking block',
						'§r§7Pickaxe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 26:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 4));
					$item->setCustomName("§r§l§eQuickening IV\nEnchantment Book");
					$item->setLore([
						'§r§eGain speed upon breaking block',
						'§r§7Pickaxe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 27:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 5));
					$item->setCustomName("§r§l§eQuickening V\nEnchantment Book");
					$item->setLore([
						'§r§eGain speed upon breaking block',
						'§r§7Pickaxe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 28:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 1));
					$item->setCustomName("§r§l§eRevive I\nEnchantment Book");
					$item->setLore([
						'§r§eGain another life',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 29:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 2));
					$item->setCustomName("§r§l§eRevive II\nEnchantment Book");
					$item->setLore([
						'§r§eGain another life',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 30:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 3));
					$item->setCustomName("§r§l§eRevive III\nEnchantment Book");
					$item->setLore([
						'§r§eGain another life',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 31:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 4));
					$item->setCustomName("§r§l§eRevive VI\nEnchantment Book");
					$item->setLore([
						'§r§eGain another life',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 32:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 5));
					$item->setCustomName("§r§l§eRevive V\nEnchantment Book");
					$item->setLore([
						'§r§eGain another life',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 33:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Volley"), 1));
					$item->setCustomName("§r§l§eVolley I\nEnchantment Book");
					$item->setLore([
						'§r§eShoots multiple arrows in a cone shape',
						'§r§7Bow Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Volley Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 34:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("VooDoo"), 1));
					$item->setCustomName("§r§l§eVoodoo I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither effect',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Voodoo Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 35:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("VooDoo"), 2));
					$item->setCustomName("§r§l§eVoodoo II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither effect',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Voodoo Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 36:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("VooDoo"), 3));
					$item->setCustomName("§r§l§eVoodoo III\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither effect',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Voodoo Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 37:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("VooDoo"), 4));
					$item->setCustomName("§r§l§eVoodoo IV\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither effect',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Voodoo Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 38:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("VooDoo"), 5));
					$item->setCustomName("§r§l§eVoodoo V\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither effect',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Voodoo Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 39:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("VooDoo"), 6));
					$item->setCustomName("§r§l§eVoodoo VI\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither effect',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Voodoo Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 40:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("VooDoo"), 7));
					$item->setCustomName("§r§l§eVoodoo VII\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither effect',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Voodoo Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 41:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("VooDoo"), 8));
					$item->setCustomName("§r§l§eVoodoo VIII\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither effect',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Voodoo Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 42:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("VooDoo"), 9));
					$item->setCustomName("§r§l§eVoodoo IX\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither effect',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Voodoo Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 43:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("VooDoo"), 10));
					$item->setCustomName("§r§l§eVoodoo X\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither effect',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Voodoo Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 44:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cripple"), 1));
					$item->setCustomName("§r§l§dCripple I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to cripple enemies',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cripple Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 45:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cripple"), 2));
					$item->setCustomName("§r§l§eCripple II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to cripple enemies',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cripple Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 46:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cripple"), 3));
					$item->setCustomName("§r§l§eCripple III\nEnchantment Book");
					$item->setLore([
						'§r§eChance to cripple enemies',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cripple Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 47:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cripple"), 4));
					$item->setCustomName("§r§l§eCripple IV\nEnchantment Book");
					$item->setLore([
						'§r§eChance to cripple enemies',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cripple Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 48:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cripple"), 5));
					$item->setCustomName("§r§l§eCripple V\nEnchantment Book");
					$item->setLore([
						'§r§eChance to cripple enemies',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cripple Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 49:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Oxygenate"), 1));
					$item->setCustomName("§r§l§eOxygenate I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to give water breathing',
						'§r§7Pickaxe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Oxygenate Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 50:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enlighted"), 1));
					$item->setCustomName("§r§l§eEnlighted I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to give regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enlighted Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 51:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enlighted"), 2));
					$item->setCustomName("§r§l§eEnlighted II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to give regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enlighted Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 52:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enlighted"), 3));
					$item->setCustomName("§r§l§eEnlighted III\nEnchantment Book");
					$item->setLore([
						'§r§eChance to give regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enlighted Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 53:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enlighted"), 4));
					$item->setCustomName("§r§l§eEnlighted IV\nEnchantment Book");
					$item->setLore([
						'§r§eChance to give regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enlighted Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 54:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enlighted"), 5));
					$item->setCustomName("§r§l§eEnlighted V\nEnchantment Book");
					$item->setLore([
						'§r§eChance to give regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enlighted Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 55:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gooey"), 1));
					$item->setCustomName("§r§l§eGooey I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to fling enemies',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gooey Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 56:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gooey"), 2));
					$item->setCustomName("§r§l§eGooey II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to fling enemies',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gooey Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 57:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gooey"), 3));
					$item->setCustomName("§r§l§eGooey III\nEnchantment Book");
					$item->setLore([
						'§r§eChance to fling enemies',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gooey Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 58:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gooey"), 4));
					$item->setCustomName("§r§l§eGooey IV\nEnchantment Book");
					$item->setLore([
						'§r§eChance to fling enemies',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gooey Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 59:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gooey"), 5));
					$item->setCustomName("§r§l§eGooey V\nEnchantment Book");
					$item->setLore([
						'§r§eChance to fling enemies',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gooey Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 60:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Harvest"), 1));
					$item->setCustomName("§r§l§eHarvest I\nEnchantment Book");
					$item->setLore([
						'§r§eHarvest',
						'§r§7Hoe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Harvest Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 61:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Meditation"), 1));
					$item->setCustomName("§r§l§eMeditation I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to regain heath',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Meditation Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 62:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Meditation"), 2));
					$item->setCustomName("§r§l§eMeditation II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to regain heath',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Meditation Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 63:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Shielded"), 1));
					$item->setCustomName("§r§l§eShielded I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to gain resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Shielded Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 64:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Shielded"), 2));
					$item->setCustomName("§r§l§eShielded II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to gain resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Shielded Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 65:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Shielded"), 3));
					$item->setCustomName("§r§l§eShielded III\nEnchantment Book");
					$item->setLore([
						'§r§eChance to gain resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Shielded Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 66:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Shielded"), 4));
					$item->setCustomName("§r§l§eShielded IV\nEnchantment Book");
					$item->setLore([
						'§r§eChance to gain resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Shielded Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 67:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Shielded"), 5));
					$item->setCustomName("§r§l§eShielded V\nEnchantment Book");
					$item->setLore([
						'§r§eChance to gain resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Shielded Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 68:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Endershift"), 1));
					$item->setCustomName("§r§l§eEndershift I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to gain speed and absorpition',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Endershift Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 69:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Endershift"), 2));
					$item->setCustomName("§r§l§eEndershift II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to gain speed and absorpition',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Endershift Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 70:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Endershift"), 3));
					$item->setCustomName("§r§l§eEndershift III\nEnchantment Book");
					$item->setLore([
						'§r§eChance to gain speed and absorpition',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Endershift Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 71:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Endershift"), 4));
					$item->setCustomName("§r§l§eEndershift IV\nEnchantment Book");
					$item->setLore([
						'§r§eChance to gain speed and absorpition',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Endershift Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 72:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Endershift"), 5));
					$item->setCustomName("§r§l§eEndershift V\nEnchantment Book");
					$item->setLore([
						'§r§eChance to gain speed and absorpition',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Endershift Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 73:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Unholy"), 1));
					$item->setCustomName("§r§l§eUnholy I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither and weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Unholy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 74:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Unholy"), 2));
					$item->setCustomName("§r§l§eUnholy II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither and weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Unholy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 75:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Unholy"), 3));
					$item->setCustomName("§r§l§eUnholy III\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither and weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Unholy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 76:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Unholy"), 4));
					$item->setCustomName("§r§l§eUnholy IV\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with wither and weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Unholy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 77:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Valor"), 1));
					$item->setCustomName("§r§l§eValor I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to reduce axe damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Valor Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 78:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Valor"), 2));
					$item->setCustomName("§r§l§eValor II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to reduce axe damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Valor Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 79:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Valor"), 3));
					$item->setCustomName("§r§l§eValor III\nEnchantment Book");
					$item->setLore([
						'§r§eChance to reduce axe damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Valor Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 80:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Valor"), 4));
					$item->setCustomName("§r§l§eValor IV\nEnchantment Book");
					$item->setLore([
						'§r§eChance to reduce axe damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Valor Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 81:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Weakening"), 1));
					$item->setCustomName("§r§l§eWeakening I\nEnchantment Book");
					$item->setLore([
						'§r§eWeakening',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Weakening Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 82:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Ragdoll"), 1));
					$item->setCustomName("§r§l§eRagdoll I\nEnchantment Book");
					$item->setLore([
						'§r§eRagdoll',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Ragdoll Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 83:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Metaphysical"), 1));
					$item->setCustomName("§r§l§eMetaphysical I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to remove slowness and mining fatigue',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Metaphysical Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 84:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cleave"), 1));
					$item->setCustomName("§r§l§eCleave I\nEnchantment Book");
					$item->setLore([
						'§r§Cleave',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Reforge Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 85:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cleave"), 1));
					$item->setCustomName("§r§l§eCleave I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to increase strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cleave Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 86:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cleave"), 2));
					$item->setCustomName("§r§l§eCleave II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to increase strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cleave Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 87:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cleave"), 3));
					$item->setCustomName("§r§l§eCleave III\nEnchantment Book");
					$item->setLore([
						'§r§eChance to increase strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cleave Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 88:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cleave"), 4));
					$item->setCustomName("§r§l§eCleave IV\nEnchantment Book");
					$item->setLore([
						'§r§eChance to increase strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cleave Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 89:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cleave"), 5));
					$item->setCustomName("§r§l§eCleave V\nEnchantment Book");
					$item->setLore([
						'§r§eChance to increase strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cleave Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 90:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cleave"), 6));
					$item->setCustomName("§r§l§eCleave VI\nEnchantment Book");
					$item->setLore([
						'§r§eChance to increase strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cleave Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 91:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cleave"), 7));
					$item->setCustomName("§r§l§eCleave VII\nEnchantment Book");
					$item->setLore([
						'§r§eChance to increase strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Cleave Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 92:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demise"), 1));
					$item->setCustomName("§r§l§eDemise I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict more damage when close to death',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demise Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 93:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demise"), 2));
					$item->setCustomName("§r§l§eDemise II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict more damage when close to death',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demise Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 94:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demise"), 3));
					$item->setCustomName("§r§l§eDemise III\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict more damage when close to death',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demise Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 95:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demise"), 4));
					$item->setCustomName("§r§l§eDemise IV\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict more damage when close to death',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demise Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 96:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demise"), 5));
					$item->setCustomName("§r§l§eDemise V\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict more damage when close to death',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demise Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 97:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demise"), 6));
					$item->setCustomName("§r§l§eDemise VI\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict more damage when close to death',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demise Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 98:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demise"), 7));
					$item->setCustomName("§r§l§eDemise VII\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict more damage when close to death',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demise Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 99:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dominate"), 1));
					$item->setCustomName("§r§l§eDominate I\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with weakness',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dominate Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 100:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dominate"), 2));
					$item->setCustomName("§r§l§eDominate II\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with weakness',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dominate Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 101:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dominate"), 3));
					$item->setCustomName("§r§l§eDominate III\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with weakness',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dominate Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 102:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dominate"), 4));
					$item->setCustomName("§r§l§eDominate IV\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with weakness',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dominate Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 103:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dominate"), 5));
					$item->setCustomName("§r§l§eDominate V\nEnchantment Book");
					$item->setLore([
						'§r§eChance to inflict enemies with weakness',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dominate Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
			}
		}
		// Custom \nEnchantment Book Tier: 3
		if ($hand->getId() == 340 and $hand->getDamage() == 102 and $hand->getCustomName() == "§r§6Rare Enchantment Book") {
			if($player->getCurrentTotalXp() <= self::RARE_USE){
				$player->sendMessage("§r§cYou require more xp to open this §r§6Required EXP: ". self::RARE_USE);
				return;
			}
			$hand->setCount($hand->getCount() - 1);
			$inv->setItemInHand($hand);
			$event->setCancelled(true);
			$reward = rand(1, 196);
			switch($reward) {
				case 1:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lifesteal"), 1));
					$item->setCustomName("§r§l§6Lifesteal I\nEnchantment Book");
					$item->setLore([
						'§r§6Steals health upon hitting enemy',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lifesteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 2:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lifesteal"), 2));
					$item->setCustomName("§r§l§6Lifesteal II\nEnchantment Book");
					$item->setLore([
						'§r§6Steals health upon hitting enemy',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lifesteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 3:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lifesteal"), 3));
					$item->setCustomName("§r§l§6Lifesteal III\nEnchantment Book");
					$item->setLore([
						'§r§6Steals health upon hitting enemy',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lifesteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 4:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lifesteal"), 4));
					$item->setCustomName("§r§l§6Lifesteal IV\nEnchantment Book");
					$item->setLore([
						'§r§6Steals health upon hitting enemy',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lifesteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 5:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lifesteal"), 5));
					$item->setCustomName("§r§l§6Lifesteal V\nEnchantment Book");
					$item->setLore([
						'§r§6Steals health upon hitting enemy',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lifesteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 6:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Rage"), 1));
					$item->setCustomName("§r§l§6Rage I\nEnchantment Book");
					$item->setLore([
						'§r§6Gains Strength when hold.',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Rage Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 7:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Rage"), 2));
					$item->setCustomName("§r§l§6Rage II\nEnchantment Book");
					$item->setLore([
						'§r§6Gains Strength when hold.',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Rage Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 8:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Rage"), 3));
					$item->setCustomName("§r§l§6Rage III\nEnchantment Book");
					$item->setLore([
						'§r§6Gains Strength when hold.',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Rage Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 9:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Rage"), 4));
					$item->setCustomName("§r§l§6Rage IV\nEnchantment Book");
					$item->setLore([
						'§r§6Gains Strength when hold.',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Rage Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 10:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Rage"), 5));
					$item->setCustomName("§r§l§6Rage V\nEnchantment Book");
					$item->setLore([
						'§r§6Gains Strength when hold.',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Rage Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 11:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathbringer"), 1));
					$item->setCustomName("§r§l§6Deathbringer I\nEnchantment Book");
					$item->setLore([
						'§r§6Increase sword damage',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathbringer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 12:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathbringer"), 2));
					$item->setCustomName("§r§l§6Deathbringer II\nEnchantment Book");
					$item->setLore([
						'§r§6Increase sword damage',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathbringer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 13:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathbringer"), 3));
					$item->setCustomName("§r§l§6Deathbringer III\nEnchantment Book");
					$item->setLore([
						'§r§6Increase sword damage',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathbringer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 14:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathbringer"), 4));
					$item->setCustomName("§r§l§6Deathbringer IV\nEnchantment Book");
					$item->setLore([
						'§r§6Increase sword damage',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathbringer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 15:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathbringer"), 5));
					$item->setCustomName("§r§l§6Deathbringer V\nEnchantment Book");
					$item->setLore([
						'§r§6Increase sword damage',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathbringer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 16:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathbringer"), 6));
					$item->setCustomName("§r§l§6Deathbringer VI\nEnchantment Book");
					$item->setLore([
						'§r§6Increase sword damage',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathbringer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 17:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathbringer"), 7));
					$item->setCustomName("§r§l§6Deathbringer VII\nEnchantment Book");
					$item->setLore([
						'§r§6Increase sword damage',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathbringer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 18:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathbringer"), 8));
					$item->setCustomName("§r§l§6Deathbringer VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Increase sword damage',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathbringer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 19:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathbringer"), 9));
					$item->setCustomName("§r§l§6Deathbringer IX\nEnchantment Book");
					$item->setLore([
						'§r§6Increase sword damage',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathbringer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 20:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathbringer"), 10));
					$item->setCustomName("§r§l§6Deathbringer X\nEnchantment Book");
					$item->setLore([
						'§r§6Increase sword damage',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathbringer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 21:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"), 1));
					$item->setCustomName("§r§l§6Overload I\nEnchantment Book");
					$item->setLore([
						'§r§6Gives 1 extra heart per level per armor piece',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overload Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 22:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"), 2));
					$item->setCustomName("§r§l§6Overload II\nEnchantment Book");
					$item->setLore([
						'§r§6Gives 1 extra heart per level per armor piece',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overload Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 23:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"), 3));
					$item->setCustomName("§r§l§6Overload III\nEnchantment Book");
					$item->setLore([
						'§r§6Gives 1 extra heart per level per armor piece',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overload Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 24:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"), 4));
					$item->setCustomName("§r§l§6Overload IV\nEnchantment Book");
					$item->setLore([
						'§r§6Gives 1 extra heart per level per armor piece',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overload Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 25:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"), 5));
					$item->setCustomName("§r§l§6Overload V\nEnchantment Book");
					$item->setLore([
						'§r§6Gives 1 extra heart per level per armor piece',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overload Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 26:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"), 5));
					$item->setCustomName("§r§l§6Overload V\nEnchantment Book");
					$item->setLore([
						'§r§6Gives 1 extra heart per level per armor piece',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overload Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 27:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"), 6));
					$item->setCustomName("§r§l§6Overload VI\nEnchantment Book");
					$item->setLore([
						'§r§6Gives 1 extra heart per level per armor piece',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overload Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 28:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"), 7));
					$item->setCustomName("§r§l§6Overload VII\nEnchantment Book");
					$item->setLore([
						'§r§6Gives 1 extra heart per level per armor piece',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overload Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 29:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"), 8));
					$item->setCustomName("§r§l§6Overload VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Gives 1 extra heart per level per armor piece',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overload Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 30:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"), 9));
					$item->setCustomName("§r§l§6Overload IX\nEnchantment Book");
					$item->setLore([
						'§r§6Gives 1 extra heart per level per armor piece',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overload Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 31:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overload"), 10));
					$item->setCustomName("§r§l§6Overload X\nEnchantment Book");
					$item->setLore([
						'§r§6Gives 1 extra heart per level per armor piece',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overload Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 32:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Antitoxin"), 1));
					$item->setCustomName("§r§l§6Antitoxin I\nEnchantment Book");
					$item->setLore([
						'§r§620% (1 = level) chance Immunity to poison',
						'§r§7Helmets Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Antitoxin Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 33:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Tank"), 1));
					$item->setCustomName("§r§l§6Tank I\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from axe by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Tank Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 34:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Tank"), 2));
					$item->setCustomName("§r§l§6Tank II\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from axe by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Tank Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 35:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Tank"), 3));
					$item->setCustomName("§r§l§6Tank III\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from axe by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Tank Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 36:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Tank"), 4));
					$item->setCustomName("§r§l§6Tank IV\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from axe by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Tank Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 37:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Tank"), 5));
					$item->setCustomName("§r§l§6Tank V\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from axe by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Tank Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 38:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Armored"), 1));
					$item->setCustomName("§r§l§6Armored I\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from sword by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Armored Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 39:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Armored"), 2));
					$item->setCustomName("§r§l§6Armored II\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from sword by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Armored Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 40:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Armored"), 3));
					$item->setCustomName("§r§l§6Armored III\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from sword by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Armored Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 41:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Armored"), 4));
					$item->setCustomName("§r§l§6Armored IV\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from sword by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Armored Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 42:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Armored"), 5));
					$item->setCustomName("§r§l§6Armored V\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from sword by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Armored Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 43:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Heavy"), 1));
					$item->setCustomName("§r§l§6Heavy I\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from bow by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Heavy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 44:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Heavy"), 2));
					$item->setCustomName("§r§l§6Heavy II\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from bow by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Heavy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 45:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Heavy"), 3));
					$item->setCustomName("§r§l§6Heavy III\nEnchantment Book");
					$item->setLore([
						'§r§6Decreases damage from bow by 10%',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Heavy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 46:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("AutoSell"), 1));
					$item->setCustomName("§r§l§6Auto Sell I\nEnchantment Book");
					$item->setLore([
						'§r§6Auto sells items from your inventory when mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Wovens Hack Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 47:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 1));
					$item->setCustomName("§r§l§6Insanity I\nEnchantment Book");
					$item->setLore([
						'§r§6Increases massive damage in Axes',
						'§r§7Axe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 48:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 2));
					$item->setCustomName("§r§l§6Insanity II\nEnchantment Book");
					$item->setLore([
						'§r§6Increases massive damage in Axes',
						'§r§7Axe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 49:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 3));
					$item->setCustomName("§r§l§6Insanity III\nEnchantment Book");
					$item->setLore([
						'§r§6Increases massive damage in Axes',
						'§r§7Axe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 50:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 4));
					$item->setCustomName("§r§l§6Insanity IV\nEnchantment Book");
					$item->setLore([
						'§r§6Increases massive damage in Axes',
						'§r§7Axe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 51:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 5));
					$item->setCustomName("§r§l§6Insanity V\nEnchantment Book");
					$item->setLore([
						'§r§6Increases massive damage in Axes',
						'§r§7Axe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 52:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 6));
					$item->setCustomName("§r§l§6Insanity VI\nEnchantment Book");
					$item->setLore([
						'§r§6Increases massive damage in Axes',
						'§r§7Axe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 53:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 6));
					$item->setCustomName("§r§l§6Insanity VI\nEnchantment Book");
					$item->setLore([
						'§r§6Increases massive damage in Axes',
						'§r§7Axe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 54:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 7));
					$item->setCustomName("§r§l§6Insanity VII\nEnchantment Book");
					$item->setLore([
						'§r§6Increases massive damage in Axes',
						'§r§7Axe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 55:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 8));
					$item->setCustomName("§r§l§6Insanity VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Increases massive damage in Axes',
						'§r§7Axe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 56:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deflect"), 1));
					$item->setCustomName("§r§l§6Deflect I\nEnchantment Book");
					$item->setLore([
						'§r§6Reflect enemies attack damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deflect Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 57:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deflect"), 2));
					$item->setCustomName("§r§l§6Deflect II\nEnchantment Book");
					$item->setLore([
						'§r§6Reflect enemies attack damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deflect Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 58:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deflect"), 3));
					$item->setCustomName("§r§l§6Deflect III\nEnchantment Book");
					$item->setLore([
						'§r§6Reflect enemies attack damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deflect Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 59:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deflect"), 4));
					$item->setCustomName("§r§l§6Deflect IV\nEnchantment Book");
					$item->setLore([
						'§r§6Reflect enemies attack damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deflect Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 60:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deflect"), 5));
					$item->setCustomName("§r§l§6Deflect V\nEnchantment Book");
					$item->setLore([
						'§r§6Reflect enemies attack damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deflect Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 61:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deflect"), 6));
					$item->setCustomName("§r§l§6Deflect VI\nEnchantment Book");
					$item->setLore([
						'§r§6Reflect enemies attack damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deflect Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 62:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deflect"), 7));
					$item->setCustomName("§r§l§6Deflect VII\nEnchantment Book");
					$item->setLore([
						'§r§6Reflect enemies attack damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deflect Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 63:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deflect"), 8));
					$item->setCustomName("§r§l§6Deflect VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Reflect enemies attack damage',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deflect Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 64:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Painkiller"), 1));
					$item->setCustomName("§r§l§6Painkiller I\nEnchantment Book");
					$item->setLore([
						'§r§6Aquired high level of resistance when low on health',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Painkiller Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 65:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Painkiller"), 2));
					$item->setCustomName("§r§l§6Painkiller II\nEnchantment Book");
					$item->setLore([
						'§r§6Aquired high level of resistance when low on health',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Painkiller Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 66:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Painkiller"), 3));
					$item->setCustomName("§r§l§6Painkiller III\nEnchantment Book");
					$item->setLore([
						'§r§6Aquired high level of resistance when low on health',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Painkiller Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 67:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Painkiller"), 4));
					$item->setCustomName("§r§l§6Painkiller IV\nEnchantment Book");
					$item->setLore([
						'§r§6Aquired high level of resistance when low on health',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Painkiller Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 68:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Painkiller"), 5));
					$item->setCustomName("§r§l§6Painkiller V\nEnchantment Book");
					$item->setLore([
						'§r§6Aquired high level of resistance when low on health',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Painkiller Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 69:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Painkiller"), 6));
					$item->setCustomName("§r§l§6Painkiller VI\nEnchantment Book");
					$item->setLore([
						'§r§6Aquired high level of resistance when low on health',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Painkiller Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 70:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Painkiller"), 7));
					$item->setCustomName("§r§l§6Painkiller VII\nEnchantment Book");
					$item->setLore([
						'§r§6Aquired high level of resistance when low on health',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Painkiller Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 71:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Painkiller"), 8));
					$item->setCustomName("§r§l§6Painkiller VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Aquired high level of resistance when low on health',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Painkiller Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 72:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Painkiller"), 9));
					$item->setCustomName("§r§l§6Painkiller IX\nEnchantment Book");
					$item->setLore([
						'§r§6Aquired high level of resistance when low on health',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Painkiller Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 73:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Painkiller"), 10));
					$item->setCustomName("§r§l§6Painkiller X\nEnchantment Book");
					$item->setLore([
						'§r§6Aquired high level of resistance when low on health',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Painkiller Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 74:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dodge"), 1));
					$item->setCustomName("§r§l§6Dodge I\nEnchantment Book");
					$item->setLore([
						'§r§6Dodges enemies attack',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dodge Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 75:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dodge"), 2));
					$item->setCustomName("§r§l§6Dodge II\nEnchantment Book");
					$item->setLore([
						'§r§6Dodges enemies attack',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dodge Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 76:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dodge"), 3));
					$item->setCustomName("§r§l§6Dodge III\nEnchantment Book");
					$item->setLore([
						'§r§6Dodges enemies attack',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dodge Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 77:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dodge"), 4));
					$item->setCustomName("§r§l§6Dodge IV\nEnchantment Book");
					$item->setLore([
						'§r§6Dodges enemies attack',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dodge Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 78:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dodge"), 5));
					$item->setCustomName("§r§l§6Dodge V\nEnchantment Book");
					$item->setLore([
						'§r§6Dodges enemies attack',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dodge Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 79:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dodge"), 6));
					$item->setCustomName("§r§l§6Dodge VI\nEnchantment Book");
					$item->setLore([
						'§r§6Dodges enemies attack',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dodge Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 80:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dodge"), 7));
					$item->setCustomName("§r§l§6Dodge VII\nEnchantment Book");
					$item->setLore([
						'§r§6Dodges enemies attack',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dodge Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 81:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Dodge"), 8));
					$item->setCustomName("§r§l§6Dodge VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Dodges enemies attack',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Dodge Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 82:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathforged"), 1));
					$item->setCustomName("§r§l§6Deathforged I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathforged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 83:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathforged"), 2));
					$item->setCustomName("§r§l§6Deathforged II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn DeathForged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 84:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathforged"), 3));
					$item->setCustomName("§r§l§6Deathforged III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathforged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 85:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathforged"), 4));
					$item->setCustomName("§r§l§6Deathforged IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathforged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 86:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathforged"), 5));
					$item->setCustomName("§r§l§6Deathforged 5\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathforged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 87:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathforged"), 6));
					$item->setCustomName("§r§l§6Deathforged VI\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathforged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 88:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathforged"), 7));
					$item->setCustomName("§r§l§6Deathforged VII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathforged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 89:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathforged"), 8));
					$item->setCustomName("§r§l§6Deathforged VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathforged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 90:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathforged"), 9));
					$item->setCustomName("§r§l§6Deathforged IX\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathforged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 91:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deathforged"), 10));
					$item->setCustomName("§r§l§6Deathforged X\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deathforged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 92:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Hallucination"), 1));
					$item->setCustomName("§r§l§6Hallucination I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to make your enemies hallucinate',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Hallucination Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 93:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Hallucination"), 2));
					$item->setCustomName("§r§l§6Hallucination II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to make your enemies hallucinate',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Hallucination Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 94:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Hallucination"), 3));
					$item->setCustomName("§r§l§6Hallucination III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to make your enemies hallucinate',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Hallucination Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 95:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Implants"), 1));
					$item->setCustomName("§r§l§6Implants I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to replenish hunger',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Implants Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 96:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Implants"), 2));
					$item->setCustomName("§r§l§6Implants II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to replenish hunger',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Implants Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 97:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Implants"), 3));
					$item->setCustomName("§r§l§6Implants III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to replenish hunger',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Implants Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 98:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Grind"), 1));
					$item->setCustomName("§r§l§6Grind I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase EXP while mining',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Grind Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 99:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Grind"), 2));
					$item->setCustomName("§r§l§6Grind II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase EXP while mining',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Grind Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 100:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Grind"), 3));
					$item->setCustomName("§r§l§6Grind III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase EXP while mining',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Grind Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 101:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Grind"), 4));
					$item->setCustomName("§r§l§6Grind IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase EXP while mining',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Grind Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 102:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Grind"), 5));
					$item->setCustomName("§r§l§6Grind V\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase EXP while mining',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Grind Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 103:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Grind"), 6));
					$item->setCustomName("§r§l§6Grind VI\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase EXP while mining',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Grind Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 104:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Grind"), 7));
					$item->setCustomName("§r§l§6Grind VII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase EXP while mining',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Grind Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 105:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Grind"), 8));
					$item->setCustomName("§r§l§6Grind VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase EXP while mining',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Grind Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 106:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Grind"), 9));
					$item->setCustomName("§r§l§6Grind IX\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase EXP while mining',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Grind Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 107:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Grind"), 10));
					$item->setCustomName("§r§l§6Grind X\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase EXP while mining',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Grind Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 108:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Assassin"), 1));
					$item->setCustomName("§r§l§6Assassin I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage while closer up',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Assassin Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 109:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Assassin"), 2));
					$item->setCustomName("§r§l§6Assassin II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage while closer up',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Assassin Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 110:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Assassin"), 3));
					$item->setCustomName("§r§l§6Assassin III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage while closer up',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Assassin Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 111:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Assassin"), 4));
					$item->setCustomName("§r§l§6Assassin IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage while closer up',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Assassin Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 112:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Assassin"), 5));
					$item->setCustomName("§r§l§6Assassin V\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage while closer up',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Assassin Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 113:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Assassin"), 6));
					$item->setCustomName("§r§l§6Assassin VI\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage while closer up',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Assassin Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 114:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Assassin"), 7));
					$item->setCustomName("§r§l§6Assassin VII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage while closer up',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Assassin Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 115:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Assassin"), 8));
					$item->setCustomName("§r§l§6Assassin VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to deal more damage while closer up',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Assassin Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 116:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Antiknockback"), 1));
					$item->setCustomName("§r§l§6Antiknockback I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to take n knockback',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Antiknockback Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 117:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Defense"), 1));
					$item->setCustomName("§r§l§6Defense I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to give resistace',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Defense Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 118:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Defense"), 2));
					$item->setCustomName("§r§l§6Defense II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to give resistace',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Defense Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 119:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Defense"), 3));
					$item->setCustomName("§r§l§6Defense III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to give resistace',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Defense Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 120:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Diminish"), 1));
					$item->setCustomName("§r§l§6Diminish I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to remove weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Diminish Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 121:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Diminish"), 2));
					$item->setCustomName("§r§l§6Diminish II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to remove weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Diminish Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 122:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Diminish"), 3));
					$item->setCustomName("§r§l§6Diminish III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to remove weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Diminish Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 123:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Diminish"), 4));
					$item->setCustomName("§r§l§6Diminish IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to remove weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Diminish Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 124:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Diminish"), 5));
					$item->setCustomName("§r§l§6Diminish V\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to remove weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Diminish Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 125:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Molten"), 1));
					$item->setCustomName("§r§l§6Molten I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to set enemies on fire',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Molten Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 126:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Molten"), 2));
					$item->setCustomName("§r§l§6Molten II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to set enemies on fire',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Molten Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 127:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Molten"), 3));
					$item->setCustomName("§r§l§6Molten III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to set enemies on fire',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Molten Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 128:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Destruction"), 1));
					$item->setCustomName("§r§l§6Destruction I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to remove strenght, speed, or jump boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Destruction Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 129:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Destruction"), 2));
					$item->setCustomName("§r§l§6Destruction II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to remove strenght, speed, or jump boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Destruction Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 130:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Destruction"), 3));
					$item->setCustomName("§r§l§6Destruction III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to remove strenght, speed, or jump boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Destruction Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 131:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Destruction"), 4));
					$item->setCustomName("§r§l§6Destruction IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to remove strenght, speed, or jump boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Destruction Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 132:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Destruction"), 5));
					$item->setCustomName("§r§l§6Destruction V\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to remove strenght, speed, or jump boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Destruction Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 133:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Resilience"), 1));
					$item->setCustomName("§r§l§6Resilience I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to gain health boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Resilence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 134:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Resilience"), 2));
					$item->setCustomName("§r§l§6Resilience II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to gain health boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Resilence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 135:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Resilience"), 3));
					$item->setCustomName("§r§l§6Resilience III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to gain health boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Resilence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 136:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Resilience"), 4));
					$item->setCustomName("§r§l§6Resilience IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to gain health boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Resilence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 137:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Resilience"), 5));
					$item->setCustomName("§r§l§6Resilience V\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to gain health boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Resilence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 138:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Resilience"), 6));
					$item->setCustomName("§r§l§6Resilience VI\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to gain health boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Resilence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 139:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Resilience"), 7));
					$item->setCustomName("§r§l§6Resilience VII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to gain health boost',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Resilence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 140:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Warmer"), 1));
					$item->setCustomName("§r§l§6Warmer I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to remove slowness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Warmer Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 141:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Keyplus"), 1));
					$item->setCustomName("§r§l§6Keyplus I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase keys while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Keyplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 142:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Keyplus"), 2));
					$item->setCustomName("§r§l§6Keyplus II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase keys while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Keyplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 143:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Keyplus"), 3));
					$item->setCustomName("§r§l§6Keyplus III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase keys while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Keyplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 144:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Keyplus"), 4));
					$item->setCustomName("§r§l§6Keyplus IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase keys while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Keyplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 145:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Keyplus"), 5));
					$item->setCustomName("§r§l§6Keyplus V\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase keys while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Keyplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 146:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Keyplus"), 6));
					$item->setCustomName("§r§l§6Keyplus VI\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase keys while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Keyplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 147:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Keyplus"), 7));
					$item->setCustomName("§r§l§6Keyplus VII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase keys while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Keyplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 148:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Keyplus"), 8));
					$item->setCustomName("§r§l§6Keyplus VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase keys while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Keyplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 149:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Keyplus"), 9));
					$item->setCustomName("§r§l§6Keyplus IX\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase keys while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Keyplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 150:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Keyplus"), 10));
					$item->setCustomName("§r§l§6Keyplus X\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase keys while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Keyplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 151:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Moneyfarm"), 1));
					$item->setCustomName("§r§l§6Moneyfarm I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Moneyfarm Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 152:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Moneyfarm"), 2));
					$item->setCustomName("§r§l§6Moneyfarm II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Moneyfarm Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 153:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Moneyfarm"), 3));
					$item->setCustomName("§r§l§6Moneyfarm III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Moneyfarm Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 154:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Moneyfarm"), 4));
					$item->setCustomName("§r§l§6Moneyfarm IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Moneyfarm Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 155:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Moneyfarm"), 5));
					$item->setCustomName("§r§l§6Moneyfarm V\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Moneyfarm Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 156:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Moneyfarm"), 6));
					$item->setCustomName("§r§l§6Moneyfarm VI\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Moneyfarm Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 157:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Moneyfarm"), 7));
					$item->setCustomName("§r§l§6Moneyfarm VII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Moneyfarm Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 158:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Pouchplus"), 1));
					$item->setCustomName("§r§l§6Pouchplus I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase pouches while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Pouchplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 159:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Pouchplus"), 2));
					$item->setCustomName("§r§l§6Pouchplus II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase pouches while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Pouchplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 160:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Pouchplus"), 3));
					$item->setCustomName("§r§l§6Pouchplus III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase pouches while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Pouchplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 161:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Pouchplus"), 4));
					$item->setCustomName("§r§l§6Pouchplus IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase pouches while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Pouchplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 162:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Pouchplus"), 5));
					$item->setCustomName("§r§l§6Pouchplus V\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase pouches while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Pouchplus Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 163:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Devour"), 1));
					$item->setCustomName("§r§l§6Devour I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase bleed damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Devour Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 164:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Devour"), 2));
					$item->setCustomName("§r§l§6Devour II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase bleed damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Devour Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 165:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Devour"), 3));
					$item->setCustomName("§r§l§6Devour III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase bleed damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Devour Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 166:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Devour"), 4));
					$item->setCustomName("§r§l§6Devour IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase bleed damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Devour Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 167:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deepwounds"), 1));
					$item->setCustomName("§r§l§6Deepwounds I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to give enemies deeper wounds',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deepwounds Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 168:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deepwounds"), 2));
					$item->setCustomName("§r§l§6Deepwounds II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to give enemies deeper wounds',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deepwounds Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 169:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Deepwounds"), 3));
					$item->setCustomName("§r§l§6Deepwounds III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to give enemies deeper wounds',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Deepwounds Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 170:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enraged"), 1));
					$item->setCustomName("§r§l§6Enraged I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to recive strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enraged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 171:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enraged"), 2));
					$item->setCustomName("§r§l§6Enraged II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to recive strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enraged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 172:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enraged"), 3));
					$item->setCustomName("§r§l§6Enraged III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to recive strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enraged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 173:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enraged"), 4));
					$item->setCustomName("§r§l§6Enraged IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to recive strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enraged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 174:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enraged"), 5));
					$item->setCustomName("§r§l§6Enraged V\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to recive strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enraged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 175:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enraged"), 6));
					$item->setCustomName("§r§l§6Enraged VI\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to recive strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enraged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 176:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enraged"), 7));
					$item->setCustomName("§r§l§6Enraged VII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to recive strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enraged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 177:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Enraged"), 8));
					$item->setCustomName("§r§l§6Enraged VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to recive strenght',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Enraged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 178:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Fling"), 1));
					$item->setCustomName("§r§l§6Fling I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to throw enemies up in the air',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Fling Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 179:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Fling"), 2));
					$item->setCustomName("§r§l§6Fling II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to throw enemies up in the air',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Fling Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 180:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Fling"), 3));
					$item->setCustomName("§r§l§6Fling III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to throw enemies up in the air',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Fling Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 181:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gravity"), 1));
					$item->setCustomName("§r§l§6Gravity I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to inflict enemies with levitation',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gravity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 182:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gravity"), 2));
					$item->setCustomName("§r§l§6Gravity II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to inflict enemies with levitation',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gravity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 183:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gravity"), 3));
					$item->setCustomName("§r§l§6Gravity II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to inflict enemies with levitation',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gravity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 184:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gravity"), 4));
					$item->setCustomName("§r§l§6Gravity IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to inflict enemies with levitation',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gravity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 185:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gravity"), 5));
					$item->setCustomName("§r§l§6Gravity V\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to inflict enemies with levitation',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gravity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 186:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gravity"), 6));
					$item->setCustomName("§r§l§6Gravity VI\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to inflict enemies with levitation',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gravity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 187:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gravity"), 7));
					$item->setCustomName("§r§l§6Gravity VII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to inflict enemies with levitation',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gravity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 188:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Gravity"), 8));
					$item->setCustomName("§r§l§6Gravity VIII\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to inflict enemies with levitation',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Gravity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 189:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Inquisitive"), 1));
					$item->setCustomName("§r§l§6Inquisitive I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase final damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Inquisitive Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 190:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Inquisitive"), 2));
					$item->setCustomName("§r§l§6Inquisitive II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase final damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Inquisitive Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 191:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Inquisitive"), 3));
					$item->setCustomName("§r§l§6Inquisitive III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase final damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Inquisitive Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 192:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Inquisitive"), 4));
					$item->setCustomName("§r§l§6Inquisitive IV\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to increase final damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Inquisitive Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 193:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Overdose"), 1));
					$item->setCustomName("§r§l§6Overdose I\nEnchantment Book");
					$item->setLore([
						'§r§6Overdose',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Overdose Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 194:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Skillswipe"), 1));
					$item->setCustomName("§r§l§6Skillwipe I\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to steal enemies EXP',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Skillswipe Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 195:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Skillswipe"), 2));
					$item->setCustomName("§r§l§6Skillwipe II\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to steal enemies EXP',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Skillswipe Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 196:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Skillswipe"), 3));
					$item->setCustomName("§r§l§6Skillwipe III\nEnchantment Book");
					$item->setLore([
						'§r§6Chance to steal enemies EXP',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Skillswipe Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
			}
		}
		if ($hand->getId() == 340 and $hand->getDamage() == 103 and $hand->getCustomName() == "§r§4Mythic Enchantment Book") {
			if($player->getCurrentTotalXp() <= self::MYTHIC_USE) {
				$player->sendMessage("§r§cYou require more xp to open this §r§6Required EXP: ". self::MYTHIC_USE);
				return;
			}
			$hand->setCount($hand->getCount() - 1);
			$inv->setItemInHand($hand);
			$event->setCancelled(true);
			$reward = rand(1, 94);
			switch($reward) {
				case 1:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Influx"), 1));
					$item->setCustomName("§r§l§4Influx I\nEnchantment Book");
					$item->setLore([
						'§r§4Chane to inflicts enemies massive poison, wither',
						'§r§4(Chance to ignore Antitoxin, Nourish enchants)',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Influx Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 2:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Influx"), 2));
					$item->setCustomName("§r§l§4Influx II\nEnchantment Book");
					$item->setLore([
						'§r§4Chane to inflicts enemies massive poison, wither',
						'§r§4(Chance to ignore Antitoxin, Nourish enchants)',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Influx Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 3:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Influx"), 3));
					$item->setCustomName("§r§l§4Influx III\nEnchantment Book");
					$item->setLore([
						'§r§4Chane to inflicts enemies massive poison, wither',
						'§r§4(Chance to ignore Antitoxin, Nourish enchants)',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Influx Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 4:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Shatterglass"), 1));
					$item->setCustomName("§r§l§4Shatterglass I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to weaken enemies amor durability',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Shatterglass Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 5:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Shatterglass"), 2));
					$item->setCustomName("§r§l§4Shatterglass II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to weaken enemies amor durability',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Shatterglass Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 6:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Shatterglass"), 3));
					$item->setCustomName("§r§l§4Shatterglass III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to weaken enemies amor durability',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Shatterglass Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 7:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Shatterglass"), 4));
					$item->setCustomName("§r§l§4Shatterglass IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to weaken enemies amor durability',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Shatterglass Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 8:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Shatterglass"), 5));
					$item->setCustomName("§r§l§4Shatterglass V\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to weaken enemies amor durability',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Shatterglass Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 9:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Bloodlost"), 1));
					$item->setCustomName("§r§l§4Bloodlost I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to inflict massive damage upon hitting enemies.',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Bloodlost Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 10:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Bloodlost"), 2));
					$item->setCustomName("§r§l§4Bloodlost II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to inflict massive damage upon hitting enemies.',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Bloodlost Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 11:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Bloodlost"), 3));
					$item->setCustomName("§r§l§4Bloodlost III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to inflict massive damage upon hitting enemies.',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Bloodlost Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 12:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Bloodlost"), 4));
					$item->setCustomName("§r§l§4Bloodlost IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to inflict massive damage upon hitting enemies.',
						'§r§7Sword Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Bloodlost Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 13:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Knight"), 1));
					$item->setCustomName("§r§l§4Knight I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to gain Invincible for 5 seconds',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Knight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 14:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Knight"), 2));
					$item->setCustomName("§r§l§4Knight II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to gain Invincible for 5 seconds',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Knight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 15:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Knight"), 3));
					$item->setCustomName("§r§l§4Knight III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to gain Invincible for 5 seconds',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Knight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 16:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Knight"), 4));
					$item->setCustomName("§r§l§4Knight IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to gain Invincible for 5 seconds',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Knight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;

				case 17:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Knight"), 5));
					$item->setCustomName("§r§l§4Knight V\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to gain Invincible for 5 seconds',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Knight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;

				case 18:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Knight"), 6));
					$item->setCustomName("§r§l§4Knight VI\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to gain Invincible for 5 seconds',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Knight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 19:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Knight"), 7));
					$item->setCustomName("§r§l§4Knight VII\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to gain Invincible for 5 seconds',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Knight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 20:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Knight"), 8));
					$item->setCustomName("§r§l§4Knight VIII\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to gain Invincible for 5 seconds',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Knight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 21:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Autoaim"), 1));
					$item->setCustomName("§r§l§4Auto Aim I\nEnchantment Book");
					$item->setLore([
						'§r§4Automatically aims to the nearest target.',
						'§r§7Bow Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Knight Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 22:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Clarity"), 1));
					$item->setCustomName("§r§l§4Clarity I\nEnchantment Book");
					$item->setLore([
						'§r§4Grants Immunity to poison',
						'§r§7Helmet Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Clarity Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 23:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BloodBerserk"), 1));
					$item->setCustomName("§r§l§4Blood Berserk I\nEnchantment Book");
					$item->setLore([
						'§r§4Decreases Bloodlost Enchantment Damage per lvl',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Blood Berserk Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 24:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Autorepair"), 1));
					$item->setCustomName("§r§l§4Autorepair I\nEnchantment Book");
					$item->setLore([
						'§r§4Automatically repairs items',
						'§r§7Global Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Autorepair Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 25:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Doomed"), 1));
					$item->setCustomName("§r§l§4Doomed I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to inflict enemies with wither, poison, slowness, or blindness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Doomed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 26:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Doomed"), 2));
					$item->setCustomName("§r§l§4Doomed II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to inflict enemies with wither, poison, slowness, or blindness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Doomed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 27:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Doomed"), 3));
					$item->setCustomName("§r§l§4Doomed III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to inflict enemies with wither, poison, slowness, or blindness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Doomed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 28:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Jackpot"), 1));
					$item->setCustomName("§r§l§4Jackpot I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Jackpot Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 29:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Jackpot"), 2));
					$item->setCustomName("§r§l§4Jackpot II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Jackpot Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 30:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Jackpot"), 3));
					$item->setCustomName("§r§l§4Jackpot III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Jackpot Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 31:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Jackpot"), 4));
					$item->setCustomName("§r§l§4Jackpot IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Jackpot Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 32:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Jackpot"), 5));
					$item->setCustomName("§r§l§4Jackpot V\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to increase money while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Jackpot Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 33:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lightning"), 1));
					$item->setCustomName("§r§l§4Lightning I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to get lighning bolts during attack',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lightning Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 34:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lightning"), 2));
					$item->setCustomName("§r§l§4Lightning II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to get lighning bolts during attack',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lightning Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 35:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lightning"), 3));
					$item->setCustomName("§r§l§4Lightning III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to get lighning bolts during attack',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lightning Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 36:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lightning"), 4));
					$item->setCustomName("§r§l§4Lightning I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to get lighning bolts during attack',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lightning Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 37:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lightning"), 5));
					$item->setCustomName("§r§l§4Lightning V\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to get lighning bolts during attack',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lightning Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 38:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lucky"), 1));
					$item->setCustomName("§r§l§4Lucky I\nEnchantment Book");
					$item->setLore([
						'§r§4Lucky',
						'§r§7Pickaxe Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Lucky Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 39:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Silence"), 1));
					$item->setCustomName("§r§l§4Silence I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove enemies regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Silence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 40:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Silence"), 2));
					$item->setCustomName("§r§l§4Silence II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove enemies regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Silence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 41:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Silence"), 3));
					$item->setCustomName("§r§l§4Silence III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove enemies regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Silence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 42:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Silence"), 4));
					$item->setCustomName("§r§l§4Silence IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove enemies regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Silence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 43:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Silence"), 5));
					$item->setCustomName("§r§l§4Silence V\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove enemies regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Silence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 44:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Silence"), 6));
					$item->setCustomName("§r§l§4Silence VI\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove enemies regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Silence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 45:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Silence"), 7));
					$item->setCustomName("§r§l§4Silence VII\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove enemies regeneration',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Silence Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 46:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Razoredged"), 1));
					$item->setCustomName("§r§l§4Razoredged I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove enemies money',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Razoredged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 47:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Razoredged"), 2));
					$item->setCustomName("§r§l§4Razoredged II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove enemies money',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Razoredged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 49:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Razoredged"), 3));
					$item->setCustomName("§r§l§4Razoredged III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove enemies money',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Razoredged Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 50:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Healing factor"), 1));
					$item->setCustomName("§r§l§4Healing Factor I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive regeneration',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Heal Factor Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 51:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Healing factor"), 2));
					$item->setCustomName("§r§l§4Healing Factor II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive regeneration',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Heal Factor Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 52:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Healing factor"), 3));
					$item->setCustomName("§r§l§4Healing Factor III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive regeneration',
						'§r§Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Heal Factor Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 53:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Healing factor"), 4));
					$item->setCustomName("§r§l§4Healing Factor IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive regeneration',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Heal Factor Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 54:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Healing factor"), 5));
					$item->setCustomName("§r§l§4Healing Factor V\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive regeneration',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Heal Factor Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 55:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demonic"), 1));
					$item->setCustomName("§r§l§4Demonic I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive fire resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demonic Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 56:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demonic"), 2));
					$item->setCustomName("§r§l§4Demonic II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive fire resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demonic Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 57:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demonic"), 3));
					$item->setCustomName("§r§l§4Demonic III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive fire resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demonic Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 58:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demonic"), 4));
					$item->setCustomName("§r§l§4Demonic IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive fire resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demonic Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 59:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Demonic"), 5));
					$item->setCustomName("§r§l§4Demonic V\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive fire resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Demonic Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 60:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Phoenix"), 1));
					$item->setCustomName("§r§l§4Phoenix I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive regeneration',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Phoenix Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 61:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Phoenix"), 2));
					$item->setCustomName("§r§l§4Phoenix II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive regeneration',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Phoenix Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 62:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Phoenix"), 3));
					$item->setCustomName("§r§l§4Phoenix III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to receive regeneration',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Phoenix Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 63:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Remendy"), 1));
					$item->setCustomName("§r§l§4Remendy I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Remendy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 64:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Remendy"), 2));
					$item->setCustomName("§r§l§4Remendy II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Remendy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 65:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Remendy"), 3));
					$item->setCustomName("§r§l§4Remendy III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Remendy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 66:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Remendy"), 4));
					$item->setCustomName("§r§l§4Remendy IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Remendy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 67:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Remendy"), 5));
					$item->setCustomName("§r§l§4Remendy V\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove weakness',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Remendy Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 68:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Block Master"), 1));
					$item->setCustomName("§r§l§4Block Master I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to add more blocks onto blocks mined',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Block Master Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 69:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Miner Luck"), 1));
					$item->setCustomName("§r§l§4Miner Luck I\nEnchantment Book");
					$item->setLore([
						'§r§4Increases luck while mining',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Miner Luck Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 70:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Bleed"), 1));
					$item->setCustomName("§r§l§4Bleed I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to make enemies bleed',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Bleed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 71:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Bleed"), 2));
					$item->setCustomName("§r§l§4Bleed II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to make enemies bleed',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Bleed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 72:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Bleed"), 3));
					$item->setCustomName("§r§l§4Bleed III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to make enemies bleed',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Bleed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 73:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Bleed"), 4));
					$item->setCustomName("§r§l§4Bleed IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to make enemies bleed',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Bleed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 74:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Bleed"), 5));
					$item->setCustomName("§r§l§4Bleed V\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to make enemies bleed',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Bleed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 75:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Bleed"), 6));
					$item->setCustomName("§r§l§4Bleed VI\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to make enemies bleed',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Bleed Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 76:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Genjutsu"), 1));
					$item->setCustomName("§r§l§4Genjutsu I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to swich places with an enemy',
						'§r§7Tool Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Genjutsu Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 77:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Soulsteal"), 1));
					$item->setCustomName("§r§l§4Soulsteal I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to steal an enemies soul',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Soulsteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 78:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Soulsteal"), 2));
					$item->setCustomName("§r§l§4Soulsteal II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to steal an enemies soul',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Soulsteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 79:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Soulsteal"), 3));
					$item->setCustomName("§r§l§4Soulsteal III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to steal an enemies soul',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Soulsteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 80:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Soulsteal"), 4));
					$item->setCustomName("§r§l§4Soulsteal IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to steal an enemies soul',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Soulsteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 81:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Soulsteal"), 5));
					$item->setCustomName("§r§l§4Soulsteal V\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to steal an enemies soul',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Soulsteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 82:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Soulsteal"), 6));
					$item->setCustomName("§r§l§4Soulsteal VI\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to steal an enemies soul',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Soulsteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 83:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Soulsteal"), 7));
					$item->setCustomName("§r§l§4Soulsteal VII\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to steal an enemies soul',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Soulsteal Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 84:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blackout"), 1));
					$item->setCustomName("§r§l§4Blackout I\nEnchantment Book");
					$item->setLore([
						'§r§4Blackout',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Blackout Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 85:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Disarmor Protection"), 1));
					$item->setCustomName("§r§l§4Disarmor Protection I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to protect from disarmor',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Disarmor Protection Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 86:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Neutralize"), 1));
					$item->setCustomName("§r§l§4Neutralize I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Neutralize Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 87:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Neutralize"), 2));
					$item->setCustomName("§r§l§4Neutralize II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Neutralize Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 88:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Neutralize"), 3));
					$item->setCustomName("§r§l§4Neutralize III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Neutralize Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 89:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Neutralize"), 4));
					$item->setCustomName("§r§l§4Neutralize IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to remove resistance',
						'§r§7Armor Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Neutralize Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 90:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Sharpen"), 1));
					$item->setCustomName("§r§l§4Sharpen I\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to increase damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Sharpen Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 91:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Sharpen"), 2));
					$item->setCustomName("§r§l§4Sharpen II\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to increase damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Sharpen Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 92:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Sharpen"), 3));
					$item->setCustomName("§r§l§4Sharpen III\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to increase damage',
						'§r§7WeaponEnchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Sharpen Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
				case 93:
					$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Sharpen"), 4));
					$item->setCustomName("§r§l§4Sharpen IV\nEnchantment Book");
					$item->setLore([
						'§r§4Chance to increase damage',
						'§r§7Weapon Enchantment',
						'§r§7Combine it into item to enchant'
					]);
					$player->sendMessage("§l§b» §r§aYou earn Sharpen Custom Enchantment");
					if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
						$player->getInventory()->addItem($item);
					}
					break;
			}
			if ($hand->getId() == 384 and $hand->getDamage() == 2 and $hand->getCustomName() == "§bExperience §3Bottle §7(Right Click)") {
				$hand->setCount($hand->getCount() - 1);
				$inv->setItemInHand($hand);
				$event->setCancelled(true);
				$reward = rand(1, 27);
				switch($reward) {
					case 1:
						$player->sendMessage("§l§b» §r§aYou earned 50 XP");
						$player->addXp("50");
						break;
					case 2:
						$player->sendMessage("§l§b» §r§aYou earned 61 XP");
						$player->addXp("61");
						break;
					case 3:
						$player->sendMessage("§l§b» §r§aYou earned 68 XP");
						$player->addXp("68");
						break;
					case 4:
						$player->sendMessage("§l§b» §r§aYou earned 69 XP");
						$player->addXp("69");
						break;
					case 5:
						$player->sendMessage("§l§b» §r§aYou earned 71 XP");
						$player->addXp("71");
						break;
					case 6:
						$player->sendMessage("§l§b» §r§aYou earned 78 XP");
						$player->addXp("78");
						break;
					case 7:
						$player->sendMessage("§l§b» §r§aYou earned 82 XP");
						$player->addXp("82");
						break;
					case 8:
						$player->sendMessage("§l§b» §r§aYou earned 73 XP");
						$player->addXp("73");
						break;
					case 9:
						$player->sendMessage("§l§b» §r§aYou earned 89 XP");
						$player->addXp("89");
						break;
					case 10:
						$player->sendMessage("§l§b» §r§aYou earned 76 XP");
						$player->addXp("76");
						break;
					case 11:
						$player->sendMessage("§l§b» §r§aYou earned 128 XP");
						$player->addXp("128");
						break;
					case 12:
						$player->sendMessage("§l§b» §r§aYou earned 908 XP");
						$player->addXp("908");
						break;
					case 13:
						$player->sendMessage("§l§b» §r§aYou earned 451 XP");
						$player->addXp("451");
						break;
					case 14:
						$player->sendMessage("§l§b» §r§aYou earned 651 XP");
						$player->addXp("651");
						break;
					case 15:
						$player->sendMessage("§l§b» §r§aYou earned 713 XP");
						$player->addXp("713");
						break;
					case 16:
						$player->sendMessage("§l§b» §r§aYou earned 816 XP");
						$player->addXp("816");
						break;
					case 17:
						$player->sendMessage("§l§b» §r§aYou earned 291 XP");
						$player->addXp("291");
						break;
					case 18:
						$player->sendMessage("§l§b» §r§aYou earned 371 XP");
						$player->addXp("371");
						break;
					case 19:
						$player->sendMessage("§l§b» §r§aYou earned 918 XP");
						$player->addXp("918");
						break;
					case 20:
						$player->sendMessage("§l§b» §r§aYou earned 456 XP");
						$player->addXp("456");
						break;
					case 21:
						$player->sendMessage("§l§b» §r§aYou earned 412 XP");
						$player->addXp("412");
						break;
					case 22:
						$player->sendMessage("§l§b» §r§aYou earned 219 XP");
						$player->addXp("219");
						break;
					case 23:
						$player->sendMessage("§l§b» §r§aYou earned 55 XP");
						$player->addXp("55");
						break;
					case 24:
						$player->sendMessage("§l§b» §r§aYou earned 59 XP");
						$player->addXp("59");
						break;
					case 25:
						$player->sendMessage("§l§b» §r§aYou earned 59 XP");
						$player->addXp("59");
						break;
					case 26:
						$player->sendMessage("§l§b» §r§aYou earned 101 XP");
						$player->addXp("101");
						break;
					case 27:
						$player->sendMessage("§l§b» §r§aYou earned 69 XP");
						$player->addXp("69");
						break;
					case 28:
						$player->sendMessage("§l§b» §r§aYou earned 69 XP");
						$player->addXp("68");
						break;
					case 29:
						$player->sendMessage("§l§b» §r§aYou earned 69 XP");
						$player->addXp("69");
						break;
					case 30:
						$player->sendMessage("§l§b» §r§aYou earned 69 XP");
						$player->addXp("108");
						break;
					case 31:
						$player->sendMessage("§l§b» §r§aYou earned 56 XP");
						$player->addXp("56");
						break;
					case 32:
						$player->sendMessage("§l§b» §r§aYou earned 231 XP");
						$player->addXp("69");
						break;
					case 33:
						$player->sendMessage("§l§b» §r§aYou earned 211 XP");
						$player->addXp("211");
						break;
					case 34:
						$player->sendMessage("§l§b» §r§aYou earned 208 XP");
						$player->addXp("208");
						break;
					case 35:
						$player->sendMessage("§l§b» §r§aYou earned 213 XP");
						$player->addXp("35");
						break;
					case 36:
						$player->sendMessage("§l§b» §r§aYou earned 53 XP");
						$player->addXp("53");
						break;
					case 37:
						$player->sendMessage("§l§b» §r§aYou earned 325 XP");
						$player->addXp("325");
						break;
					case 38:
						$player->sendMessage("§l§b» §r§aYou earned 39 XP");
						$player->addXp("105");
						break;
				}
			}
			if ($hand->getId() == 384 and $hand->getDamage() == 105 and $hand->getCustomName() == "§bExperience §3Bottle §7(Right Click)") {
				$hand->setCount($hand->getCount() - 1);
				$inv->setItemInHand($hand);
				$event->setCancelled(true);
				$reward = rand(1, 38);
				switch($reward) {
					case 1:
						$player->sendMessage("§l§b» §r§aYou earned 1000 XP");
						$player->addXp("1000");
						break;
					case 2:
						$player->sendMessage("§l§b» §r§aYou earned 2000 XP");
						$player->addXp("2000");
						break;
					case 3:
						$player->sendMessage("§l§b» §r§aYou earned 3000 XP");
						$player->addXp("3000");
						break;
					case 4:
						$player->sendMessage("§l§b» §r§aYou earned 4500 XP");
						$player->addXp("4500");
						break;
					case 5:
						$player->sendMessage("§l§b» §r§aYou earned 5600 XP");
						$player->addXp("5600");
						break;
					case 6:
						$player->sendMessage("§l§b» §r§aYou earned 8250 XP");
						$player->addXp("8250");
						break;
					case 7:
						$player->sendMessage("§l§b» §r§aYou earned 9851 XP");
						$player->addXp("9851");
						break;
					case 8:
						$player->sendMessage("§l§b» §r§aYou earned 1250 XP");
						$player->addXp("1250");
						break;
					case 9:
						$player->sendMessage("§l§b» §r§aYou earned 1005 XP");
						$player->addXp("1005");
						break;
					case 10:
						$player->sendMessage("§l§b» §r§aYou earned 2590 XP");
						$player->addXp("2590");
						break;
					case 11:
						$player->sendMessage("§l§b» §r§aYou earned 10,000 XP");
						$player->addXp("10000");
						break;
					case 12:
						$player->sendMessage("§l§b» §r§aYou earned 12,000 XP");
						$player->addXp("12000");
						break;
					case 13:
						$player->sendMessage("§l§b» §r§aYou earned 5600 XP");
						$player->addXp("5600");
						break;
					case 14:
						$player->sendMessage("§l§b» §r§aYou earned 2501 XP");
						$player->addXp("2501");
						break;
					case 15:
						$player->sendMessage("§l§b» §r§aYou earned 1599 XP");
						$player->addXp("1599");
						break;
					case 16:
						$player->sendMessage("§l§b» §r§aYou earned 12900 XP");
						$player->addXp("12900");
						break;
					case 17:
						$player->sendMessage("§l§b» §r§aYou earned 51000 XP");
						$player->addXp("51000");
						break;
					case 18:
						$player->sendMessage("§l§b» §r§aYou earned 5000 XP");
						$player->addXp("5000");
						break;
					case 19:
						$player->sendMessage("§l§b» §r§aYou earned 95000 XP");
						$player->addXp("95000");
						break;
					case 20:
						$player->sendMessage("§l§b» §r§aYou earned 12000 XP");
						$player->addXp("12000");
						break;
					case 21:
						$player->sendMessage("§l§b» §r§aYou earned 15000 XP");
						$player->addXp("15000");
						break;
					case 22:
						$player->sendMessage("§l§b» §r§aYou earned 75000 XP");
						$player->addXp("75000");
						break;
					case 23:
						$player->sendMessage("§l§b» §r§aYou earned 1003 XP");
						$player->addXp("1003");
						break;
					case 24:
						$player->sendMessage("§l§b» §r§aYou earned 1001 XP");
						$player->addXp("1001");
						break;
					case 25:
						$player->sendMessage("§l§b» §r§aYou earned 1002 XP");
						$player->addXp("1002");
						break;
					case 26:
						$player->sendMessage("§l§b» §r§aYou earned 1002 XP");
						$player->addXp("1002");
						break;
					case 27:
						$player->sendMessage("§l§b» §r§aYou earned 16969 XP");
						$player->addXp("16969");
						break;
					case 28:
						$player->sendMessage("§l§b» §r§aYou earned 16969 XP");
						$player->addXp("16969");
						break;
					case 29:
						$player->sendMessage("§l§b» §r§aYou earned 16969 XP");
						$player->addXp("16969");
						break;
					case 30:
						$player->sendMessage("§l§b» §r§aYou earned 16969 XP");
						$player->addXp("16969");
						break;
					case 31:
						$player->sendMessage("§l§b» §r§aYou earned 1000 XP");
						$player->addXp("1000");
						break;
					case 32:
						$player->sendMessage("§l§b» §r§aYou earned 6969 XP");
						$player->addXp("6969");
						break;
					case 33:
						$player->sendMessage("§l§b» §r§aYou earned 6969 XP");
						$player->addXp("6969");
						break;
					case 34:
						$player->sendMessage("§l§b» §r§aYou earned 6969 XP");
						$player->addXp("6969");
						break;
					case 35:
						$player->sendMessage("§l§b» §r§aYou earned 1269 XP");
						$player->addXp("1269");
						break;
					case 36:
						$player->sendMessage("§l§b» §r§aYou earned 1269 XP");
						$player->addXp("1269");
						break;
					case 37:
						$player->sendMessage("§l§b» §r§aYou earned 1325 XP");
						$player->addXp("1325");
						break;
					case 38:
						$player->sendMessage("§l§b» §r§aYou earned 1025 XP");
						$player->addXp("1025");
						break;
				}
			}
			if ($hand->getId() == 339 and $hand->getDamage() == 105 and $hand->getCustomName() == "§aMoney Note §7(Right Click)") {
				$hand->setCount($hand->getCount() - 1);
				$inv->setItemInHand($hand);
				$event->setCancelled(true);
				$reward = rand(1, 38);
				switch($reward) {
					case 1:
						$player->sendMessage("§l§b» §r§aYou earned 1000 Money");
						$player->addMoney("1000");
						break;
					case 2:
						$player->sendMessage("§l§b» §r§aYou earned 2000 Money");
						$player->addMoney("2000");
						break;
					case 3:
						$player->sendMessage("§l§b» §r§aYou earned 3000 Money");
						$player->addMoney("3000");
						break;
					case 4:
						$player->sendMessage("§l§b» §r§aYou earned 4500 Money");
						$player->addMoney("4500");
						break;
					case 5:
						$player->sendMessage("§l§b» §r§aYou earned 5600 Money");
						$player->addMoney("5600");
						break;
					case 6:
						$player->sendMessage("§l§b» §r§aYou earned 8250 Money");
						$player->addMoney("8250");
						break;
					case 7:
						$player->sendMessage("§l§b» §r§aYou earned 9851 Money");
						$player->addMoney("9851");
						break;
					case 8:
						$player->sendMessage("§l§b» §r§aYou earned 1250 Money");
						$player->addMoney("1250");
						break;
					case 9:
						$player->sendMessage("§l§b» §r§aYou earned 1005 Money");
						$player->addMoney("1005");
						break;
					case 10:
						$player->sendMessage("§l§b» §r§aYou earned 2590 Money");
						$player->addMoney("2590");
						break;
					case 11:
						$player->sendMessage("§l§b» §r§aYou earned 10,000 Money");
						$player->addMoney("10000");
						break;
					case 12:
						$player->sendMessage("§l§b» §r§aYou earned 12,000 Money");
						$player->addMoney("12000");
						break;
					case 13:
						$player->sendMessage("§l§b» §r§aYou earned 5600 Money");
						$player->addMoney("5600");
						break;
					case 14:
						$player->sendMessage("§l§b» §r§aYou earned 2501 Money");
						$player->addMoney("2501");
						break;
					case 15:
						$player->sendMessage("§l§b» §r§aYou earned 1599 Money");
						$player->addMoney("1599");
						break;
					case 16:
						$player->sendMessage("§l§b» §r§aYou earned 12900 Money");
						$player->addMoney("12900");
						break;
					case 17:
						$player->sendMessage("§l§b» §r§aYou earned 51000 Money");
						$player->addMoney("51000");
						break;
					case 18:
						$player->sendMessage("§l§b» §r§aYou earned 5000 Money");
						$player->addMoney("5000");
						break;
					case 19:
						$player->sendMessage("§l§b» §r§aYou earned 95000 Money");
						$player->addMoney("95000");
						break;
					case 20:
						$player->sendMessage("§l§b» §r§aYou earned 12000 Money");
						$player->addMoney("12000");
						break;
					case 21:
						$player->sendMessage("§l§b» §r§aYou earned 15000 Money");
						$player->addMoney("15000");
						break;
					case 22:
						$player->sendMessage("§l§b» §r§aYou earned 75000 Money");
						$player->addMoney("75000");
						break;
					case 23:
						$player->sendMessage("§l§b» §r§aYou earned 1003 Money");
						$player->addMoney("1003");
						break;
					case 24:
						$player->sendMessage("§l§b» §r§aYou earned 1001 Money");
						$player->addMoney("1001");
						break;
					case 25:
						$player->sendMessage("§l§b» §r§aYou earned 1002 Money");
						$player->addMoney("1002");
						break;
					case 26:
						$player->sendMessage("§l§b» §r§aYou earned 1002 Money");
						$player->addMoney("1002");
						break;
					case 27:
						$player->sendMessage("§l§b» §r§aYou earned 16969 Money");
						$player->addMoney("16969");
						break;
					case 28:
						$player->sendMessage("§l§b» §r§aYou earned 16969 Money");
						$player->addMoney("16969");
						break;
					case 29:
						$player->sendMessage("§l§b» §r§aYou earned 16969 Money");
						$player->addMoney("16969");
						break;
					case 30:
						$player->sendMessage("§l§b» §r§aYou earned 16969 Money");
						$player->addMoney("16969");
						break;
					case 31:
						$player->sendMessage("§l§b» §r§aYou earned 1000 Money");
						$player->addMoney("1000");
						break;
					case 32:
						$player->sendMessage("§l§b» §r§aYou earned 6969 Money");
						$player->addMoney("6969");
						break;
					case 33:
						$player->sendMessage("§l§b» §r§aYou earned 6969 Money");
						$player->addMoney("6969");
						break;
					case 34:
						$player->sendMessage("§l§b» §r§aYou earned 6969 Money");
						$player->addMoney("6969");
						break;
					case 35:
						$player->sendMessage("§l§b» §r§aYou earned 1269 Money");
						$player->addMoney("1269");
						break;
					case 36:
						$player->sendMessage("§l§b» §r§aYou earned 1269 Money");
						$player->addMoney("1269");
						break;
					case 37:
						$player->sendMessage("§l§b» §r§aYou earned 1325 Money");
						$player->addMoney("1325");
						break;
					case 38:
						$player->sendMessage("§l§b» §r§aYou earned 1025 Money");
						$player->addMoney("1025");
						break;
				}
			}
			if ($hand->getId() == 465 and $hand->getDamage() == 1) {
				$hand->setCount($hand->getCount() - 1);
				$inv->setItemInHand($hand);
				$event->setCancelled(true);
				$reward = rand(1, 4);
				switch($reward) {
					case 1:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh cow 1 ' . $player->getName());
						break;
					case 2:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh pig 1 ' . $player->getName());
						$player->addXp("61");
						break;
					case 3:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh Chicken 1 ' . $player->getName());
						break;
					case 4:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh Chicken 1 ' . $player->getName());
						break;
				}
			}
			if ($hand->getId() == 465 and $hand->getDamage() == 2) {
				$hand->setCount($hand->getCount() - 1);
				$inv->setItemInHand($hand);
				$event->setCancelled(true);
				$reward = rand(1, 4);
				switch($reward) {
					case 1:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh spider 1 ' . $player->getName());
						break;
					case 2:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh skeleton 1 ' . $player->getName());
						$player->addXp("61");
						break;
					case 3:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh enderman 1 ' . $player->getName());
						break;
					case 4:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh spider 1 ' . $player->getName());
						break;
				}
			}
			if ($hand->getId() == 465 and $hand->getDamage() == 3) {
				$hand->setCount($hand->getCount() - 1);
				$inv->setItemInHand($hand);
				$event->setCancelled(true);
				$reward = rand(1, 4);
				switch($reward) {
					case 1:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh blaze 1 ' . $player->getName());
						break;
					case 2:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh irongolem 1 ' . $player->getName());
						$player->addXp("61");
						break;
					case 3:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh vindicator 1 ' . $player->getName());
						break;
					case 4:
						$this->plugin->getServer()->dispatchCommand($this->console, 'nh blaze 1 ' . $player->getName());
						break;
				}
			}
			if ($hand->getId() == 339 and $hand->getDamage() == 150) {
				$hand->setCount($hand->getCount() - 1);
				$inv->setItemInHand($hand);
				$event->setCancelled(true);
				$reward = rand(1, 20);
				switch($reward) {
					case 1:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 1000');
						break;
					case 2:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 2000');
						$player->addXp("61");
						break;
					case 3:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 3000');
						break;
					case 4:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 4000');
						break;
					case 5:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 5000');
						break;
					case 6:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 6000');
						break;
					case 7:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 7000');
						break;
					case 8:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 8000');
						break;
					case 9:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 9000');
						break;
					case 10:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 10000');
						break;
					case 11:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 1920');
						break;
					case 12:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 1005');
						break;
					case 13:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 1200');
						break;
					case 14:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 2250');
						break;
					case 15:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 3010');
						break;
					case 16:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 2020');
						break;
					case 17:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 6969');
						break;
					case 18:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 9500');
						break;
					case 19:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 3005');
						break;
					case 20:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 4000');
						break;
				}
			}
			if ($hand->getId() == 120 and $hand->getDamage() == 1) {
				$hand->setCount($hand->getCount() - 1);
				$inv->setItemInHand($hand);
				$event->setCancelled(true);
				$reward = rand(1, 21);
				switch($reward) {
					case 1:
						$this->plugin->getServer()->dispatchCommand($this->console, 'give ' . $player->getName() . ' 19 32');
						break;
					case 2:
						$this->plugin->getServer()->dispatchCommand($this->console, 'give ' . $player->getName() . ' 19 64');
						break;
					case 3:
						$this->plugin->getServer()->dispatchCommand($this->console, 'give ' . $player->getName() . ' diamond_block 16');
						break;
					case 4:
						$this->plugin->getServer()->dispatchCommand($this->console, 'give ' . $player->getName() . ' diamond_block 32');
						break;
					case 5:
						$this->plugin->getServer()->dispatchCommand($this->console, 'key Rare 1 ' . $player->getName());
						break;
					case 6:
						$this->plugin->getServer()->dispatchCommand($this->console, 'key Legendary 1 ' . $player->getName());
						break;
					case 7:
						$this->plugin->getServer()->dispatchCommand($this->console, 'key Common 1 ' . $player->getName());
						break;
					case 8:
						$this->plugin->getServer()->dispatchCommand($this->console, 'key Common 1 ' . $player->getName());
						break;
					case 9:
						$this->plugin->getServer()->dispatchCommand($this->console, 'key Common 1 ' . $player->getName());
						break;
					case 10:
						$this->plugin->getServer()->dispatchCommand($this->console, 'give ' . $player->getName() . ' diamond_block 16');
						break;
					case 11:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 50000');
						break;
					case 12:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 60000');
						break;
					case 13:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 70000');
						break;
					case 14:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 80000');
						break;
					case 15:
						$this->plugin->getServer()->dispatchCommand($this->console, 'brokenagem ' . $player->getName() . ' 224:1 1');
						break;
					case 16:
						$this->plugin->getServer()->dispatchCommand($this->console, 'brokensoulgem ' . $player->getName() . ' 224:1 1');
						break;
					case 17:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 10000 ' . $player->getName());
						break;
					case 18:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 20000 ' . $player->getName());
						break;
					case 19:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 30000 ' . $player->getName());
						break;
					case 20:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 40000 ' . $player->getName());
						break;
					case 21:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 50000 ' . $player->getName());
						break;
				}
			}
			if ($hand->getId() == 120 and $hand->getDamage() == 2) {
				$hand->setCount($hand->getCount() - 1);
				$inv->setItemInHand($hand);
				$event->setCancelled(true);
				$reward = rand(1, 31);
				switch($reward) {
					case 1:
						$this->plugin->getServer()->dispatchCommand($this->console, 'b ' . $player->getName() . ' zombie 1');
						break;
					case 2:
						$this->plugin->getServer()->dispatchCommand($this->console, 'b ' . $player->getName() . ' zombie 1');
						break;
					case 3:
						$this->plugin->getServer()->dispatchCommand($this->console, 'give ' . $player->getName() . ' 466 1');
						break;
					case 4:
						$this->plugin->getServer()->dispatchCommand($this->console, 'give ' . $player->getName() . ' 466 2');
						break;
					case 5:
						$this->plugin->getServer()->dispatchCommand($this->console, 'key Rare 16 ' . $player->getName());
						break;
					case 6:
						$this->plugin->getServer()->dispatchCommand($this->console, 'key Rare 32 ' . $player->getName());
						break;
					case 7:
						$this->plugin->getServer()->dispatchCommand($this->console, 'key Legendary 6 ' . $player->getName());
						break;
					case 8:
						$this->plugin->getServer()->dispatchCommand($this->console, 'key Legendary 6 ' . $player->getName());
						break;
					case 9:
						$this->plugin->getServer()->dispatchCommand($this->console, 'key Rare 16 ' . $player->getName());
						break;
					case 10:
						$this->plugin->getServer()->dispatchCommand($this->console, 'b ' . $player->getName() . ' zombie 1');
						break;
					case 11:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 100000');
						break;
					case 12:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 150000');
						break;
					case 13:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 200000');
						break;
					case 14:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 250000');
						break;
					case 15:
						$this->plugin->getServer()->dispatchCommand($this->console, 'brokenagem ' . $player->getName() . ' 224:1 1');
						break;
					case 16:
						$this->plugin->getServer()->dispatchCommand($this->console, 'brokensoulgem ' . $player->getName() . ' 224:1 1');
						break;
					case 17:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 10000 ' . $player->getName());
						break;
					case 18:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 15000 ' . $player->getName());
						break;
					case 19:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 20000 ' . $player->getName());
						break;
					case 20:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 25000 ' . $player->getName());
						break;
					case 21:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 17000 ' . $player->getName());
						break;
					case 22:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 7));
						$item->setCustomName("§r§l§4BlackOut VII\nEnchantment Book");
						$item->setLore([
							'§r§eChance to disable enemy',
							'§r§7Sword Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn BlackOut Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 23:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Hallucination"), 4));
						$item->setCustomName("§r§l§6Hallucination IV\nEnchantment Book");
						$item->setLore([
							'§r§eChance to trap enemies in prison',
							'§r§7Sword Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn Hallucination Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 24:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 5));
						$item->setCustomName("§r§l§4BlackOut V\nEnchantment Book");
						$item->setLore([
							'§r§eChance to disable enemy',
							'§r§7Sword Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn BlackOut Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 25:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 3));
						$item->setCustomName("§r§l§4BlackOut III\nEnchantment Book");
						$item->setLore([
							'§r§eChance to disable enemy',
							'§r§7Sword Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn BlackOut Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 26:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Genjutsu"), 5));
						$item->setCustomName("§r§l§4Genjutsu V\nEnchantment Book");
						$item->setLore([
							'§r§eChance to Trap Enemy in a illusion',
							'§r§7Sword Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn Genjutsu Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 27:
						$item = Item::get(403, 0, 1);
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Genjutsu"), 8));
						$item->setCustomName("§r§l§4Genjustu VIII\nEnchantment Book");
						$item->setLore([
							'§r§eChance to Trap Enemy in a illusion',
							'§r§7Sword Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn Genjutsu Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 28:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Genjutsu"), 2));
						$item->setCustomName("§r§l§4Genjutsu II\nEnchantment Book");
						$item->setLore([
							'§r§eChance to Trap Enemy in a illusion',
							'§r§7Sword Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn Genjutsu Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 29:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Spitsweb"), 1));
						$item->setCustomName("§r§l§eSpits Web I\nEnchantment Book");
						$item->setLore([
							'§r§eChance to trap enemies with cobwebs. Cooldown: 60 Seconds',
							'§r§eCooldown: 60 Seconds',
							'§r§7Weapon Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn Spits Web Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 30:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 7));
						$item->setCustomName("§r§l§6Insanity VII\nEnchantment Book");
						$item->setLore([
							'§r§eIncreases massive damage in Axes',
							'§r§7Axe Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 31:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 8));
						$item->setCustomName("§r§l§6Insanity VIII\nEnchantment Book");
						$item->setLore([
							'§r§eIncreases massive damage in Axes',
							'§r§7Axe Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
				}
			}
			if ($hand->getId() == 54 and $hand->getDamage() == 1) {
				$hand->setCount($hand->getCount() - 1);
				$inv->setItemInHand($hand);
				$event->setCancelled(true);
				$reward = rand(1, 21);
				switch($reward) {
					case 1:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 50000 ' . $player->getName());
						$player->sendMessage("§b§l>> §r§aYou Recieved 50k EXP");
						break;
					case 2:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 100000 ' . $player->getName());
						$player->sendMessage("§b§l>> §r§aYou Recieved 100k EXP");
						break;
					case 3:
						$this->plugin->getServer()->dispatchCommand($this->console, 'item styx ' . $player->getName());
						$player->sendMessage("§b§l>> §r§aYou Recieved an STYX AXE");
						break;
					case 4:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wrath"), 1));
						$item->setCustomName("§r§l§4Wrath I\nEnchantment Book");
						$item->setLore([
							'§r§eChance to disable enemy',
							'§r§7Sword Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn Wrath Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 5:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wrath"), 2));
						$item->setCustomName("§r§l§4Wrath II\nEnchantment Book");
						$item->setLore([
							'§r§eChance to disable enemy',
							'§r§7Sword Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn Wrath Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 6:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 25000 ' . $player->getName());
						$player->sendMessage("§b§l>> §r§aYou Recieved 25k EXP");
						break;
					case 7:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 25000 ' . $player->getName());
						$player->sendMessage("§b§l>> §r§aYou Recieved 25k Money");
						break;
					case 8:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 50000 ' . $player->getName());
						$player->sendMessage("§b§l>> §r§aYou Recieved 50k Money");
						break;
					case 9:
						$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 100000 ' . $player->getName());
						$player->sendMessage("§b§l>> §r§aYou Recieved 100k Money");
						break;
					case 10:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 6));
						$item->setCustomName("§r§l§4BlackOut VI\nEnchantment Book");
						$item->setLore([
							'§r§eChance to disable enemy',
							'§r§7Sword Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn Wrath Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
					case 11:
						$item = Item::get(403, 0, 1);
						$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 5));
						$item->setCustomName("§r§l§4BlackOut V\nEnchantment Book");
						$item->setLore([
							'§r§eChance to disable enemy',
							'§r§7Sword Enchantment',
							'§r§7Combine it into item to enchant'
						]);
						$player->sendMessage("§l§b» §r§aYou earn BlackOut Custom Enchantment");
						if (!$player->getInventory()->canAddItem($item)) {
							$player->dropItem($item);
						} else {
							$player->getInventory()->addItem($item);
						}
						break;
				}
			}
			if ($hand->getId() == 389 and $hand->getDamage() == 0) {
				$hand->setCount($hand->getCount() - 1);
				$inv->setItemInHand($hand);
				$event->setCancelled(true);
				$reward = rand(1, 2);
				switch($reward) {
					case 1:
						$this->plugin->getServer()->dispatchCommand($this->console, 'sm ' . $player->getName() . ' §c§l(!) §r§cThis item is banned, you cannot place this item');
						break;
					case 2:
						$this->plugin->getServer()->dispatchCommand($this->console, 'sm ' . $player->getName() . ' §c§l(!) §r§cThis item is banned, you cannot place this item');
						break;
				}
			}
		}
	}
}