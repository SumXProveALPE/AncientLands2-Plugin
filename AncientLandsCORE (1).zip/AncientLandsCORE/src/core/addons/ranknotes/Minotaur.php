<?php

namespace core\addons\ranknotes;

use core\AncientLands;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\plugin\Plugin;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\item\Durable;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\CompoundTag;


class Minotaur extends PluginCommand{

	/** @var array */
	public $plugin;

	public function __construct($name, AncientLands $plugin) {
        parent::__construct($name, $plugin);
        $this->setDescription("Minotaur RankNote");
        $this->setUsage("/minotaur <player>");
        $this->setPermission("core.command.hermes");
		$this->plugin = $plugin;
    }

	/**
     * @param CommandSender $sender
     * @param string $alias
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool{
		if (!$sender->hasPermission("core.command.hermes")) {
			$sender->sendMessage(TextFormat::RED . "You do not have permission to use this command");
			return false;
		}		
		if (count($args) < 1) {
            $sender->sendMessage(TextFormat::GOLD . "Usage:" . TextFormat::GREEN . " /hermes <player>");
            return false;
        }
		if (!empty($args[0])) {
            $target = $this->getPlayer($args[0]);
			if ($target == null) {
                $sender->sendMessage(TextFormat::RED . "That player cannot be found");
				return false;
			}
            if ($target == true) {
			    $special = Item::get(339);
                $special->setCustomName("§aMino§0dtaur §7RankNote");
                $special->setNamedTagEntry(new StringTag("MinotaurRN"));
                $special->setLore([
                '§r',
                '§r§7The Grinding RankNote for Minotaur',
                '§r§7Contains, The Rank,Access to the Kit',
                '§r',
                '§r§7Right click to claim §The RankNote',
                '§r',
				'§r§6Tier Level: §aVIII',
                '§r§3'
                ]);
				$target->getInventory()->addItem($special);
                $target->sendMessage("§a§l(!) §r§aYou recieved the Minotaur RankNote§a!"); 
				return true;
            }
		}
	}
	
	/**
     * @param string $player
     * @return null|Player
     */
    public function getPlayer($player): ?Player{
        if (!Player::isValidUserName($player)) {
            return null;
        }
        $player = strtolower($player);
        $found = null;
        foreach($this->plugin->getServer()->getOnlinePlayers() as $target) {
            if (strtolower(TextFormat::clean($target->getDisplayName(), true)) === $player || strtolower($target->getName()) === $player) {
                $found = $target;
                break;
            }
        }
        if (!$found) {
            $found = ($f = $this->plugin->getServer()->getPlayer($player)) === null ? null : $f;
        }
        if (!$found) {
            $delta = PHP_INT_MAX;
            foreach($this->plugin->getServer()->getOnlinePlayers() as $target) {
                if (stripos(($name = TextFormat::clean($target->getDisplayName(), true)), $player) === 0) {
                    $curDelta = strlen($name) - strlen($player);
                    if ($curDelta < $delta) {
                        $found = $target;
                        $delta = $curDelta;
                    }
                    if ($curDelta === 0) {
                        break;
                    }
                }
            }
        }
        return $found;
    }
}