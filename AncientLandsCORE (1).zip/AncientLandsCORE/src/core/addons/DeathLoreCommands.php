<?php

namespace core\addons;

use core\AncientLands;

# Pocketmine
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use pocketmine\event\Listener;
use pocketmine\level\Location;
use pocketmine\level\Position;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;
use pocketmine\command\PluginCommand;
use pocketmine\command\CommandSender;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\StringTag;

# Death Class
class DeathLoreCommands extends PluginCommand implements Listener{

    private $plugin;

    public function __construct($name, AncientLands $plugin){
        $this->plugin = $plugin;
        parent::__construct($name, $plugin);
        $this->setDescription("Get a custom DeathMessage");
        $this->setUsage("/deathlore");
        $this->setPermission("cmd.deathlore");
        $this->plugin->getServer()->getPluginManager()->registerEvents($this, $plugin);
    }

    public function execute(CommandSender $sender, string $label, array $args): bool{
        if (!$sender->hasPermission("cmd.deathlore")) {
			$sender->sendMessage("§l§1(§b!§1) §r§cYou do not have permission to use this command.");
			return false;
		}
		if ($sender instanceof ConsoleCommandSender) {
			$sender->sendMessage("§l§1(§b!§1) §r§cThis command can only be used in-game.");
			return false;
		}
        if(isset($args[0])){
            $item = $sender->getInventory()->getItemInHand();
            $sender->getInventory()->removeItem($item);
            $item->setNamedTagEntry(new StringTag("deathLore", "$args[0]"));
            $sender->getInventory()->addItem($item);
        } else {
            $sender->sendMessage("/deathlore (Message)");
            return false;
        }
        return true;
    }
}