<?php

# Namespace
namespace core\event;

# Pocketmine Uses
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\plugin\Plugin;
use pocketmine\event\Listener;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\plugin\PluginBase;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\command\CommandSender;
use pocketmine\event\player\PlayerInteractEvent;

# Main Use
use core\AncientLands;

# Rank Event
class RankEvents implements Listener {

    private $plugin;
    
    public function __construct(AncientLands $plugin){
        $this->plugin = $plugin;
    }

    public function onTouch(PlayerInteractEvent $event) {
        $player = $event->getPlayer();
        $name = $player->getName();
        $hand = $player->getInventory()->getItemInHand();
        if($hand->getNamedTag()->hasTag("AphroditeRN")) {
            $hand->setCount($hand->getCount() -1);
            $player->getInventory()->setItemInHand($hand);
            $purePerms = $this->plugin->getServer()->getPluginManager()->getPlugin("PurePerms");
            $group = $purePerms->getUserDataMgr()->getData($player)["group"];
            if($group == "Guest") {
                $group = $purePerms->getGroup("Aphrodite");
                $purePerms->setGroup($player, $group);
                $player->sendMessage("§a§l(!) §r§aYou have been ranked up to Aphrodite.");
                $this->plugin->getServer()->broadcastMessage("§a§l(!) §r§a" . $player->getName() . " has ranked up to Aphrodite!");
                }
         }
        if($hand->getNamedTag()->hasTag("AthenaRN")) {
            $hand->setCount($hand->getCount() -1);
            $player->getInventory()->setItemInHand($hand);
            $purePerms = $this->plugin->getServer()->getPluginManager()->getPlugin("PurePerms");
            $group = $purePerms->getUserDataMgr()->getData($player)["group"];
            if($group == "Ares") {
                $group = $purePerms->getGroup("Athena");
                $purePerms->setGroup($player, $group);
                $player->sendMessage("§a§l(!) §r§aYou have been ranked up to Athena.");
                $this->plugin->getServer()->broadcastMessage("§a§l(!) §r§a" . $player->getName() . " has ranked up to Athena!");
            }
        }
        if($hand->getNamedTag()->hasTag("MinatourRN")) {
            $hand->setCount($hand->getCount() -1);
            $player->getInventory()->setItemInHand($hand);
            $purePerms = $this->plugin->getServer()->getPluginManager()->getPlugin("PurePerms");
            $group = $purePerms->getUserDataMgr()->getData($player)["group"];
            if($group == "Hermes") {
                $group = $purePerms->getGroup("Minatour");
                $purePerms->setGroup($player, $group);
                $player->sendMessage("§a§l(!) §r§aYou have been ranked up to Minatour.");
                $this->plugin->getServer()->broadcastMessage("§a§l(!) §r§a" . $player->getName() . " has ranked up to Minatour!");
            }
        }
        if($hand->getNamedTag()->hasTag("HadesRN")) {
            $hand->setCount($hand->getCount() -1);
            $player->getInventory()->setItemInHand($hand);
            $purePerms = $this->plugin->getServer()->getPluginManager()->getPlugin("PurePerms");
            $group = $purePerms->getUserDataMgr()->getData($player)["group"];
            if($group == "Demeter") {
                $group = $purePerms->getGroup("Hades");
                $purePerms->setGroup($player, $group);
                $player->sendMessage("§a§l(!) §r§aYou have been ranked up to Hades.");
                $this->plugin->getServer()->broadcastMessage("§a§l(!) §r§a" . $player->getName() . " has ranked up to Hades!");
            }
        }
        if($hand->getNamedTag()->hasTag("PoseidonRN")) {
            $hand->setCount($hand->getCount() -1);
            $player->getInventory()->setItemInHand($hand);
            $purePerms = $this->plugin->getServer()->getPluginManager()->getPlugin("PurePerms");
            $group = $purePerms->getUserDataMgr()->getData($player)["group"];
            if($group == "Minotaur") {
                $group = $purePerms->getGroup("Poseidon");
                $purePerms->setGroup($player, $group);
                $player->sendMessage("§a§l(!) §r§aYou have been ranked up to Poseidon.");
                $this->plugin->getServer()->broadcastMessage("§a§l(!) §r§a" . $player->getName() . " has ranked up to Poseidon!");
            }
        }
        if($hand->getNamedTag()->hasTag("DemeterRN")) {
            $hand->setCount($hand->getCount() -1);
            $player->getInventory()->setItemInHand($hand);
            $purePerms = $this->plugin->getServer()->getPluginManager()->getPlugin("PurePerms");
            $group = $purePerms->getUserDataMgr()->getData($player)["group"];
            if($group == "Athena") {
                $group = $purePerms->getGroup("Demeter");
                $purePerms->setGroup($player, $group);
                $player->sendMessage("§a§l(!) §r§aYou have been ranked up to Demeter.");
                $this->plugin->getServer()->broadcastMessage("§a§l(!) §r§a" . $player->getName() . " has ranked up to Demeter!");
            }
        }
        if($hand->getNamedTag()->hasTag("ApolloRN")) {
            $hand->setCount($hand->getCount() -1);
            $player->getInventory()->setItemInHand($hand);
            $purePerms = $this->plugin->getServer()->getPluginManager()->getPlugin("PurePerms");
            $group = $purePerms->getUserDataMgr()->getData($player)["group"];
            if($group == "Aphrodite") {
                $group = $purePerms->getGroup("Apollo");
                $purePerms->setGroup($player, $group);
                $player->sendMessage("§a§l(!) §r§aYou have been ranked up to Apollo.");
                $this->plugin->getServer()->broadcastMessage("§a§l(!) §r§a" . $player->getName() . " has ranked up to Apollo!");
            }
        }
        if($hand->getNamedTag()->hasTag("AresRN")) {
            $hand->setCount($hand->getCount() -1);
            $player->getInventory()->setItemInHand($hand);
            $purePerms = $this->plugin->getServer()->getPluginManager()->getPlugin("PurePerms");
            $group = $purePerms->getUserDataMgr()->getData($player)["group"];
            if($group == "Apollo") {
                $group = $purePerms->getGroup("Ares");
                $purePerms->setGroup($player, $group);
                $player->sendMessage("§a§l(!) §r§aYou have been ranked up to Ares.");
                $this->plugin->getServer()->broadcastMessage("§a§l(!) §r§a" . $player->getName() . " has ranked up to Ares!");
            }
        }
        if($hand->getNamedTag()->hasTag("ZeusRN")) {
            $hand->setCount($hand->getCount() -1);
            $player->getInventory()->setItemInHand($hand);
            $purePerms = $this->plugin->getServer()->getPluginManager()->getPlugin("PurePerms");
            $group = $purePerms->getUserDataMgr()->getData($player)["group"];
            if($group == "Poseidon") {
                $group = $purePerms->getGroup("Zeus");
                $purePerms->setGroup($player, $group);
                $player->sendMessage("§a§l(!) §r§aYou have been ranked up to Zeus.");
                $this->plugin->getServer()->broadcastMessage("§a§l(!) §r§a" . $player->getName() . " has ranked up to Zeus!");
            }
        }
    }
}