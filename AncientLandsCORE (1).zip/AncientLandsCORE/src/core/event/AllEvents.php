<?php

namespace core\event;

use core\AncientLands;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Entity;
use pocketmine\entity\Zombie;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityEffectAddEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Explosion;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\PiggyCustomEnchants;
use DaPigGuy\PiggyCustomEnchants\CustomEnchantManager;
use onebone\economyapi\EconomyAPI;
use _64FF00\PurePerms\PPGroup;

class AllEvents implements Listener{

	/** @var array */
	public $plugin;

    public function __construct(AncientLands $plugin) {
       $this->plugin = $plugin;
		$this->console = new ConsoleCommandSender();
	}
	
	/**
     * @param PlayerInteractEvent $event
     */
	public function onItems(PlayerInteractEvent $event) : void{
        $player = $event->getPlayer();
		$block = $event->getBlock();
		$inv = $player->getInventory();
		$hand = $inv->getItemInHand();
		$nbt = $hand->getNamedTag();
		if ($hand->getId() == 54 and $hand->getDamage() == 1) {
			$hand->setCount($hand->getCount() - 1);
			$inv->setItemInHand($hand);
			$event->setCancelled(true);
			$reward = rand(1, 21);
			switch($reward) {
                    case 1:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givexp 50000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 50k EXP");
                    break;
                    case 2:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givexp 100000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 100k EXP");
                    break;
                    case 3:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'item styx ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved an STYX AXE");
                    break;
		    case 4:
		    $item = Item::get(403, 0, 1);
		    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wrath"), 1));
                    $item->setCustomName("§r§l§4Wrath I\nEnchantment Book");
                    $item->setLore([
                    '§r§eChance to disable enemy',
                    '§r§7Sword Enchantment',
                    '§r§7Combine it into item to enchant'
                    ]);
                    $player->sendMessage("§l§b» §r§aYou earn Wrath Custom Enchantment");
                    if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
		    break;
		    case 5:
		    $item = Item::get(403, 0, 1);
		    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wrath"), 2));
                    $item->setCustomName("§r§l§4Wrath II\nEnchantment Book");
                    $item->setLore([
                    '§r§eChance to disable enemy',
                    '§r§7Sword Enchantment',
                    '§r§7Combine it into item to enchant'
                    ]);
                    $player->sendMessage("§l§b» §r§aYou earn Wrath Custom Enchantment");
                    if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
		    break;
                    case 6:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givexp 25000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 25k EXP");
                    break;
                    case 7:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 25000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 25k Money");
                    break;
                    case 8:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 50000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 50k Money");
                    break;
                    case 9:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 100000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 100k Money");
                    break;
		    case 10:
		    $item = Item::get(403, 0, 1);
		    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 6));
                    $item->setCustomName("§r§l§4BlackOut VI\nEnchantment Book");
                    $item->setLore([
                    '§r§eChance to disable enemy',
                    '§r§7Sword Enchantment',
                    '§r§7Combine it into item to enchant'
                    ]);
                    $player->sendMessage("§l§b» §r§aYou earn Wrath Custom Enchantment");
                    if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
		    break;
		    case 11:
		    $item = Item::get(403, 0, 1);
		    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 5));
                    $item->setCustomName("§r§l§4BlackOut V\nEnchantment Book");
                    $item->setLore([
                    '§r§eChance to disable enemy',
                    '§r§7Sword Enchantment',
                    '§r§7Combine it into item to enchant'
                    ]);
                    $player->sendMessage("§l§b» §r§aYou earn BlackOut Custom Enchantment");
                    if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
		    break;
			}
		}
        		if ($hand->getId() == 384 and $hand->getDamage() == 2 and $hand->getCustomName() == "§a§lExperience Bottle §r§7(Right Click)") {
			$hand->setCount($hand->getCount() - 1);
			$inv->setItemInHand($hand);
			$event->setCancelled(true);
			$reward = rand(1, 27);
			switch($reward) {
				case 1:
				$player->sendMessage("§l§b» §r§aYou earned 50 XP");
				$player->addXp("50");
				break;
				case 2:
				$player->sendMessage("§l§b» §r§aYou earned 61 XP");
				$player->addXp("61");
				break;
				case 3:
				$player->sendMessage("§l§b» §r§aYou earned 68 XP");
				$player->addXp("68");
				break;
				case 4:
				$player->sendMessage("§l§b» §r§aYou earned 69 XP");
				$player->addXp("69");
				break;
				case 5:
				$player->sendMessage("§l§b» §r§aYou earned 71 XP");
				$player->addXp("71");
				break;
				case 6:
				$player->sendMessage("§l§b» §r§aYou earned 78 XP");
				$player->addXp("78");
				break;
				case 7:
				$player->sendMessage("§l§b» §r§aYou earned 82 XP");
				$player->addXp("82");
				break;
				case 8:
				$player->sendMessage("§l§b» §r§aYou earned 73 XP");
				$player->addXp("73");
				break;
				case 9:
				$player->sendMessage("§l§b» §r§aYou earned 89 XP");
				$player->addXp("89");
				break;
				case 10:
				$player->sendMessage("§l§b» §r§aYou earned 76 XP");
				$player->addXp("76");
				break;
				case 11:
				$player->sendMessage("§l§b» §r§aYou earned 128 XP");
				$player->addXp("128");
				break;
				case 12:
				$player->sendMessage("§l§b» §r§aYou earned 908 XP");
				$player->addXp("908");
				break;
				case 13:
				$player->sendMessage("§l§b» §r§aYou earned 451 XP");
				$player->addXp("451");
				break;
				case 14:
				$player->sendMessage("§l§b» §r§aYou earned 651 XP");
				$player->addXp("651");
				break;
				case 15:
				$player->sendMessage("§l§b» §r§aYou earned 713 XP");
				$player->addXp("713");
				break;
				case 16:
				$player->sendMessage("§l§b» §r§aYou earned 816 XP");
				$player->addXp("816");
				break;
				case 17:
				$player->sendMessage("§l§b» §r§aYou earned 291 XP");
				$player->addXp("291");
				break;
				case 18:
				$player->sendMessage("§l§b» §r§aYou earned 371 XP");
				$player->addXp("371");
				break;
				case 19:
				$player->sendMessage("§l§b» §r§aYou earned 918 XP");
				$player->addXp("918");
				break;
				case 20:
				$player->sendMessage("§l§b» §r§aYou earned 456 XP");
				$player->addXp("456");
				break;
				case 21:
				$player->sendMessage("§l§b» §r§aYou earned 412 XP");
				$player->addXp("412");
				break;
				case 22:
				$player->sendMessage("§l§b» §r§aYou earned 219 XP");
				$player->addXp("219");
				break;
				case 23:
				$player->sendMessage("§l§b» §r§aYou earned 55 XP");
				$player->addXp("55");
				break;
				case 24:
				$player->sendMessage("§l§b» §r§aYou earned 59 XP");
				$player->addXp("59");
				break;
				case 25:
				$player->sendMessage("§l§b» §r§aYou earned 59 XP");
				$player->addXp("59");
				break;
				case 26:
				$player->sendMessage("§l§b» §r§aYou earned 101 XP");
				$player->addXp("101");
				break;
				case 27:
				$player->sendMessage("§l§b» §r§aYou earned 69 XP");
				$player->addXp("69");
				break;
				case 28:
				$player->sendMessage("§l§b» §r§aYou earned 69 XP");
				$player->addXp("68");
				break;
				case 29:
				$player->sendMessage("§l§b» §r§aYou earned 69 XP");
				$player->addXp("69");
				break;
				case 30:
				$player->sendMessage("§l§b» §r§aYou earned 69 XP");
				$player->addXp("108");
				break;
				case 31:
				$player->sendMessage("§l§b» §r§aYou earned 56 XP");
				$player->addXp("56");
				break;
				case 32:
				$player->sendMessage("§l§b» §r§aYou earned 231 XP");
				$player->addXp("69");
				break;
				case 33:
				$player->sendMessage("§l§b» §r§aYou earned 211 XP");
				$player->addXp("211");
				break;
				case 34:
				$player->sendMessage("§l§b» §r§aYou earned 208 XP");
				$player->addXp("208");
				break;
				case 35:
				$player->sendMessage("§l§b» §r§aYou earned 213 XP");
				$player->addXp("35");
				break;
				case 36:
				$player->sendMessage("§l§b» §r§aYou earned 53 XP");
				$player->addXp("53");
				break;
				case 37:
				$player->sendMessage("§l§b» §r§aYou earned 325 XP");
				$player->addXp("325");
				break;
				case 38:
				$player->sendMessage("§l§b» §r§aYou earned 39 XP");
				$player->addXp("105");
				break;
			}
		}
        if ($hand->getId() == 7 and $hand->getCustomName() == "§3§lAncientLands KOTH Lootbag §r§7(Right-Click)") {
			$hand->setCount($hand->getCount() - 1);
			$inv->setItemInHand($hand);
			$event->setCancelled(true);
			$reward = rand(1, 2);
			switch($reward) {
                    case 1:
                    Server::getInstance()->broadcastMessage("§8§l(§b!§8) §a{$player->getName()} §r§7opened a §3Koth Crate §7and received the following: \n§l§8<§b+§8>§4§l Akatsuki Axe \n§8<§b+§8>§a§l Sourusutira Sword");
		    $this->plugin->getServer()->dispatchCommand($this->console, 'item "Akatsuki Axe" ' . $player->getName());
		    $this->plugin->getServer()->dispatchCommand($this->console, 'item "Sourusutira" ' . $player->getName());
                    break;
                    case 2:
                    Server::getInstance()->broadcastMessage("§8§l(§b!§8) §a{$player->getName()} §r§7opened a §3Koth Crate §7and received the following: \n§l§8<§b+§8>§b§l Kirisuto Sword \n§8<§b+§8>§g§l Valkyrie Axe");
		    $this->plugin->getServer()->dispatchCommand($this->console, 'item "Kirisuto" ' . $player->getName());
		    $this->plugin->getServer()->dispatchCommand($this->console, 'item "Valkyrie" ' . $player->getName());
                    break;
			}
		}
		if ($hand->getId() == 384 and $hand->getDamage() == 105 and $hand->getCustomName() == "§a§lExperience Bottle §r§7(Right Click)") {
			$hand->setCount($hand->getCount() - 1);
			$inv->setItemInHand($hand);
			$event->setCancelled(true);
			$reward = rand(1, 38);
			switch($reward) {
				case 1:
				$player->sendMessage("§l§b» §r§aYou earned 1000 XP");
				$player->addXp("1000");
				break;
				case 2:
				$player->sendMessage("§l§b» §r§aYou earned 2000 XP");
				$player->addXp("2000");
				break;
				case 3:
				$player->sendMessage("§l§b» §r§aYou earned 3000 XP");
				$player->addXp("3000");
				break;
				case 4:
				$player->sendMessage("§l§b» §r§aYou earned 4500 XP");
				$player->addXp("4500");
				break;
				case 5:
				$player->sendMessage("§l§b» §r§aYou earned 5600 XP");
				$player->addXp("5600");
				break;
				case 6:
				$player->sendMessage("§l§b» §r§aYou earned 8250 XP");
				$player->addXp("8250");
				break;
				case 7:
				$player->sendMessage("§l§b» §r§aYou earned 9851 XP");
				$player->addXp("9851");
				break;
				case 8:
				$player->sendMessage("§l§b» §r§aYou earned 1250 XP");
				$player->addXp("1250");
				break;
				case 9:
				$player->sendMessage("§l§b» §r§aYou earned 1005 XP");
				$player->addXp("1005");
				break;
				case 10:
				$player->sendMessage("§l§b» §r§aYou earned 2590 XP");
				$player->addXp("2590");
				break;
				case 11:
				$player->sendMessage("§l§b» §r§aYou earned 10,000 XP");
				$player->addXp("10000");
				break;
				case 12:
				$player->sendMessage("§l§b» §r§aYou earned 12,000 XP");
				$player->addXp("12000");
				break;
				case 13:
				$player->sendMessage("§l§b» §r§aYou earned 5600 XP");
				$player->addXp("5600");
				break;
				case 14:
				$player->sendMessage("§l§b» §r§aYou earned 2501 XP");
				$player->addXp("2501");
				break;
				case 15:
				$player->sendMessage("§l§b» §r§aYou earned 1599 XP");
				$player->addXp("1599");
				break;
				case 16:
				$player->sendMessage("§l§b» §r§aYou earned 12900 XP");
				$player->addXp("12900");
				break;
				case 17:
				$player->sendMessage("§l§b» §r§aYou earned 51000 XP");
				$player->addXp("51000");
				break;
				case 18:
				$player->sendMessage("§l§b» §r§aYou earned 5000 XP");
				$player->addXp("5000");
				break;
				case 19:
				$player->sendMessage("§l§b» §r§aYou earned 95000 XP");
				$player->addXp("95000");
				break;
				case 20:
				$player->sendMessage("§l§b» §r§aYou earned 12000 XP");
				$player->addXp("12000");
				break;
				case 21:
				$player->sendMessage("§l§b» §r§aYou earned 15000 XP");
				$player->addXp("15000");
				break;
				case 22:
				$player->sendMessage("§l§b» §r§aYou earned 75000 XP");
				$player->addXp("75000");
				break;
				case 23:
				$player->sendMessage("§l§b» §r§aYou earned 1003 XP");
				$player->addXp("1003");
				break;
				case 24:
				$player->sendMessage("§l§b» §r§aYou earned 1001 XP");
				$player->addXp("1001");
				break;
				case 25:
				$player->sendMessage("§l§b» §r§aYou earned 1002 XP");
				$player->addXp("1002");
				break;
				case 26:
				$player->sendMessage("§l§b» §r§aYou earned 1002 XP");
				$player->addXp("1002");
				break;
				case 27:
				$player->sendMessage("§l§b» §r§aYou earned 16969 XP");
				$player->addXp("16969");
				break;
				case 28:
				$player->sendMessage("§l§b» §r§aYou earned 16969 XP");
				$player->addXp("16969");
				break;
				case 29:
				$player->sendMessage("§l§b» §r§aYou earned 16969 XP");
				$player->addXp("16969");
				break;
				case 30:
				$player->sendMessage("§l§b» §r§aYou earned 16969 XP");
				$player->addXp("16969");
				break;
				case 31:
				$player->sendMessage("§l§b» §r§aYou earned 1000 XP");
				$player->addXp("1000");
				break;
				case 32:
				$player->sendMessage("§l§b» §r§aYou earned 6969 XP");
				$player->addXp("6969");
				break;
				case 33:
				$player->sendMessage("§l§b» §r§aYou earned 6969 XP");
				$player->addXp("6969");
				break;
				case 34:
				$player->sendMessage("§l§b» §r§aYou earned 6969 XP");
				$player->addXp("6969");
				break;
				case 35:
				$player->sendMessage("§l§b» §r§aYou earned 1269 XP");
				$player->addXp("1269");
				break;
				case 36:
				$player->sendMessage("§l§b» §r§aYou earned 1269 XP");
				$player->addXp("1269");
				break;
				case 37:
				$player->sendMessage("§l§b» §r§aYou earned 1325 XP");
				$player->addXp("1325");
				break;
				case 38:
				$player->sendMessage("§l§b» §r§aYou earned 1025 XP");
				$player->addXp("1025");
			    break;
			}
		}
		if ($hand->getId() == 339 and $hand->getDamage() == 105 and $hand->getCustomName() == "§l§aMoney Note §r§7(Right Click)") {
			$hand->setCount($hand->getCount() - 1);
			$inv->setItemInHand($hand);
			$event->setCancelled(true);
			$reward = rand(1, 38);
            $money = $nbt->getInt("Money");
          	EconomyAPI::getInstance()->addMoney($player->getName(), $money);
			switch($reward) {
				case 1:
				$player->sendMessage("§l§b» §r§aYou earned 1000 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 1000 ' . $player->getName());
				break;
				case 2:
				$player->sendMessage("§l§b» §r§aYou earned 2000 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 2000 ' . $player->getName());
				break;
				case 3:
				$player->sendMessage("§l§b» §r§aYou earned 3000 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 4500 ' . $player->getName());
				break;
				case 4:
				$player->sendMessage("§l§b» §r§aYou earned 4500 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 4500 ' . $player->getName());
				break;
				case 5:
				$player->sendMessage("§l§b» §r§aYou earned 5600 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 5600 ' . $player->getName());
				break;
				case 6:
				$player->sendMessage("§l§b» §r§aYou earned 8250 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 8250 ' . $player->getName());
				break;
				case 7:
				$player->sendMessage("§l§b» §r§aYou earned 9851 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 9851 ' . $player->getName());
				break;
				case 8:
				$player->sendMessage("§l§b» §r§aYou earned 1250 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 1250 ' . $player->getName());
				break;
				case 9:
				$player->sendMessage("§l§b» §r§aYou earned 1005 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 1005 ' . $player->getName());
				break;
				case 10:
				$player->sendMessage("§l§b» §r§aYou earned 2590 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 2590 ' . $player->getName());
				break;
				case 11:
				$player->sendMessage("§l§b» §r§aYou earned 10,000 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 10000 ' . $player->getName());
				break;
				case 12:
				$player->sendMessage("§l§b» §r§aYou earned 12,000 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 12000 ' . $player->getName());
				break;
				case 13:
				$player->sendMessage("§l§b» §r§aYou earned 5600 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 5600 ' . $player->getName());
				break;
				case 14:
				$player->sendMessage("§l§b» §r§aYou earned 2501 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 2581 ' . $player->getName());
				break;
				case 15:
				$player->sendMessage("§l§b» §r§aYou earned 1599 Money");
		    	$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 1599 ' . $player->getName());
				break;
				case 16:
				$player->sendMessage("§l§b» §r§aYou earned 12900 Money");
				$player->addMoney("12900");
				break;
				case 17:
				$player->sendMessage("§l§b» §r§aYou earned 51000 Money");
				$player->addMoney("51000");
				break;
				case 18:
				$player->sendMessage("§l§b» §r§aYou earned 5000 Money");
				$player->addMoney("5000");
				break;
				case 19:
				$player->sendMessage("§l§b» §r§aYou earned 95000 Money");
				$player->addMoney("95000");
				break;
				case 20:
				$player->sendMessage("§l§b» §r§aYou earned 12000 Money");
				$player->addMoney("12000");
				break;
				case 21:
				$player->sendMessage("§l§b» §r§aYou earned 15000 Money");
				$player->addMoney("15000");
				break;
				case 22:
				$player->sendMessage("§l§b» §r§aYou earned 75000 Money");
				$player->addMoney("75000");
				break;
				case 23:
				$player->sendMessage("§l§b» §r§aYou earned 1003 Money");
				$player->addMoney("1003");
				break;
				case 24:
				$player->sendMessage("§l§b» §r§aYou earned 1001 Money");
				$player->addMoney("1001");
				break;
				case 25:
				$player->sendMessage("§l§b» §r§aYou earned 1002 Money");
				$player->addMoney("1002");
				break;
				case 26:
				$player->sendMessage("§l§b» §r§aYou earned 1002 Money");
				$player->addMoney("1002");
				break;
				case 27:
				$player->sendMessage("§l§b» §r§aYou earned 16969 Money");
				$player->addMoney("16969");
				break;
				case 28:
				$player->sendMessage("§l§b» §r§aYou earned 16969 Money");
				$player->addMoney("16969");
				break;
				case 29:
				$player->sendMessage("§l§b» §r§aYou earned 16969 Money");
				$player->addMoney("16969");
				break;
				case 30:
				$player->sendMessage("§l§b» §r§aYou earned 16969 Money");
				$player->addMoney("16969");
				break;
				case 31:
				$player->sendMessage("§l§b» §r§aYou earned 1000 Money");
				$player->addMoney("1000");
				break;
				case 32:
				$player->sendMessage("§l§b» §r§aYou earned 6969 Money");
				$player->addMoney("6969");
				break;
				case 33:
				$player->sendMessage("§l§b» §r§aYou earned 6969 Money");
				$player->addMoney("6969");
				break;
				case 34:
				$player->sendMessage("§l§b» §r§aYou earned 6969 Money");
				$player->addMoney("6969");
				break;
				case 35:
				$player->sendMessage("§l§b» §r§aYou earned 1269 Money");
				$player->addMoney("1269");
				break;
				case 36:
				$player->sendMessage("§l§b» §r§aYou earned 1269 Money");
				$player->addMoney("1269");
				break;
				case 37:
				$player->sendMessage("§l§b» §r§aYou earned 1325 Money");
				$player->addMoney("1325");
				break;
				case 38:
				$player->sendMessage("§l§b» §r§aYou earned 1025 Money");
				$player->addMoney("1025");
			    break;
			}
		}
		if ($hand->getId() == 120 and $hand->getDamage() == 2) {
			$hand->setCount($hand->getCount() - 1);
			$inv->setItemInHand($hand);
			$event->setCancelled(true);
			$reward = rand(1, 31);
			switch($reward) {
				case 1:
				$this->plugin->getServer()->dispatchCommand($this->console, 'b ' . $player->getName() . ' zombie 1');
				break;
				case 2:
				$this->plugin->getServer()->dispatchCommand($this->console, 'b ' . $player->getName() . ' zombie 1');
				break;
				case 3:
				$this->plugin->getServer()->dispatchCommand($this->console, 'give ' . $player->getName() . ' 466 1');
				break;
				case 4:
				$this->plugin->getServer()->dispatchCommand($this->console, 'give ' . $player->getName() . ' 466 2');
				break;
				case 5:
				$this->plugin->getServer()->dispatchCommand($this->console, 'key Rare 16 ' . $player->getName());
				break;
				case 6:
				$this->plugin->getServer()->dispatchCommand($this->console, 'key Rare 32 ' . $player->getName());
				break;
				case 7:
				$this->plugin->getServer()->dispatchCommand($this->console, 'key Legendary 6 ' . $player->getName());
				break;
				case 8:
				$this->plugin->getServer()->dispatchCommand($this->console, 'key Legendary 6 ' . $player->getName());
				break;
				case 9:
				$this->plugin->getServer()->dispatchCommand($this->console, 'key Rare 16 ' . $player->getName());
				break;
				case 10:
				$this->plugin->getServer()->dispatchCommand($this->console, 'b ' . $player->getName() . ' zombie 1');
				break;
				case 11:
				$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 100000');
				break;
				case 12:
				$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 150000');
				break;
				case 13:
				$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 200000');
				break;
				case 14:
				$this->plugin->getServer()->dispatchCommand($this->console, 'givemoney ' . $player->getName() . ' 250000');
				break;
				case 15:
				$this->plugin->getServer()->dispatchCommand($this->console, 'brokenagem ' . $player->getName() . ' 224:1 1');
				break;
				case 16:
				$this->plugin->getServer()->dispatchCommand($this->console, 'brokensoulgem ' . $player->getName() . ' 224:1 1');
				break;
				case 17:
				$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 10000 ' . $player->getName());
				break;
				case 18:
				$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 15000 ' . $player->getName());
				break;
				case 19:
				$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 20000 ' . $player->getName());
				break;
				case 20:
				$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 25000 ' . $player->getName());
				break;
				case 21:
				$this->plugin->getServer()->dispatchCommand($this->console, 'givexp 17000 ' . $player->getName());
				break;
				case 22:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 7));
                $item->setCustomName("§r§l§4BlackOut VII\nEnchantment Book");
                $item->setLore([
                '§r§eChance to disable enemy',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn BlackOut Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 23:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Hallucination"), 4));
                $item->setCustomName("§r§l§6Hallucination IV\nEnchantment Book");
                $item->setLore([
                '§r§eChance to trap enemies in prison',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Hallucination Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 24:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 5));
                $item->setCustomName("§r§l§4BlackOut V\nEnchantment Book");
                $item->setLore([
                '§r§eChance to disable enemy',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn BlackOut Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 25:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("BlackOut"), 3));
                $item->setCustomName("§r§l§4BlackOut III\nEnchantment Book");
                $item->setLore([
                '§r§eChance to disable enemy',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn BlackOut Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 26:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Genjutsu"), 5));
                $item->setCustomName("§r§l§4Genjutsu V\nEnchantment Book");
                $item->setLore([
                '§r§eChance to Trap Enemy in a illusion',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Genjutsu Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 27:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Genjutsu"), 8));
                $item->setCustomName("§r§l§4Genjustu VIII\nEnchantment Book");
                $item->setLore([
                '§r§eChance to Trap Enemy in a illusion',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Genjutsu Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 28:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Genjutsu"), 2));
                $item->setCustomName("§r§l§4Genjutsu II\nEnchantment Book");
                $item->setLore([
                '§r§eChance to Trap Enemy in a illusion',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Genjutsu Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 29:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Spitsweb"), 1));
                $item->setCustomName("§r§l§eSpits Web I\nEnchantment Book");
                $item->setLore([
                '§r§eChance to trap enemies with cobwebs. Cooldown: 60 Seconds',
                '§r§eCooldown: 60 Seconds',
                '§r§7Weapon Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Spits Web Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 30:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 7));
                $item->setCustomName("§r§l§6Insanity VII\nEnchantment Book");
                $item->setLore([
                '§r§eIncreases massive damage in Axes',
                '§r§7Axe Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 31:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Insanity"), 8));
                $item->setCustomName("§r§l§6Insanity VIII\nEnchantment Book");
                $item->setLore([
                '§r§eIncreases massive damage in Axes',
                '§r§7Axe Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Insanity Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
			}
		}
    }
}    