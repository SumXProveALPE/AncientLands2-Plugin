<?php

namespace core\event;

use core\AncientLands;

# Pocketmine Uses
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\command\CommandSender;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\item\Item;
use pocketmine\nbt\tag\StringTag;

# Join Event
class DeathEvent implements Listener {

  private $plugin;

  public function __construct(AncientLands $plugin){
  $this->plugin = $plugin;

  }
    public function onDeath(PlayerDeathEvent $event) {
       $player = $event->getPlayer();
    if($event->getPlayer()->getLastDamageCause() instanceof EntityDamageByEntityEvent) {
        if($event->getPlayer()->getLastDamageCause()->getDamager() instanceof Player) {
            $killer = $event->getPlayer()->getLastDamageCause()->getDamager();
            $item = $killer->getInventory()->getItemInHand();
            if($item->hasCustomName()){
                $name = $item->getCustomName();
            } else {
                $name = $item->getName();
            }
            if($item->getNamedTag()->hasTag("deathLore")){
            $deathPrefix = $item->getNamedTagEntry("deathLore")->getValue();
            } else {
                $deathPrefix = "killed";
            }
            $event->setDeathMessage("§r§c" . $player->getName() . " got " . $deathPrefix . " §r§cby " . $killer->getName() . " §r§cusing " . $name);
        }
    }
}
}
