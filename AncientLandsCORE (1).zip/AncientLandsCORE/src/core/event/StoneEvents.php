<?php

namespace core\event;

use core\AncientLands;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Entity;
use pocketmine\entity\Zombie;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityEffectAddEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Explosion;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\PiggyCustomEnchants;
use DaPigGuy\PiggyCustomEnchants\CustomEnchantManager;
use onebone\economyapi\EconomyAPI;
use _64FF00\PurePerms\PPGroup;

class StoneEvents implements Listener{

	/** @var array */
	public $plugin;

    public function __construct(AncientLands $plugin) {
       $this->plugin = $plugin;
		$this->console = new ConsoleCommandSender();
	}
	
	/**
     * @param PlayerInteractEvent $event
     */
    public function onGem(PlayerInteractEvent $event) : void{    
            $player = $event->getPlayer();
            $block = $event->getBlock();
            $inv = $player->getInventory();
            $hand = $inv->getItemInHand();
            $nbt = $hand->getNamedTag();

         if ($hand->getId() == 409 and $hand->getDamage() == 0 and $hand->getCustomName() == "§8Fractured §7Stone") {
                $hand->setCount($hand->getCount() - 1);
                $inv->setItemInHand($hand);
                $event->setCancelled(true);
                $reward = mt_rand(1,6);
                switch ($reward) {
		    case 1:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' MindStone');
	        break;

		    case 2:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' PowerStone');
	        break;

		    case 3:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' RealityStone');
	        break;

		    case 4:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' SoulStone');
	        break;

		    case 5:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' SpaceStone');
	        break;

		    case 6:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' TimeStone');
	        break;
             }
	}	
	}
}