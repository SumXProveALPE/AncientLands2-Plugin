<?php

namespace core\event;

use core\AncientLands;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Entity;
use pocketmine\entity\Zombie;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityEffectAddEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Explosion;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\PiggyCustomEnchants;
use DaPigGuy\PiggyCustomEnchants\CustomEnchantManager;
use onebone\economyapi\EconomyAPI;
use _64FF00\PurePerms\PPGroup;

class KeyEvents implements Listener{

	/** @var array */
	public $plugin;

    public function __construct(AncientLands $plugin) {
       $this->plugin = $plugin;
		$this->console = new ConsoleCommandSender();
	}
	
	/**
     * @param PlayerInteractEvent $event
     */
	public function onItems(PlayerInteractEvent $event) : void{
		$player = $event->getPlayer();
		$item = $player->getInventory()->getItemInHand();
        $block = $event->getBlock();
        if($block->getId() === Block::CHEST || $block->getId() === Block::TRAPPED_CHEST){
            if($item->getId() === Item::DYE && $item->getDamage() === 18){ //BlueCrystal Key
                $event->setCancelled();
                $player->getInventory()->removeItem(Item::get(351, 18, 1));
                $reward = rand(1, 52);
                switch($reward) {
		    case 1:
		$this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' MindStone');
		$player->sendMessage("§l§b» §r§aYou got an MindStone");
	        break;
		    case 2:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' PowerStone');
		$player->sendMessage("§l§b» §r§aYou got an PowerStone");
	        break;

		    case 3:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' RealityStone');
		$player->sendMessage("§l§b» §r§aYou got an RealityStone");
	        break;

		    case 4:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' SoulStone');
		$player->sendMessage("§l§b» §r§aYou got an SoulStone");
	        break;

		    case 5:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' SpaceStone');
		$player->sendMessage("§l§b» §r§aYou got an SpaceStone");
	        break;

		    case 6:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' TimeStone');
		$player->sendMessage("§l§b» §r§aYou got an TimeStone");
	        break;

		     case 7:
		     $player->sendMessage("§l§b» §r§aYou earned 1000 XP");
		$player->addXp("1000");
		break;
		     case 8:
		     $player->sendMessage("§l§b» §r§aYou earned 2000 XP");
		$player->addXp("2000");
		break;
		     case 9:
		     $player->sendMessage("§l§b» §r§aYou earned 3000 XP");
		$player->addXp("4000");
		break;
		     case 10:
		     $player->sendMessage("§l§b» §r§aYou earned 5000 XP");
		$player->addXp("5000");
		break;

				case 11:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Frozen"), 3));
                $item->setCustomName("§r§l§bFrozen III\nEnchantment Book");
                $item->setLore([
                '§r§eGives enemy slowness',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Frozen Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 12:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Trickster"), 1));
                $item->setCustomName("§r§l§bTrickster I\nEnchantment Book");
                $item->setLore([
                '§r§eTeleport Behind Enemy',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Trickster Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 13:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Trickster"), 2));
                $item->setCustomName("§r§l§bTrickster II\nEnchantment Book");
                $item->setLore([
                '§r§eTeleport Behind Enemy',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Trickster Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 14:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Trickster"), 3));
                $item->setCustomName("§r§l§bTrickster III\nEnchantment Book");
                $item->setLore([
                '§r§eTeleport Behind Enemy',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Trickster Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 15:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Trickster"), 4));
                $item->setCustomName("§r§l§bTrickster IV\nEnchantment Book");
                $item->setLore([
                '§r§eTelport Behind Enemy',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Trickster Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 16:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Trickster"), 5));
                $item->setCustomName("§r§l§bTrickster V\nEnchantment Book");
                $item->setLore([
                '§r§eTeleport Behind Enemy',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Trickster Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 17:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Trickster"), 6));
                $item->setCustomName("§r§l§bTrickster VI\nEnchantment Book");
                $item->setLore([
                '§r§eTeleport Behind Enemy',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Trickster Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 18:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Trickster"), 7));
                $item->setCustomName("§r§l§bTrickster VII\nEnchantment Book");
                $item->setLore([
                '§r§eTelport Behind Enemy',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Trickster Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 19:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("ShockWave"), 1));
                $item->setCustomName("§r§l§bShockWave I\nEnchantment Book");
                $item->setLore([
                '§r§eKnocks enemy back',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn ShockWave Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 20:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("ShockWave"), 2));
                $item->setCustomName("§r§l§bShockWave II\nEnchantment Book");
                $item->setLore([
                '§r§eKnocks enemy back',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn ShockWave Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 21:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("ShockWave"), 3));
                $item->setCustomName("§r§l§bShockWave III\nEnchantment Book");
                $item->setLore([
                '§r§eKnocks enemy back',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn ShockWave Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 22:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Confusion"), 1));
                $item->setCustomName("§r§l§bConfusion I\nEnchantment Book");
                $item->setLore([
                '§r§eGives Enemy Nausa',
                '§r§7Weapon Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Confusion Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
			case 23:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Confusion"), 2));
                $item->setCustomName("§r§l§bConfusion II\nEnchantment Book");
                $item->setLore([
                '§r§eGives Enemy Nausa',
                '§r§7Weapon Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Confusion Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
			case 24:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Confusion"), 3));
                $item->setCustomName("§r§l§bConfusion III\nEnchantment Book");
                $item->setLore([
                '§r§eGives Enemy Nausa',
                '§r§7Weapon Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Confusion Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;			
                                case 25:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Confusion"), 4));
                $item->setCustomName("§r§l§bConfusion IV\nEnchantment Book");
                $item->setLore([
                '§r§eGives Enemy Nausa',
                '§r§7Weapon Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Confusion Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
			       case 26:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Confusion"), 5));
                $item->setCustomName("§r§l§bConfusion V\nEnchantment Book");
                $item->setLore([
                '§r§eGives Enemy Nausa',
                '§r§7Weapon Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Confusion Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
			       case 27:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Pummel"), 1));
                $item->setCustomName("§r§l§bPummel I\nEnchantment Book");
                $item->setLore([
                '§r§eGives Enemy Slowness',
                '§r§7Weapon Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Pummel Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
			       case 28:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Pummel"), 2));
                $item->setCustomName("§r§l§bPummel II\nEnchantment Book");
                $item->setLore([
                '§r§eGives Enemy Slowness',
                '§r§7Weapon Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Pummel Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
			       case 29:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Pummel"), 3));
                $item->setCustomName("§r§l§bPummel III\nEnchantment Book");
                $item->setLore([
                '§r§eGives Enemy Slowness',
                '§r§7Weapon Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Pummel Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 30:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Smelting"), 1));
                $item->setCustomName("§r§l§bSmelting I\nEnchantment Book");
                $item->setLore([
                '§r§eAutomatically smelts drops when block broken',
                '§r§7Tools Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Smelting Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 31:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Glowing"), 1));
                $item->setCustomName("§r§l§eGlowing I\nEnchantment Book");
                $item->setLore([
                '§r§eGives effect night vision',
                '§r§7Helmets Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Glowing Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 32:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 1));
                $item->setCustomName("§r§l§bWither I\nEnchantment Book");
                $item->setLore([
                '§r§eInflict Wither on enemies',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Wither Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 33:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 2));
                $item->setCustomName("§r§l§bWither II\nEnchantment Book");
                $item->setLore([
                '§r§eInflict Wither on enemies',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Wither Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 34:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 3));
                $item->setCustomName("§r§l§bWither III\nEnchantment Book");
                $item->setLore([
                '§r§eInflict Wither on enemies',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Wither Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 35:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 4));
                $item->setCustomName("§r§l§bWither IV\nEnchantment Book");
                $item->setLore([
                '§r§eInflict Wither on enemies',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Wither Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 36:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Wither"), 5));
                $item->setCustomName("§r§l§bWither V\nEnchantment Book");
                $item->setLore([
                '§r§eInflict Wither on enemies',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Wither Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 37:
				$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 1));
								$item->setCustomName("§r§l§eQuickening I\nEnchantment Book");
								$item->setLore([
								'§r§eGain speed upon breaking block',
								'§r§7Pickaxe Enchantment',
								'§r§7Combine it into item to enchant'
								]);
								$player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
								if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
										$player->getInventory()->addItem($item);
				}
				break;
				case 38:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 1));
                $item->setCustomName("§r§l§bPoison I\nEnchantment Book");
                $item->setLore([
                '§r§eInflict Poison on enemies',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Poison Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 39:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 2));
                $item->setCustomName("§r§l§bPoison II\nEnchantment Book");
                $item->setLore([
                '§r§eInflict Poison on enemies',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Poison Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 40:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 3));
                $item->setCustomName("§r§l§bPoison III\nEnchantment Book");
                $item->setLore([
                '§r§eInflict Poison on enemies',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Poison Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 41:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Poison"), 4));
                $item->setCustomName("§r§l§bPoison IV\nEnchantment Book");
                $item->setLore([
                '§r§eInflict Poison on enemies',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Poison Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;

                    case 42:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 5000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 5k Money");
                    break;

                    case 43:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 6000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 6k Money");
                    break;

                    case 44:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 7000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 7k Money");
                    break;

                    case 45:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 8000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 8k Money");
                    break;

                    case 46:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 9000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 9k Money");
                    break;

                    case 47:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 322 8 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 8 Golden Apples");
                    break;

                    case 48:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 322 16 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 8 Golden Apples");
                    break;

                    case 49:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 322 32 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 8 Golden Apples");

                    case 50:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 368 4 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 4 EnderPearls");
                    break;

                    case 51:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 368 8 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 4 EnderPearls");
                    break;

                    case 52:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 368 12 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 4 EnderPearls");
                    break;
		}
	 }	
        if($block->getId() === Block::CHEST || $block->getId() === Block::TRAPPED_CHEST){
            if($item->getId() === Item::DYE && $item->getDamage() === 11){ //YellowCrystal Key
                $event->setCancelled();
                $player->getInventory()->removeItem(Item::get(351, 11, 1));
                $reward = rand(1, 52);
                switch($reward) {
		    case 1:
		$this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' MindStone');
		$player->sendMessage("§l§b» §r§aYou got an MindStone");
	        break;
		    case 2:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' PowerStone');
		$player->sendMessage("§l§b» §r§aYou got an PowerStone");
	        break;

		    case 3:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' RealityStone');
		$player->sendMessage("§l§b» §r§aYou got an RealityStone");
	        break;

		    case 4:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' SoulStone');
		$player->sendMessage("§l§b» §r§aYou got an SoulStone");
	        break;

		    case 5:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' SpaceStone');
		$player->sendMessage("§l§b» §r§aYou got an SpaceStone");
	        break;

		    case 6:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'stone ' . $player->getName() . ' TimeStone');
		$player->sendMessage("§l§b» §r§aYou got an TimeStone");
	        break;

		     case 7:
		     $player->sendMessage("§l§b» §r§aYou earned 6000 XP");
		$player->addXp("6000");
		break;
		     case 8:
		     $player->sendMessage("§l§b» §r§aYou earned 7000 XP");
		$player->addXp("7000");
		break;
		     case 9:
		     $player->sendMessage("§l§b» §r§aYou earned 8000 XP");
		$player->addXp("8000");
		break;
		     case 10:
		     $player->sendMessage("§l§b» §r§aYou earned 9000 XP");
		$player->addXp("9000");
		break;

				case 11:
				$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cursed"), 8));
								$item->setCustomName("§r§l§eCursed VIII\nEnchantment Book");
								$item->setLore([
								'§r§eGives wither to attacker',
								'§r§7Armor Enchantment',
								'§r§7Combine it into item to enchant'
								]);
								$player->sendMessage("§l§b» §r§aYou earn Cursed Custom Enchantment");
								if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
										$player->getInventory()->addItem($item);
				}
				break;
				case 12:
				$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cursed"), 9));
								$item->setCustomName("§r§l§eCursed XI\nEnchantment Book");
								$item->setLore([
								'§r§eGives wither to attacker',
								'§r§7Armor Enchantment',
								'§r§7Combine it into item to enchant'
								]);
								$player->sendMessage("§l§b» §r§aYou earn Cursed Custom Enchantment");
								if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
										$player->getInventory()->addItem($item);
				}
				break;
				case 13:
				$item = Item::get(403, 0, 1);
					$item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Cursed"), 10));
								$item->setCustomName("§r§l§eCursed X\nEnchantment Book");
								$item->setLore([
								'§r§eGives wither to attacker',
								'§r§7Armor Enchantment',
								'§r§7Combine it into item to enchant'
								]);
								$player->sendMessage("§l§b» §r§aYou earn Cursed Custom Enchantment");
								if (!$player->getInventory()->canAddItem($item)) {
						$player->dropItem($item);
					} else {
										$player->getInventory()->addItem($item);
				}
				break;
				case 14:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Fertilizer"), 1));
                $item->setCustomName("§r§l§eFertilizer I\nEnchantment Book");
                $item->setLore([
                '§r§eCreates farmland in a level radius around the block',
                '§r§7Hoe Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Fertilizer Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 15:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Lumberjack"), 1));
                $item->setCustomName("§r§l§eLumberjack I\nEnchantment Book");
                $item->setLore([
                '§r§eMines all logs connected to log when broken',
                '§r§7Axe Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Lumberjack Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 16:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Focused"), 1));
                $item->setCustomName("§r§l§eFocused I\nEnchantment Book");
                $item->setLore([
                '§r§e20% (1 = level) chance Immunity to Nausea',
                '§r§7Helmets Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Focused Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 17:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Focused"), 2));
                $item->setCustomName("§r§l§eFocused II\nEnchantment Book");
                $item->setLore([
                '§r§e20% (1 = level) chance Immunity to Nausea',
                '§r§7Helmets Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Focused Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 18:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Focused"), 3));
                $item->setCustomName("§r§l§eFocused III\nEnchantment Book");
                $item->setLore([
                '§r§e20% (1 = level) chance Immunity to Nausea',
                '§r§7Helmets Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Focused Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 19:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blessed"), 1));
                $item->setCustomName("§r§l§eBlessed I\nEnchantment Book");
                $item->setLore([
                '§r§e20% (1 = level) chance Immunity to Nausea',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Blessed Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 20:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blessed"), 2));
                $item->setCustomName("§r§l§eBlessed II\nEnchantment Book");
                $item->setLore([
                '§r§e20% (1 = level) chance Immunity to Nausea',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Blessed Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 21:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Blessed"), 3));
                $item->setCustomName("§r§l§eBlessed III\nEnchantment Book");
                $item->setLore([
                '§r§e20% (1 = level) chance Immunity to Nausea',
                '§r§7Sword Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Blessed Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 22:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Farmer"), 1));
                $item->setCustomName("§r§l§eFarmer I\nEnchantment Book");
                $item->setLore([
                '§r§eAutomatically replace seeds when crop is broken',
                '§r§7Hoe Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Farmer Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 23:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Nourish"), 1));
                $item->setCustomName("§r§l§eNourish I\nEnchantment Book");
                $item->setLore([
                '§r§eGrants immunty to wither',
                '§r§7Helmet Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Nourish Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 24:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Nourish"), 2));
                $item->setCustomName("§r§l§eNourish II\nEnchantment Book");
                $item->setLore([
                '§r§eGrants immunty to wither',
                '§r§7Helmet Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Nourish Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 25:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Nourish"), 3));
                $item->setCustomName("§r§l§eNourish III\nEnchantment Book");
                $item->setLore([
                '§r§eGrants immunty to wither',
                '§r§7Helmet Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Nourish Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 26:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Nourish"), 4));
                $item->setCustomName("§r§l§eNourish IV\nEnchantment Book");
                $item->setLore([
                '§r§eGrants immunty to wither',
                '§r§7Helmet Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Nourish Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 27:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Nourish"), 5));
                $item->setCustomName("§r§l§eNourish V\nEnchantment Book");
                $item->setLore([
                '§r§eGrants immunty to wither',
                '§r§7Helmet Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Nourish Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 28:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 1));
                $item->setCustomName("§r§l§eQuickening I\nEnchantment Book");
                $item->setLore([
                '§r§eGain speed upon breaking block',
                '§r§7Pickaxe Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 29:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 2));
                $item->setCustomName("§r§l§eQuickening II\nEnchantment Book");
                $item->setLore([
                '§r§eGain speed upon breaking block',
                '§r§7Pickaxe Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 30:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 3));
                $item->setCustomName("§r§l§eQuickening III\nEnchantment Book");
                $item->setLore([
                '§r§eGain speed upon breaking block',
                '§r§7Pickaxe Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 31:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 4));
                $item->setCustomName("§r§l§eQuickening IV\nEnchantment Book");
                $item->setLore([
                '§r§eGain speed upon breaking block',
                '§r§7Pickaxe Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 32:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Quickening"), 5));
                $item->setCustomName("§r§l§eQuickening V\nEnchantment Book");
                $item->setLore([
                '§r§eGain speed upon breaking block',
                '§r§7Pickaxe Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Quickening Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 33:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 1));
                $item->setCustomName("§r§l§eRevive I\nEnchantment Book");
                $item->setLore([
                '§r§eGain another life',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 34:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 2));
                $item->setCustomName("§r§l§eRevive II\nEnchantment Book");
                $item->setLore([
                '§r§eGain another life',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 35:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 3));
                $item->setCustomName("§r§l§eRevive III\nEnchantment Book");
                $item->setLore([
                '§r§eGain another life',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 36:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 4));
                $item->setCustomName("§r§l§eRevive VI\nEnchantment Book");
                $item->setLore([
                '§r§eGain another life',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 37:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 5));
                $item->setCustomName("§r§l§eRevive V\nEnchantment Book");
                $item->setLore([
                '§r§eGain another life',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 38:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 6));
                $item->setCustomName("§r§l§eRevive VI\nEnchantment Book");
                $item->setLore([
                '§r§eGain another life',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 39:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 7));
                $item->setCustomName("§r§l§eRevive VII\nEnchantment Book");
                $item->setLore([
                '§r§eGain another life',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
                                case 40:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Revive"), 8));
                $item->setCustomName("§r§l§eRevive VIII\nEnchantment Book");
                $item->setLore([
                '§r§eGain another life',
                '§r§7Armor Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Revive Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;
				case 41:
				$item = Item::get(403, 0, 1);
			    $item->addEnchantment(new EnchantmentInstance(CustomEnchantManager::getEnchantmentByName("Volley"), 1));
                $item->setCustomName("§r§l§eVolley I\nEnchantment Book");
                $item->setLore([
                '§r§eShoots multiple arrows in a cone shape',
                '§r§7Bow Enchantment',
                '§r§7Combine it into item to enchant'
                ]);
                $player->sendMessage("§l§b» §r§aYou earn Volley Custom Enchantment");
                if (!$player->getInventory()->canAddItem($item)) {
				    $player->dropItem($item);
			    } else {
                    $player->getInventory()->addItem($item);
				}
				break;

                    case 42:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 10000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 10k Money");
                    break;

                    case 43:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 11000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 11k Money");
                    break;

                    case 44:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 12000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 12k Money");
                    break;

                    case 45:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 13000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 13k Money");
                    break;

                    case 46:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'givemoney 14000 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 14k Money");
                    break;

                    case 47:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 322 8 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 8 Golden Apples");
                    break;

                    case 48:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 322 16 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 8 Golden Apples");
                    break;

                    case 49:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 322 32 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 8 Golden Apples");

                    case 50:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 368 4 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 4 EnderPearls");
                    break;

                    case 51:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 368 8 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 4 EnderPearls");
                    break;

                    case 52:
		    $this->plugin->getServer()->dispatchCommand($this->console, 'give 368 12 ' . $player->getName());
                    $player->sendMessage("§b§l>> §r§aYou Recieved 4 EnderPearls");
                    break;
		}
	 }	

            }
        }    
	}
}