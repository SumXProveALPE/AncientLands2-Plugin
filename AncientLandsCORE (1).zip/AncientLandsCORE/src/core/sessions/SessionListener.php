<?php

namespace core\sessions;

use core\AncientLands;
use core\database\Database;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;

class SessionListener implements Listener{

	public AncientLands $plugin;

	public function __construct(
		AncientLands $plugin
	){
		$this->plugin = $plugin;
	}

	public function onJoin(PlayerJoinEvent $event)
	{
		if(!Database::exist($event->getPlayer())){
			Database::createData($event->getPlayer());
		}
	    Sessions::createSession($event->getPlayer());
		#$event->getPlayer()->sendMessage("SESSIONED");
		#$event->getPlayer()->sendMessage("BLOCKS" . Sessions::getSession($event->getPlayer())->getBlocks());
	}

	public function onQuit(PlayerQuitEvent $event){
		$s = Sessions::getSession($event->getPlayer());
		$s->saveData();
	}

	/**
	 * @return AncientLands
	 */
	public function getPlugin(): AncientLands
	{
		return $this->plugin;
	}
}