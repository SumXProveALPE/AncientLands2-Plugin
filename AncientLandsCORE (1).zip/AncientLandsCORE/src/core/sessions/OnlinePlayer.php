<?php


namespace core\sessions;

use core\database\Database;
use pocketmine\Player;

class OnlinePlayer
{

	protected $uuid;
	protected $player;

	protected $data;

	public function __construct(Player $player)
	{
		$this->uuid = $player->getUniqueId()->toString();
		$this->player = $player;
		$this->loadData();
	}

	public function loadData()
	{
		$this->data = [
			"uuid" => $this->uuid,
			"username" => $this->player->getName(),
			"mining rewards" => [
				"level" => Database::getMRLevel($this->player),
				"blocks" => Database::getMinedBlocks($this->player)
			]
		];
	}

	public function getLevel()
	{
		return $this->data["mining rewards"]["level"];
	}

	public function getBlocks()
	{
		return $this->data["mining rewards"]["blocks"];
	}

	public function updateMRData(string $label, int $value)
	{
		$this->data["mining rewards"][$label] = $value;
	}

	public function saveData()
	{
		Database::updateLevel($this->player, $this->getLevel());
		Database::updateMinedBlocks($this->player, $this->getBlocks());
	}

}