<?php


namespace core\sessions;


use pocketmine\Player;

class Sessions
{

	/** @var OnlinePlayer[] */
	private static $sessions = [];

	public static function createSession(Player $player): void{
		if (isset(self::$sessions[$player->getUniqueId()->toString()])) return;
		self::$sessions[$player->getUniqueId()->toString()] = new OnlinePlayer($player);
	}

	public static function removeSession(Player $player): void{
		if (!isset(self::$sessions[$player->getUniqueId()->toString()])) return;
		unset(self::$sessions[$player->getUniqueId()->toString()]);
	}

	public static function getSession(Player $player): OnlinePlayer{
		if (!isset(self::$sessions[$player->getUniqueId()->toString()])) self::createSession($player);
		return self::$sessions[$player->getUniqueId()->toString()];
	}

}